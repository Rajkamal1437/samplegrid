import { Routes } from '@angular/router';
import { EjsgridComponent } from './ejsgrid/ejsgrid.component';
import { LandingComponent } from './landing/landing.component';
import {  BulkEntryDeactivateGuard } from './bulkentry-gaurd.service';
import { Tsej2gridComponent } from './tsej2grid/tsej2grid.component';


export const ROUTES: Routes = [
  { path: '', redirectTo: 'landing', pathMatch: 'full' },
  { path: 'bulk-entry', component: EjsgridComponent, canDeactivate: [BulkEntryDeactivateGuard]  },
  { path: 'ts-bulk-entry', component: Tsej2gridComponent },
  { path: 'landing', component: LandingComponent },
  { path: '**', component: LandingComponent },

];
