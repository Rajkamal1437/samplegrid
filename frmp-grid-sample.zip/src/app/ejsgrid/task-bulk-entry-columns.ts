import { IEditCell, GridComponent, parentsUntil } from '@syncfusion/ej2-angular-grids';
import { ValidationService } from './validation.service';
import { Injectable, ViewChild } from '@angular/core';
import { Query } from '@syncfusion/ej2-data';
import { NumericTextBox } from '@syncfusion/ej2-inputs';
import { countriesData } from '../data-source';
import { format } from 'util';

@Injectable({
  providedIn: 'root',
})
export class TaskBulkEntryCloumns {
  @ViewChild('grid')
  public grid: GridComponent;
  public numericParams: IEditCell;
  public singeDecimalParams: IEditCell;
  public noDecimalParams: IEditCell;
  public countryParams: IEditCell;
  public filterTemp = '#numberfilterItemTemplate';
  constructor(private validationService: ValidationService) {
    this.countryParams = {
      params: {
        dataSource: countriesData || [],
        fields: { value: 'countrycode', text: 'countryname' },
        query: new Query(),
        placeholder: 'Select a country',
        floatLabelType: 'Never'
      }
    };
    this.numericParams = { params: { validateDecimalOnType: true, decimals: 2, showSpinButton: false } };
    this.singeDecimalParams = { params: { validateDecimalOnType: true, decimals: 1, showSpinButton: false } };
    this.noDecimalParams = { params: { validateDecimalOnType: true, decimals: 0, showSpinButton: false } };

  }


  public columns = (currentYear) => {
    let elem: HTMLElement;
    let numericTextBoxObj: NumericTextBox;
    let EditTemplatefn = {
      create: () => {
        elem = document.createElement('input');
        return elem;
      },
      read: () => {
        return numericTextBoxObj.value;
      },
      destroy: () => {
        numericTextBoxObj.destroy();
      },
      write: (args: { rowData: Object, column: any }) => {
        numericTextBoxObj = new NumericTextBox({
          showSpinButton: false,
          decimals: 1,
          validateDecimalOnType: true,
          value: args.rowData[args.column.field],
          created: function (args) {
            this.element.addEventListener("keypress", function (args) {
              let decimal: string = '.';
              let INTREGEXP: RegExp = new RegExp('^(-)?(\\d{0,6})$');
              if (args.key !== decimal) {
                let cellVal = args.target.value.toString();
                let num = cellVal.split('.');
                let result: string = num[0] + args.key;
                if (result.indexOf(decimal) < 0 && cellVal && !INTREGEXP.test(result)) {
                  args.preventDefault();
                }
              }
            });
          }
        });
        numericTextBoxObj.appendTo(elem);
      }
    }
    let isFF = false;

    // customAttributes: {class:  (this.showHideCol(currentYear, TabType))  ? 'e-hideCell' : ''}
    // valueAccessor: this.validationService.getValueAccessorData,
    return {
      TotalSale: [
        {  clipMode: 'EllipsisWithTooltip', customAttributes: { class: 'e-Total-backgtound' }, field: 'TotalCurrentYearSales', headerTextAlign: "left", format: 'N0', headerText: currentYear, textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120,  allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', customAttributes: { class: 'e-Total-backgtound' }, field: 'TotalPreviousYearRefreshSales', headerTextAlign: "left", format: 'N0', headerText: (currentYear - 1) + '- R', textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120,  allowFiltering: true }
      ],
      salesIFF: [
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFCurrentYearSales', headerTextAlign: "left", headerText: currentYear, textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearRefreshSales', headerTextAlign: "left", headerText: (currentYear - 1) + '- R', textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true }
      ]
      , salesFirmenich: [
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichCurrentYearSales', headerTextAlign: "left", headerText: currentYear, textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: true, validationRules: { required: true, min: 0, max: 99999.9 }, editParams: { decimalPlaces: 1 } },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearSales', headerTextAlign: "left", headerText: (currentYear - 1), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearRefreshSales', headerTextAlign: "left", headerText: (currentYear - 1) + '- R', textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: true, validationRules: { required: true, min: 0, max: 99999.9 } }
      ],
      salesGivaudan: [
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanCurrentYearSales', headerTextAlign: "left", headerText: currentYear, textAlign: 'Right', showInColumnChooser: false, width: 120, customAttributes: { class: 'editCell' }, editType: 'numericedit', edit: this.singeDecimalParams,validationRules: { required: true, min: 0, max: 99999.9 }, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearSales', headerTextAlign: "left", headerText: (currentYear - 1), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearRefreshSales', headerTextAlign: "left", headerText: (currentYear - 1) + '- R', textAlign: 'Right', showInColumnChooser: false, width: 120, customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams,validationRules: { required: true, min: 0, max: 99999.9 }, allowFiltering: true }
      ],
      salesSymrise: [
        {  clipMode: 'EllipsisWithTooltip', field: 'SymriseCurrentYearSales', headerTextAlign: "left", headerText: currentYear, textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams,validationRules: { required: true, min: 0, max: 99999.9 }, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearSales', headerTextAlign: "left", headerText: (currentYear - 1), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearRefreshSales', headerTextAlign: "left", headerText: (currentYear - 1) + '- R', textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams,validationRules: { required: true, min: 0, max: 99999.9 }, showInColumnChooser: false, width: 120, allowFiltering: true }
      ],
      salesMane: [
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManeCurrentYearSales', headerTextAlign: "left", headerText: currentYear, textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams,validationRules: { required: true, min: 0, max: 99999.9 }, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManePreviousYearSales', headerTextAlign: "left", headerText: (currentYear - 1), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManePreviousYearRefreshSales', headerTextAlign: "left", headerText: (currentYear - 1) + '- R', textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams,validationRules: { required: true, min: 0, max: 99999.9 }, showInColumnChooser: false, width: 120, allowFiltering: true }
      ],
      salesTakasago: [
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoCurrentYearSales', headerTextAlign: "left", headerText: currentYear, textAlign: 'Right', showInColumnChooser: false, customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, validationRules: { required: true, min: 0, max: 99999.9 }, width: 120, allowFiltering: true },
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearSales', headerTextAlign: "left", headerText: (currentYear - 1), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearRefreshSales', headerTextAlign: "left", headerText: (currentYear - 1) + '- R', textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, validationRules: { required: true, min: 0, max: 99999.9 }, showInColumnChooser: false, width: 120, allowFiltering: true }
      ],
      salesOthers: [
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersCurrentYearSales', headerTextAlign: "left", headerText: currentYear, textAlign: 'Right', showInColumnChooser: false, customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, validationRules: { required: true, min: 0, max: 99999.9 }, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearSales', headerTextAlign: "left", headerText: (currentYear - 1), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearRefreshSales', headerTextAlign: "left", headerText: (currentYear - 1) + '- R', textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams,validationRules: { required: true, min: 0, max: 99999.9 }, showInColumnChooser: false, width: 120, allowFiltering: true }
      ],
      CurYearDosage: [
        { clipMode: 'EllipsisWithTooltip', field: 'CurrentCspExw', headerTextAlign: "left", headerText: currentYear + " CSP EXW ($/Kg)", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.numericParams, showInColumnChooser: false, width: 140, allowFiltering: false, format: 'C2' },
        { clipMode: 'EllipsisWithTooltip', field: 'CurrentDosage', headerTextAlign: "left", headerText: currentYear + " Dosage (%)", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.numericParams, showInColumnChooser: false, width: 140, allowFiltering: false, format: 'P2' },
        { clipMode: 'EllipsisWithTooltip', field: 'CurrentDosageCPT', headerTextAlign: "left", headerText: currentYear + " Cost Per Ton", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, valueAccessor: this.validationService.getCurrentDosageCPT.bind(this), allowFiltering: false,format: 'C2' },
      ],
      PrevYearDosage: [
        { clipMode: 'EllipsisWithTooltip', field: 'PrevCspExw', headerTextAlign: "left", headerText: (currentYear - 1) + " CSP EXW ($/Kg)", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: false, format: 'C2' },
        { clipMode: 'EllipsisWithTooltip', field: 'PrevDosage', headerTextAlign: "left", headerText: (currentYear - 1) + " Dosage (%)", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: false, format: 'P2' },
        { clipMode: 'EllipsisWithTooltip', field: 'PrevDosageCPT', headerTextAlign: "left", headerText: (currentYear - 1) + " Cost Per Ton", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, valueAccessor: this.validationService.getPrevDosageCPT, allowFiltering: false, format: 'C2' },
      ],
      AvailablityCurYearIFF: [
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFCurrentYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFCurrentYearAvailabilitySales', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140,  allowFiltering: true, format: 'N0' },
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFCurrentYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', validationRules: { required: true, min: 0, max: 100 }, allowEditing: true, edit: this.noDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityPrevYearIFF: [
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityCurYearFirmenich: [
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichCurrentYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichCurrentYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichCurrentYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', validationRules: { required: true, min: 0, max: 100 }, allowEditing: true, edit: this.noDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityPrevYearFirmenich: [
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearAvailabilitySales',format: 'N0',  headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityCurYearGivaudan: [
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanCurrentYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanCurrentYearAvailabilitySales',format: 'N0',  headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanCurrentYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', validationRules: { required: true, min: 0, max: 100 }, allowEditing: true, edit: this.noDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityPrevYearGivaudan: [
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearTP',  headerTextAlign: "left", headerText: "Total Potential", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearAvailabilitySales',format: 'N0',  headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityCurYearSymrise: [
        {  clipMode: 'EllipsisWithTooltip', field: 'SymriseCurrentYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymriseCurrentYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymriseCurrentYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', validationRules: { required: true, min: 0, max: 100 }, allowEditing: true, edit: this.noDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityPrevYearSymrise: [
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityCurYearTakasago: [
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoCurrentYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoCurrentYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoCurrentYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', validationRules: { required: true, min: 0, max: 100 }, allowEditing: true, edit: this.noDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityPrevYearTakasago: [
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        { visible: !isFF, clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],

      AvailablityCurYearMane: [
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManeCurrentYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManeCurrentYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManeCurrentYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', validationRules: { required: true, min: 0, max: 100 }, allowEditing: true, edit: this.noDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityPrevYearMane: [
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManePreviousYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManePreviousYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  visible: isFF, clipMode: 'EllipsisWithTooltip', field: 'ManePreviousYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityCurYearOthers: [
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersCurrentYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersCurrentYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersCurrentYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', customAttributes: { class: 'editCell' }, editType: 'numericedit', validationRules: { required: true, min: 0, max: 100 }, allowEditing: true, edit: this.noDecimalParams, showInColumnChooser: false, width: 120, allowFiltering: false },
      ],
      AvailablityPrevYearOthers: [
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearTP',  headerTextAlign: "left", headerText: "Total Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearAvailabilitySales', format: 'N0', headerTextAlign: "left", headerText: "$ in 000's", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearAvailability', headerTextAlign: "left", headerText: "%", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: false },
      ],
      TotalEncap: [
        { field: 'TotalCurEncap', customAttributes: { class: 'e-Total-backgtound' },  clipMode: 'EllipsisWithTooltip', headerTextAlign: "left", headerText: (currentYear), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        { field: 'TotalPrevEncap', customAttributes: { class: 'e-Total-backgtound' },  clipMode: 'EllipsisWithTooltip', headerTextAlign: "left", headerText: (currentYear - 1), textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true },
        { field: 'TotalPrevRefEncap', customAttributes: { class: 'e-Total-backgtound' },  clipMode: 'EllipsisWithTooltip', headerTextAlign: "left", headerText: (currentYear - 1) + "-R", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 140, allowFiltering: true }
      ],
      IFFENCAPCurrYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFCurrentYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {
           clipMode: 'EllipsisWithTooltip', field: 'IFFCurrentYearEncapsulation', customAttributes: { class: 'editCell' }, editType: 'numericedit',
          allowEditing: true, edit: this.singeDecimalParams, headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', showInColumnChooser: false, width: 120,
          allowFiltering: true, validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 }
        }
      ],
      IFFENCAPPrevYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      IFFENCAPPrevYearRef: [
        {  clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearRefreshSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {
           clipMode: 'EllipsisWithTooltip', field: 'IFFPreviousYearRefreshEncapsulation',
          validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
          customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true
        },
      ],
      FirmenichENCAPCurrYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichCurrentYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichCurrentYearEncapsulation', customAttributes: { class: 'editCell' }, editType: 'numericedit',
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
         allowEditing: true, edit: this.singeDecimalParams, headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      FirmenichENCAPPrevYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      FirmenichENCAPPrevYearRef: [
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearRefreshSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'FirmenichPreviousYearRefreshEncapsulation', customAttributes: { class: 'editCell' }, editType: 'numericedit',
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
         allowEditing: true, edit: this.singeDecimalParams, headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      GivaudanENCAPCurrYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanCurrentYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanCurrentYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", 
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
        customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      GivaudanENCAPPrevYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      GivaudanENCAPPrevYearRef: [
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearRefreshSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'GivaudanPreviousYearRefreshEncapsulation', headerTextAlign: "left", headerText: "Market Encap", 
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
        customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],

      SymriseENCAPCurrYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'SymriseCurrentYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymriseCurrentYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", 
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
        customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      SymriseENCAPPrevYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      SymriseENCAPPrevYearRef: [
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearRefreshSalesMP',  headerTextAlign: "left", headerText: "Market Potential", textAlign: 'Right', allowEditing: false, showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'SymrisePreviousYearRefreshEncapsulation', headerTextAlign: "left", headerText: "Market Encap", 
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
        customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],

      TakasagoENCAPCurrYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'TakasagoCurrentYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'TakasagoCurrentYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", 
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
        customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      TakasagoENCAPPrevYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      TakasagoENCAPPrevYearRef: [
        {  clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearRefreshSalesMP',  headerTextAlign: "left", headerText: "Market Potential", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'TakasagoPreviousYearRefreshEncapsulation', headerTextAlign: "left", headerText: "Market Encap", 
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
        customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],

      OthersENCAPCurrYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersCurrentYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersCurrentYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", 
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
        customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      OthersENCAPPrevYear: [
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearSalesMP',  headerTextAlign: "left", headerText: "Market Potential", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearEncapsulation', headerTextAlign: "left", headerText: "Market Encap", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      OthersENCAPPrevYearRef: [
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearRefreshSalesMP',  headerTextAlign: "left", headerText: "Market Potential", allowEditing: false, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
        {  clipMode: 'EllipsisWithTooltip', field: 'OthersPreviousYearRefreshEncapsulation', headerTextAlign: "left", headerText: "Market Encap",
        validationRules: { required: [this.validationService.validateCurYearEncap.bind(this), 'Market Encap cannot be greater than Market potential'], min: 0 },
         customAttributes: { class: 'editCell' }, editType: 'numericedit', allowEditing: true, edit: this.singeDecimalParams, textAlign: 'Right', showInColumnChooser: false, width: 120, allowFiltering: true },
      ],
      rowSummaryColumns: [
        {
           clipMode: 'EllipsisWithTooltip', field: 'IFFTotalConsumption',
          
          headerTextAlign: 'Left',
          headerText: '$ in 000\'s',
          width: 140,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: true,
          allowSorting: true,
          showInColumnChooser: false,
          customAttributes: { class: 'e-Total-backgtound' },
          allowEditing: false,
          // isFrozen: true
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'RowPercentage',
          headerTextAlign: 'Left',
          headerText: '%',
          width: 120,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          customAttributes: { class: 'e-Total-backgtound' },
          allowEditing: false,
          format: 'P0',
          // isFrozen: true,
          // formatter: ExtendedFormatter
          valueAccessor: this.validationService.getRowTotalPercent
        }
      ],
      consumptionCountry1Columns: [
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country1Id',
          headerTextAlign: 'Left',
          headerText: 'Invoiced Country',
          width: 180,
          textAlign: 'Left',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          editType: 'dropdownedit',
          edit: this.countryParams,
          valueAccessor: this.validationService.countryNameFromCode,
          validationRules: { required: true },
          allowEditing: true,
          customAttributes: { class: 'editCell' }
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country1PercentageOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Split in (%)',
          width: 100,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          editType: 'numericedit',
          customAttributes: { class: 'editCell' },
          edit: this.noDecimalParams,
          validationRules: { required: [this.validationService.customFn.bind(this), 'Country 1 must be entered!'], min: 0, max: 100 }
          // validationRules: { required: [this.validationService.percentFn.bind(this), 'percentage field should be between 0 to 100'], min:0, max: 100 }
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country1ValueOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Values in (000\'s)',
          format: 'N1',
          width: 140,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          allowEditing: false,
          // valueAccessor: this.validationService.calculateSpiltValue,
        }
      ],
      consumptionCountry2Columns: [
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country2Id',
          headerTextAlign: 'Left',
          headerText: 'Consumption Country 2',
          width: 180,
          textAlign: 'Left',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          editType: 'dropdownedit',
          edit: this.countryParams,
          customAttributes: { class: 'editCell' },
          valueAccessor: this.validationService.countryNameFromCode,
          // validationRules: { required: true },
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country2PercentageOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Split in (%)',
          width: 100,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          editType: 'numericedit',
          customAttributes: { class: 'editCell' },
          edit: this.noDecimalParams,
          validationRules: { required: [this.validationService.customFn.bind(this), 'Country 2 must be entered!'], min: 0, max: 100 }
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country2ValueOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Values in (000\'s)',
          format: 'N1',
          width: 140,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          allowEditing: false,
          // valueAccessor: this.validationService.calculateSpiltValue,
        }
      ],
      consumptionCountry3Columns: [
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country3Id',
          headerTextAlign: 'Left',
          headerText: 'Consumption Country 3',
          width: 180,
          textAlign: 'Left',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          editType: 'dropdownedit',
          edit: this.countryParams,
          customAttributes: { class: 'editCell' },
          valueAccessor: this.validationService.countryNameFromCode,
          // validationRules: { required: true },
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country3PercentageOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Split in (%)',
          width: 100,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          editType: 'numericedit',
          edit: this.noDecimalParams,
          customAttributes: { class: 'editCell' },
          validationRules: { required: true, min: 0, max: 100 }
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country3ValueOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Values in (000\'s)',
          format: 'N1',
          width: 140,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          allowEditing: false,
          // valueAccessor: this.validationService.calculateSpiltValue,
        }
      ],
      consumptionCountry4Columns: [
        {
           clipMode: 'EllipsisWithTooltip',
          field: 'Country4Id',
          headerTextAlign: 'Left',
          headerText: '',
          width: 180,
          textAlign: 'Left',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          allowEditing: false,
          validationRules: { required: true },
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country4PercentageOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Split in (%)',
          width: 100,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          format: 'P2',
          showInColumnChooser: false,
          editType: 'numericedit',
          edit: this.noDecimalParams,
          customAttributes: { class: 'editCell' },
          validationRules: { required: true, min: 0, max: 100 }
        },
        {
           clipMode: 'EllipsisWithTooltip', field: 'Country4ValueOfConsumption',
          headerTextAlign: 'Left',
          headerText: 'Values in (000\'s)',
          format: 'N1',
          width: 140,
          textAlign: 'Right',
          minWidth: 10,
          allowFiltering: false,
          allowSorting: true,
          showInColumnChooser: false,
          allowEditing: false,
          // valueAccessor: this.validationService.calculateSpiltValue,
        }
      ]
    }
  }
};
