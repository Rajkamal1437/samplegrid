import { Component, OnInit, ViewChild } from '@angular/core';
import { IEditCell, ColumnModel, parentsUntil } from '@syncfusion/ej2-angular-grids';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { PercentPipe } from '@angular/common';
import { SharedConstant } from '../shared-constant.config';
import { Internationalization } from '@syncfusion/ej2-base';
import { countriesData } from '../data-source';

@Injectable({
  providedIn: 'root',
})
export class ValidationService implements OnInit {
  //countries
  public Countries = countriesData;
  // Stacked Header
  public rowSummaryColumns: ColumnModel[];
  public consumptionCountry1Columns: ColumnModel[];
  public consumptionCountry2Columns: ColumnModel[];
  public consumptionCountry3Columns: ColumnModel[];
  public consumptionCountry4Columns: ColumnModel[];

  // filter
  public countryElem: HTMLElement;
  public countryObj: DropDownList;

  constructor(
    private percentPipe: PercentPipe) {

  }

  /**
   * @name calculateSales
   * @param totalSales total Sales value of the Year ( Current Year / Previous Year / Previous Year Refresh )
   * @param currentSales Sales value of the Brand( IFF, Firmenich, Givaudan, Symrise, Takasago, Others) 
   * of that year ( Current Year / Previous Year / Previous Year Refresh )
   */
  public static calculateSales(totalSales, currentSales) {
    return totalSales * currentSales / 100;
  }

  /**
   * @name getValueAccessorData
   * @param field name of the column field
   * @param input will contain the entire row data as object
   * @param column will have the array of objects of all columns
   */
  getValueAccessorData(field: string, input, column: Object): any {
    let currentYearSalesTotal = parseFloat(input['FirmenichCurrentYearSales'] || 0) +
      parseFloat(input['IFFCurrentYearSales'] || 0) +
      parseFloat(input['GivaudanCurrentYearSales'] || 0) +
      parseFloat(input['SymriseCurrentYearSales'] || 0) +
      parseFloat(input['TakasagoCurrentYearSales'] || 0) +
      parseFloat(input['OthersCurrentYearSales'] || 0);
    let previousYearSalesTotal = parseFloat(input['IFFPreviousYearSales'] || 0) +
      parseFloat(input['FirmenichPreviousYearSales'] || 0) +
      parseFloat(input['GivaudanPreviousYearSales'] || 0) +
      parseFloat(input['SymrisePreviousYearSales'] || 0) +
      parseFloat(input['TakasagoPreviousYearSales'] || 0) +
      parseFloat(input['OthersPreviousYearSales'] || 0);

    let previousYearRefreshSalesTotal = parseFloat(input['IFFPreviousYearRefreshSales'] || 0) +
      parseFloat(input['FirmenichPreviousYearRefreshSales'] || 0) +
      parseFloat(input['GivaudanPreviousYearRefreshSales'] || 0) +
      parseFloat(input['SymrisePreviousYearRefreshSales'] || 0) +
      parseFloat(input['TakasagoPreviousYearRefreshSales'] || 0) +
      parseFloat(input['OthersPreviousYearRefreshSales'] || 0);

    let currentYearEncapTotal = parseFloat(input['IFFCurrentYearEncapsulation'] || 0) +
      parseFloat(input['FirmenichCurrentYearEncapsulation'] || 0) +
      parseFloat(input['GivaudanCurrentYearEncapsulation'] || 0) +
      parseFloat(input['SymriseCurrentYearEncapsulation'] || 0) +
      parseFloat(input['TakasagoCurrentYearEncapsulation'] || 0) +
      parseFloat(input['OthersCurrentYearEncapsulation'] || 0);
    let previousYearEncapTotal = parseFloat(input['IFFPreviousYearEncapsulation'] || 0) +
      parseFloat(input['FirmenichPreviousYearEncapsulation'] || 0) +
      parseFloat(input['GivaudanPreviousYearEncapsulation'] || 0) +
      parseFloat(input['SymrisePreviousYearEncapsulation'] || 0) +
      parseFloat(input['TakasagoPreviousYearEncapsulation'] || 0) +
      parseFloat(input['OthersPreviousYearEncapsulation'] || 0);

    let previousYearRefreshEncapTotal = parseFloat(input['IFFPreviousYearRefreshEncapsulation'] || 0) +
      parseFloat(input['FirmenichPreviousYearRefreshEncapsulation'] || 0) +
      parseFloat(input['GivaudanPreviousYearRefreshEncapsulation'] || 0) +
      parseFloat(input['SymrisePreviousYearRefreshEncapsulation'] || 0) +
      parseFloat(input['TakasagoPreviousYearRefreshEncapsulation'] || 0) +
      parseFloat(input['OthersPreviousYearRefreshEncapsulation'] || 0);

    if (field && input && column) {
      switch (field) {
        case SharedConstant.IFF_CURRENTYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, currentYearSalesTotal, (parseFloat(input['IFFCurrentYearAvailability'])));
        }
        case SharedConstant.IFF_PREVIOUSYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, previousYearSalesTotal, (parseFloat(input['IFFPreviousYearAvailability'])));
        }
        case SharedConstant.FIRMENICH_CURRENTYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, currentYearSalesTotal, (parseFloat(input['FirmenichCurrentYearAvailability'])));
        }
        case SharedConstant.FIRMENICH_PREVIOUSYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, previousYearRefreshSalesTotal, (parseFloat(input['FirmenichPreviousYearAvailability'])));
        }
        case SharedConstant.GIVAUDAN_CURRENTYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, currentYearSalesTotal, (parseFloat(input['GivaudanCurrentYearAvailability'])));
        }
        case SharedConstant.GIVAUDAN_PREVIOUSYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, previousYearRefreshSalesTotal, (parseFloat(input['GivaudanPreviousYearAvailability'])));
        }
        case SharedConstant.SYMRISE_CURRENTYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, currentYearSalesTotal, (parseFloat(input['SymriseCurrentYearAvailability'])));
        }
        case SharedConstant.SYMRISE_PREVIOUSYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, previousYearRefreshSalesTotal, (parseFloat(input['SymrisePreviousYearAvailability'])));
        }
        case SharedConstant.TAKASAGO_CURRENTYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, currentYearSalesTotal, (parseFloat(input['TakasagoCurrentYearAvailability'])));
        }
        case SharedConstant.TAKASAGO_PREVIOUSYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, previousYearRefreshSalesTotal, (parseFloat(input['TakasagoPreviousYearAvailability'])));
        }
        case SharedConstant.OTHERS_CURRENTYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, currentYearSalesTotal, (parseFloat(input['OthersCurrentYearAvailability'])));
        }
        case SharedConstant.OTHERS_PREVIOUSYEAR_AVAILABILITY_SALES: {
          return ValidationService.calculateSales.call(this, previousYearRefreshSalesTotal, (parseFloat(input['OthersPreviousYearAvailability'])));
        }
        case SharedConstant.TOTAL_CURRENTYEAR_SALES:
        case SharedConstant.IFF_CURRENTYEAR_TOTALPOTENTIAL:
        case SharedConstant.FIRMENICH_CURRENTYEAR_TOTALPOTENTIAL:
        case SharedConstant.GIVAUDAN_CURRENTYEAR_TOTALPOTENTIAL:
        case SharedConstant.SYMRISE_CURRENTYEAR_TOTALPOTENTIAL:
        case SharedConstant.TAKASAGO_CURRENTYEAR_TOTALPOTENTIAL:
        case SharedConstant.OTHERS_CURRENTYEAR_TOTALPOTENTIAL: {
          return currentYearSalesTotal !== 0 ? currentYearSalesTotal : 0;
        }
        case SharedConstant.TOTAL_PREVIOUSYEAR_REFRESH_SALES:
        case SharedConstant.IFF_PREVIOUSYEAR_TOTALPOTENTIAL:
        case SharedConstant.FIRMENICH_PREVIOUSYEAR_TOTALPOTENTIAL:
        case SharedConstant.GIVAUDAN_PREVIOUSYEAR_TOTALPOTENTIAL:
        case SharedConstant.SYMRISE_PREVIOUSYEAR_TOTALPOTENTIAL:
        case SharedConstant.TAKASAGO_PREVIOUSYEAR_TOTALPOTENTIAL:
        case SharedConstant.OTHERS_PREVIOUSYEAR_TOTALPOTENTIAL: {
          return previousYearRefreshSalesTotal !== 0 ? previousYearRefreshSalesTotal : 0;
        }
        case SharedConstant.TOTAL_PREVIOUSYEAR_SALES: {
          return previousYearSalesTotal !== 0 ? previousYearSalesTotal : 0;
        }
        case SharedConstant.IFF_CURRENTYEAR_MARKETPOTENTIAL:
        case SharedConstant.IFF_TOTAL_CONSUMPTION: {
          return parseFloat(input['IFFCurrentYearSales'] || 0);
        }
        case SharedConstant.FIRMENICH_CURRENTYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['FirmenichCurrentYearSales'] || 0);
        }
        case SharedConstant.GIVAUDAN_CURRENTYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['GivaudanCurrentYearSales'] || 0);
        }
        case SharedConstant.SYMRISE_CURRENTYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['SymriseCurrentYearSales'] || 0);
        }
        case SharedConstant.TAKASAGO_CURRENTYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['TakasagoCurrentYearSales'] || 0);
        }
        case SharedConstant.OTHERS_CURRENTYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['OthersCurrentYearSales'] || 0);
        }
        case SharedConstant.IFF_PREVIOUSYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['IFFPreviousYearSales'] || 0);
        }
        case SharedConstant.FIRMENICH_PREVIOUSYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['FirmenichPreviousYearSales'] || 0);
        }
        case SharedConstant.GIVAUDAN_PREVIOUSYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['GivaudanPreviousYearSales'] || 0);
        }
        case SharedConstant.SYMRISE_PREVIOUSYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['SymrisePreviousYearSales'] || 0);
        }
        case SharedConstant.TAKASAGO_PREVIOUSYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['TakasagoPreviousYearSales'] || 0);
        }
        case SharedConstant.OTHERS_PREVIOUSYEAR_MARKETPOTENTIAL: {
          return parseFloat(input['OthersPreviousYearSales'] || 0);
        }
        case SharedConstant.IFF_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL: {
          return parseFloat(input['IFFPreviousYearRefreshSales'] || 0);
        }
        case SharedConstant.FIRMENICH_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL: {
          return parseFloat(input['FirmenichPreviousYearRefreshSales'] || 0);
        }
        case SharedConstant.GIVAUDAN_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL: {
          return parseFloat(input['GivaudanPreviousYearRefreshSales'] || 0);
        }
        case SharedConstant.SYMRISE_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL: {
          return parseFloat(input['SymrisePreviousYearRefreshSales'] || 0);
        }
        case SharedConstant.TAKASAGO_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL: {
          return parseFloat(input['TakasagoPreviousYearRefreshSales'] || 0);
        }
        case SharedConstant.OTHERS_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL: {
          return parseFloat(input['OthersPreviousYearRefreshSales'] || 0);
        }
        case SharedConstant.TOTAL_CURYEAR_ENCAP: {
          return Number(currentYearEncapTotal.toFixed(0));
        }
        case SharedConstant.TOTAL_PREVYEAR_ENCAP: {
          return  Number(previousYearEncapTotal.toFixed(0));
        }
        case SharedConstant.TOTAL_PREVYEARREF_ENCAP: {
          return  Number(previousYearRefreshEncapTotal.toFixed(0));
        }
      }
    } else {
      return 0;
    }

  }
  public countryNameFromCode = (field: string, input, column: Object) => {
    if (input && input[field]) {
      return this.getCountryName(input[field]);
    }
  }

  public getCountryName(countryCode) {
    return countryCode.toLowerCase() !== 'others'
      ? (countriesData.find((c: any) => c.countrycode.toLowerCase() === countryCode.toLowerCase()) as any).countryname
      : 'Others';
  }
  public getRowTotalPercent(field: string, input, column: Object): number {
    return parseFloat(input['Country1PercentageOfConsumption'] || 0) +
      parseFloat(input['Country2PercentageOfConsumption'] || 0) +
      parseFloat(input['Country3PercentageOfConsumption'] || 0) +
      parseFloat(input['Country4PercentageOfConsumption'] || 0);
  }
  public customFn: (args: { [key: string]: string }) => boolean = (args: { [key: string]: string }) => {
    let value = parseInt(args['value'], 10);
    return value !== null && value !== undefined && value !== 0;
  }

  public percentFn: (args: { [key: string]: string }) => boolean = (args: { [key: string]: string }) => {
    return parseInt(args['value'], 10) >= 0 && parseInt(args['value'], 10) <= 100;
  }
  public calculateSpiltValue(field: string, input, column: Object): number {
    if ('Country1ValueOfConsumption' === field && input['Country1PercentageOfConsumption']) {
      return Number((input['IFFCurrentYearSales'] * (input['Country1PercentageOfConsumption'] / 100)).toFixed(2));
    } else if ('Country2ValueOfConsumption' === field && input['Country2PercentageOfConsumption']) {
      return Number((input['IFFCurrentYearSales'] * (input['Country2PercentageOfConsumption'] / 100)).toFixed(2));
    } else if ('Country3ValueOfConsumption' === field && input['Country3PercentageOfConsumption']) {
      return Number((input['IFFCurrentYearSales'] * (input['Country3PercentageOfConsumption'] / 100)).toFixed(2));
    } else if ('Country4ValueOfConsumption' === field && input['Country4PercentageOfConsumption']) {
      return Number((input['IFFCurrentYearSales'] * (input['Country4PercentageOfConsumption'] / 100)).toFixed(2));
    } else {
      return 0;
    }
  }

  getCurrentDosageCPT(field: string, input, column: any): number {
    if (input) {
      let exwPrice = parseFloat(input['CurrentCspExw'] || 0);
      let dosage = parseFloat(input['CurrentDosage'] || 0);
      let result = Number((Number(exwPrice) * (Number(dosage) / 100) * 1000).toFixed(2));
      // let intl: Internationalization = new Internationalization();
      // let nFormatter: Function = intl.getNumberFormat({ format: column.format, currency: 'USD' });
      // return nFormatter(result)
      return result;
    }
    else {
      return null;
    }
  }

  getPrevDosageCPT(field: string, input, column: any): number {
    if (input) {
      let exwPrice = parseFloat(input['PrevCspExw'] || 0);
      let dosage = parseFloat(input['PrevDosage'] || 0);
      let result = Number((Number(exwPrice) * (Number(dosage) / 100) * 1000).toFixed(2));
      // let intl: Internationalization = new Internationalization();
      // let nFormatter: Function = intl.getNumberFormat({ format: column.format, currency: 'USD' });
      // return Number(nFormatter(result));
      return result;
    }
    else {
      return null;
    }
  }

  getFormattedMarketShare(yearlySales: number, totalYearSales: number) {
    let marketShareValue = this.getMarketShare(yearlySales, totalYearSales);
    return isNaN(marketShareValue) ? 'NA' : marketShareValue;
  }
  public getMarketShare(yearlySales: number, totalYearSales: number): number {
    let marketShare = Number(yearlySales) / Number(totalYearSales);
    return isFinite(marketShare) ? marketShare : null;
  }

  public validateCurYearEncap: (args: { [key: string]: string }) => boolean = (args: { [key: string]: string }) => {
    if (document.getElementById('grid')) {
      var rData = parentsUntil((args as any).element, 'e-rowcell');
      let gridInst: any = (<any>document.getElementById('grid')).ej2_instances[0].getRowObjectFromUID(rData.parentElement.getAttribute('data-uid')).data;
      let fieldName = args.element['name'];
      switch (fieldName) {
        // IFFCurrentYearEncapsulation
        case 'IFFCurrentYearEncapsulation': {
          if (gridInst.IFFCurrentYearSales >= args.value && gridInst.IFFCurrentYearSales >= 0) {
            return true;
          }else if(gridInst.IFFCurrentYearSales < 0 && args.value == '0'){
            return true;
          } else {
            return false;
          }
        }
        //IFFPreviousYearRefreshEncapsulation
        case 'IFFPreviousYearRefreshEncapsulation': {
            if (gridInst.IFFPreviousYearRefreshSales >= args.value && gridInst.IFFPreviousYearRefreshSales >= 0) {
              return true;
            }else if(gridInst.IFFPreviousYearRefreshSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
        //FirmenichCurrentYearEncapsulation
        case 'FirmenichCurrentYearEncapsulation': {
            if (gridInst.FirmenichCurrentYearSales >= args.value && gridInst.FirmenichCurrentYearSales >= 0) {
              return true;
            }else if(gridInst.FirmenichCurrentYearSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
        //FirmenichPreviousYearRefreshEncapsulation 
        case 'FirmenichPreviousYearRefreshEncapsulation': {
            if (gridInst.FirmenichPreviousYearRefreshSales >= args.value && gridInst.FirmenichPreviousYearRefreshSales >= 0) {
              return true;
            }else if(gridInst.FirmenichPreviousYearRefreshSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
        //GivaudanCurrentYearEncapsulation
        case 'GivaudanCurrentYearEncapsulation': {
            if (gridInst.GivaudanCurrentYearSales >= args.value && gridInst.GivaudanCurrentYearSales >= 0) {
              return true;
            }else if(gridInst.GivaudanCurrentYearSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
        //GivaudanPreviousYearRefreshEncapsulation
        case 'GivaudanPreviousYearRefreshEncapsulation': {
            if (gridInst.GivaudanPreviousYearRefreshSales >= args.value && gridInst.GivaudanPreviousYearRefreshSales >= 0) {
              return true;
            }else if(gridInst.GivaudanPreviousYearRefreshSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
        //SymriseCurrentYearEncapsulation
        case 'SymriseCurrentYearEncapsulation': {
            if (gridInst.SymriseCurrentYearSales >= args.value && gridInst.SymriseCurrentYearSales >= 0) {
              return true;
            }else if(gridInst.SymriseCurrentYearSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }

        }
        //SymrisePreviousYearRefreshEncapsulation
        case 'SymrisePreviousYearRefreshEncapsulation': {
            if (gridInst.SymrisePreviousYearRefreshSales >= args.value && gridInst.SymrisePreviousYearRefreshSales >= 0) {
              return true;
            }else if(gridInst.SymrisePreviousYearRefreshSales < 0 && args.value == '0'){
            return true;
          } else {
            return false;
          }
        }
        // TakasagoCurrentYearEncapsulation
        case 'TakasagoCurrentYearEncapsulation': {
            if (gridInst.TakasagoCurrentYearSales >= args.value && gridInst.TakasagoCurrentYearSales >= 0) {
              return true;
            }else if(gridInst.TakasagoCurrentYearSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
        //TakasagoPreviousYearRefreshEncapsulation
        case 'TakasagoPreviousYearRefreshEncapsulation': {
        if (gridInst.TakasagoPreviousYearRefreshSales >= args.value && gridInst.TakasagoPreviousYearRefreshSales >= 0) {
              return true;
            }else if(gridInst.TakasagoPreviousYearRefreshSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }

        //OthersCurrentYearEncapsulation
        case 'OthersCurrentYearEncapsulation': {
            if (gridInst.OthersCurrentYearSales >= args.value && gridInst.OthersCurrentYearSales >= 0) {
              return true;
            }else if(gridInst.OthersCurrentYearSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
        //OthersPreviousYearRefreshEncapsulation
        case 'OthersPreviousYearRefreshEncapsulation': {
            if (gridInst.OthersPreviousYearRefreshSales >= args.value && gridInst.OthersPreviousYearRefreshSales >= 0) {
              return true;
            }else if(gridInst.OthersPreviousYearRefreshSales < 0 && args.value == '0'){
              return true;
            } else {
              return false;
            }
        }
      }
    } else {
      return false;
    }
  }
  ngOnInit() {

  }
}