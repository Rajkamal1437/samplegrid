import { Component, OnInit, ViewChild } from '@angular/core';
import {
  EditSettingsModel, ToolbarItems, IEditCell, GridComponent, VirtualScrollService,
  FreezeService, FilterService, PageSettingsModel, FilterSettingsModel, TextWrapSettingsModel,
  ToolbarService, ColumnChooserService, PageService, EditService, Group, GroupSettingsModel, parentsUntil
} from '@syncfusion/ej2-angular-grids';
import { Router } from '@angular/router';
import { TaskBulkEntryCloumns } from './task-bulk-entry-columns';
import { ToastrService } from 'ngx-toastr';
import { QueryCellInfoEventArgs, ResizeService } from '@syncfusion/ej2-angular-grids';
import { MatDialog } from '@angular/material';
import { AggregateCalculationService } from './aggregate-calculation.service';
import { Internationalization } from '@syncfusion/ej2-base';
import { RadioButton, Switch } from "@syncfusion/ej2-buttons";
import { PercentPipe } from '@angular/common';
import { isNullOrUndefined } from 'util';
import { TaskStatus } from '../task-status.enum';
import { countriesData, productData } from '../data-source';


@Component({
  selector: 'app-ejsgrid',
  templateUrl: './ejsgrid.component.html',
  styleUrls: ['./ejsgrid.component.scss'],
  // providers: [ToolbarService, EditService, PageService]
  providers: [TaskBulkEntryCloumns, FreezeService, VirtualScrollService, FilterService, ToolbarService, ColumnChooserService, PageService, EditService, ResizeService],
})

export class EjsgridComponent implements OnInit {

  // Grid settings
  @ViewChild('grid')
  public grid: GridComponent;
  public TextWrapSettings: TextWrapSettingsModel;
  public pageSettings: PageSettingsModel;
  public toolbarOptions: ToolbarItems[];
  public editSettings: EditSettingsModel;
  public filterOptions: FilterSettingsModel;
  public groupSettings: any;
  public sortOptions: Object;
  public columns = {
    TotalSale: [],
    salesIFF: [],
    salesFirmenich: [],
    salesGivaudan: [],
    salesSymrise: [],
    salesTakasago: [],
    salesMane: [],
    salesOthers: [],
    CurYearDosage: [],
    PrevYearDosage: [],
    AvailablityCurYearIFF: [],
    AvailablityPrevYearIFF: [],
    AvailablityCurYearFirmenich: [],
    AvailablityPrevYearFirmenich: [],
    AvailablityCurYearGivaudan: [],
    AvailablityPrevYearGivaudan: [],
    AvailablityCurYearSymrise: [],
    AvailablityPrevYearSymrise: [],
    AvailablityCurYearTakasago: [],
    AvailablityPrevYearTakasago: [],
    AvailablityCurYearMane: [],
    AvailablityPrevYearMane: [],
    AvailablityCurYearOthers: [],
    AvailablityPrevYearOthers: [],
    TotalEncap: [],
    IFFENCAPCurrYear: [],
    IFFENCAPPrevYear: [],
    IFFENCAPPrevYearRef: [],
    FirmenichENCAPCurrYear: [],
    FirmenichENCAPPrevYear: [],
    FirmenichENCAPPrevYearRef: [],
    GivaudanENCAPCurrYear: [],
    GivaudanENCAPPrevYear: [],
    GivaudanENCAPPrevYearRef: [],

    SymriseENCAPCurrYear: [],
    SymriseENCAPPrevYear: [],
    SymriseENCAPPrevYearRef: [],

    TakasagoENCAPCurrYear: [],
    TakasagoENCAPPrevYear: [],
    TakasagoENCAPPrevYearRef: [],

    OthersENCAPCurrYear: [],
    OthersENCAPPrevYear: [],
    OthersENCAPPrevYearRef: [],
    rowSummaryColumns: [],
    consumptionCountry1Columns: [],
    consumptionCountry2Columns: [],
    consumptionCountry3Columns: [],
    consumptionCountry4Columns: []
  };
  public initialGridLoad = true;
  public externalValue = 100;
  public updatedRecords = [];

  public userInfo: any = {};
  public currentYear = null;
  public bulkIds = [1212, 121212, 12121];
  public Taskdata: any = [];
  public MPTabShowCol = [];
  public MPTabHideCol = [];

  public eCellBorderAll = { class: 'aggregateAllBorders' };

  TabSelectionSettings = {
    CurrentSelection: 'Potential',
    Potential: {
      Start: 8,
      End: 37
    },
    Availability: {
      Start: 38,
      End: 79
    },
    Encapsulation: {
      Start: 80,
      End: 118
    },
    Consumption: {
      Start: 119,
      End: 132
    }
  };

  // test
  public data: Object[];
  batchData: any;
  public dueDate: Date;
  public updatePayload: any = [];
  public elem: any;
  public iObj: any;
  public iObj3: any;
  public dpParams: IEditCell;
  public cTemplate: any = "#ColTemplate";
  public isVaildMPTab = [];
  public isVaildBATab = [];
  public isVaildMETab = [];
  public isVaildCCTab = [];
  public isFF = false;
  public hasUnsavedChanges = false;
  public isValidationEdit = false;

  constructor(
    private columnsService: TaskBulkEntryCloumns,
    private router: Router,
    // private appBroadCast: AppBroadCast,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private percentPipe: PercentPipe,
    public aggregateCalculation: AggregateCalculationService) {
    //get Grid Data
    this.data = productData;
    this.isValidationEdit = false;
    if (!this.bulkIds) {
      this.toastr.error('Please select tasks.');
      this.router.navigate(['/commercial']);
    }
    this.userInfo = {
      AlreadyLoggedIn: true,
      CurrentYear: 2019,
      DepartmentId: 3,
      DepartmentName: "Sales",
      DisplayName: "Rajkamal Mahadevan",
      DueDate: "2019-11-15T00:00:00.000Z",
      Email: "RAJKAMAL.MAHADEVAN@IFF.COM",
      ExportInProgress: false,
      Id: "rxm0095",
      IsAcquisitionDone: true,
      IsBWImported: false,
      IsCommercialCompleted: false,
      IsMarketingCompleted: true,
      IsTaskCreated: true,
      IsValidationCompleted: false,
      IsYearCompleted: false,
      Location: "IT",
      SettingId: 4,
      Status: 1,
      SubmittedOn: null
    }
    this.currentYear = this.userInfo.CurrentYear;
    this.dueDate = this.userInfo.DueDate;

    // Initialize grid configurations
    this.editSettings = { showConfirmDialog: false, allowEditing: true, mode: 'Batch' };
    this.TextWrapSettings = { wrapMode: 'Header' };
    this.filterOptions = { type: 'CheckBox' };
    this.pageSettings = { pageSizes: ["5", "10", '25', '50', '100', "All"], pageSize: 10 };
    this.toolbarOptions = ['ColumnChooser'];
    this.groupSettings = { disablePageWiseAggregates: true };
    this.sortOptions = { columns: [{ field: 'Country', direction: 'Ascending' }] };
  }
  public selectedTabIndex(e) {
    if (e == 0) {
      this.onTabSelectionChange('Potential');
    } else if (e == 1) {
      this.onTabSelectionChange('Availability');
    } else if (e == 2) {
      this.onTabSelectionChange('Encapsulation');
    } else if (e == 3) {
      this.onTabSelectionChange('Consumption');
    } else {
      this.onTabSelectionChange('Potential');
    }
  }
  public actionComplete = (args) => {
    if (args.requestType === "filterchoicerequest") {
      let filterColumns = ['PrevDosage', 'CurrentDosage', 'IFFCurrentYearAvailability', 'IFFPreviousYearAvailability', 'FirmenichCurrentYearAvailability', 'FirmenichPreviousYearAvailability', 'GivaudanCurrentYearAvailability', 'GivaudanPreviousYearAvailability', 'SymriseCurrentYearAvailability', 'SymrisePreviousYearAvailability', 'TakasagoCurrentYearAvailability', 'TakasagoPreviousYearAvailability', 'ManeCurrentYearAvailability', 'ManePreviousYearAvailability', 'OthersCurrentYearAvailability', 'OthersPreviousYearAvailability', 'Country1PercentageOfConsumption', 'Country2PercentageOfConsumption', 'Country3PercentageOfConsumption', 'Country4PercentageOfConsumption'];
      filterColumns.forEach(element => {
        this.grid.getColumnByField(element).getFilterItemTemplate = () => { return undefined };
      });
    }

    if (args.requestType === "columnstate") {
      setTimeout(() => {
        this.aggregateTextFormat();
        this.updateAggregateFieldsDOM();
      }, 100)
    }
  }
  public actionBegin = (args) => {
    if (args.requestType && (args.requestType === "paging" || args.requestType === "sorting" || args.requestType === "filtering")) {
      this.prepareCommercialTasks(false);
    }
  }
  public cellEdit(args) {
    if (args.columnName !== 'Country2PercentageOfConsumption' ||
      args.columnName !== 'Country3PercentageOfConsumption' ||
      args.columnName !== 'Country1PercentageOfConsumption') {
      args.cell.classList.remove('editCell');
    }
    if (args.columnName === 'Country2PercentageOfConsumption') {
      if (args.rowData['Country2Id']) {
        args.cell.classList.remove('editCell');
      } else {
        args.cancel = true;
      }
    }

    if (args.columnName === 'Country3PercentageOfConsumption') {
      if (args.rowData['Country3Id']) {
        args.cell.classList.remove('editCell');
      } else {
        args.cancel = true;
      }
    }

    if (args.columnName === 'Country1PercentageOfConsumption') {
      if (args.rowData['Country1Id']) {
        args.cell.classList.remove('editCell');
      } else {
        args.cancel = true;
      }
    }

  }

  public keypress1(args) {
    if (args.keyCode === 13) {
      this.keypress(args);
    }
  }

  public keypress(args) {
    if (args.keyCode == 187) {
      this.prepareCommercialTasks(false);
    }
    if (args.keyCode == 13) {
      // console.log('keypress Triggered', new Date().toString());
      args.cancel = true;
      args.preventDefault();
      args.stopImmediatePropagation();
      var cellDetails = (this.grid.editModule as any).editModule.cellDetails;
      this.grid.saveCell();
      // console.log('saveCell Triggered', new Date().toString());
      this.grid.editCell((cellDetails.rowIndex + 1), this.grid.getColumnByIndex(cellDetails.cellIndex).field);
      setTimeout(() => {
        // console.log('InsideTimeout Triggered', new Date().toString());
        (this.grid.editModule.formObj.element.querySelector('input.e-field') as any).select();
      }, 100);
    }
    if (args.keyCode == 9 && this.grid.isEdit == true) {
      args.cancel = true;
      args.preventDefault();
      var cellDetails = (this.grid.editModule as any).editModule.cellDetails;
      this.grid.saveCell();
      var nextIndex = (this.grid.editModule as any).editModule.findNextEditableCell(cellDetails.cellIndex + 1, false);

      this.grid.editCell((cellDetails.rowIndex), this.grid.getColumnByIndex(nextIndex).field);
      (this.grid.editModule.formObj.element.querySelector('input.e-field') as any).select();
    }
  }
  public cellSaved(args) {
    if (args.columnName !== "IsPrivate") {
      args.cell.classList.add('editCell');
    }
    if (args.columnName == "IsPrivate") {
      args.rowData["IsPrivate"] = args.value;
      var params = { cell: args.cell, column: args.columnObject, data: args.rowData };
      this.customiseCell(params);
    }
    let percentFields = ['RowPercentage', 'PrevDosage', 'CurrentDosage', 'IFFCurrentYearAvailability', 'IFFPreviousYearAvailability', 'FirmenichCurrentYearAvailability', 'FirmenichPreviousYearAvailability', 'GivaudanCurrentYearAvailability', 'GivaudanPreviousYearAvailability', 'SymriseCurrentYearAvailability', 'SymrisePreviousYearAvailability', 'TakasagoCurrentYearAvailability', 'TakasagoPreviousYearAvailability', 'ManeCurrentYearAvailability', 'ManePreviousYearAvailability', 'OthersCurrentYearAvailability', 'OthersPreviousYearAvailability', 'Country1PercentageOfConsumption', 'Country2PercentageOfConsumption', 'Country3PercentageOfConsumption', 'Country4PercentageOfConsumption'];
    if (args.columnName && (percentFields.includes(args.columnName) === true)) {
      // let num = this.getFormat(args.value);
      args.cell.innerText = args.value + ' %';
    }
    setTimeout(() => {
      this.validateRecords(args, true);
      this.aggregateTextFormat();
      this.updateAggregateFieldsDOM();
      // this.prepareCommercialTasks(false);
    }, 100)
    //  autoFitColumns([fieldname]);

  }

  getFormat(data: any) {
    const intl: Internationalization = new Internationalization();
    const nFormatter = intl.formatNumber(data, { format: " 0 '%'" });
    return nFormatter;
  }
  ngOnInit() {
    this.dpParams = {
      create: () => {
        this.elem = document.createElement("input");
        return this.elem;
      },
      read: () => {
        var readval;
        if (this.iObj.checked) {
          readval = true;
        } else {
          readval = false;
        }
        return readval;
      },
      destroy: () => {
        this.iObj.destroy();
        this.iObj3.destroy();
      },
      write: args => {
        let radiovalON = false;
        let radiovalOFF = false;
        if (args.rowData['IsPrivate'] == true) {
          radiovalON = true;
        }
        else {
          radiovalOFF = true;
        }
        var elem2 = document.createElement('input');
        elem2.setAttribute("e-mappinguid", "grid-column3");
        elem2.setAttribute("name", "Status3"); //define name attribute as column name
        elem2.setAttribute("id", "GridStatus3"); // Grid ID + columnname
        //var brelem = document.createElement('br');
        //args.element.parentElement.appendChild(brelem);
        args.element.parentElement.appendChild(elem2);
        var elem3 = document.getElementById('gridIsPrivate');
        elem3.setAttribute("style", "display: initial");
        // render radiobutton in these elements
        this.iObj = new RadioButton({
          label: "Yes",
          checked: radiovalON,
          name: 'radiocol'
        });
        this.iObj.appendTo(this.elem);
        this.iObj3 = new RadioButton({
          label: "No",
          checked: radiovalOFF,
          name: 'radiocol'
        });
        this.iObj3.appendTo(elem2);
      }
    }
    this.columns = this.columnsService.columns(this.currentYear);

    setTimeout(() => {
      this.TabSelectionSettings.CurrentSelection = 'Potential';
      this.processColumnVisibility(this.TabSelectionSettings['Availability'], false);
      this.processColumnVisibility(this.TabSelectionSettings['Encapsulation'], false);
      this.processColumnVisibility(this.TabSelectionSettings['Consumption'], false);
      this.grid.refreshColumns();
      (this.grid as any).freezeRefresh();
    }, 1000);
  }


  onTabSelectionChange(tabName: string) {
    if (this.TabSelectionSettings.CurrentSelection === tabName) {
      return;
    }
    this.prepareCommercialTasks(false);
    this.processColumnVisibility(this.TabSelectionSettings[this.TabSelectionSettings.CurrentSelection], false);
    this.TabSelectionSettings.CurrentSelection = tabName;
    this.processColumnVisibility(this.TabSelectionSettings[this.TabSelectionSettings.CurrentSelection], true);
    this.grid.refreshColumns();
    (this.grid as any).freezeRefresh();
  }

  processColumnVisibility(range: { Start: number, End: number }, toggle: boolean) {
    for (let index = range.Start; index <= range.End; index++) {
      this.grid.getColumnByIndex(index).visible = toggle;
      if (this.isFF) {
        this.grid.getColumnByField('TakasagoCurrentYearSales').visible = false;
        this.grid.getColumnByField('TakasagoPreviousYearSales').visible = false;
        this.grid.getColumnByField('TakasagoPreviousYearRefreshSales').visible = false;
        this.grid.getColumnByField('TakasagoCurrentYearTP').visible = false;
        this.grid.getColumnByField('TakasagoCurrentYearAvailabilitySales').visible = false;
        this.grid.getColumnByField('TakasagoCurrentYearAvailability').visible = false;
        this.grid.getColumnByField('TakasagoPreviousYearTP').visible = false;
        this.grid.getColumnByField('TakasagoPreviousYearAvailabilitySales').visible = false;
        this.grid.getColumnByField('TakasagoPreviousYearAvailability').visible = false;
      }
      else {
        this.grid.getColumnByField('ManeCurrentYearSales').visible = false;
        this.grid.getColumnByField('ManePreviousYearSales').visible = false;
        this.grid.getColumnByField('ManePreviousYearRefreshSales').visible = false;
        this.grid.getColumnByField('ManeCurrentYearTP').visible = false;
        this.grid.getColumnByField('ManeCurrentYearAvailabilitySales').visible = false;
        this.grid.getColumnByField('ManeCurrentYearAvailability').visible = false;
        this.grid.getColumnByField('ManePreviousYearTP').visible = false;
        this.grid.getColumnByField('ManePreviousYearAvailabilitySales').visible = false;
        this.grid.getColumnByField('ManePreviousYearAvailability').visible = false;
      }
    }
  }
  public cellSave(args: any) {
    // let modifiedValue = parseFloat(args.cell.querySelectorAll('input')[1].value) || args.value;
    let modifiedValue = args.value;
    if (modifiedValue !== args.previousValue) {
      this.hasUnsavedChanges = true;
      var uid = args.cell.parentElement.getAttribute('data-uid');
      this.grid.getRowObjectFromUID(uid).data[args.columnName] = modifiedValue;
      args.rowData[args.columnName] = modifiedValue;
      let dataCopy = this.grid.getRowObjectFromUID(uid).data;
      let RefreshValueFields = ['IFFPreviousYearRefreshSales', 'FirmenichPreviousYearRefreshSales', 'GivaudanPreviousYearRefreshSales', 'SymrisePreviousYearRefreshSales', 'TakasagoPreviousYearRefreshSales', 'ManePreviousYearRefreshSales', 'OthersPreviousYearRefreshSales'];
      if (RefreshValueFields.includes(args.columnName)) {
        dataCopy['isRefreshChanged'] = true;
      }

      let currentYearSalesTotal = parseFloat(args.rowData['FirmenichCurrentYearSales'] || 0) +
        parseFloat(args.rowData['IFFCurrentYearSales'] || 0) +
        parseFloat(args.rowData['GivaudanCurrentYearSales'] || 0) +
        parseFloat(args.rowData['SymriseCurrentYearSales'] || 0) +
        parseFloat(args.rowData['TakasagoCurrentYearSales'] || 0) +
        parseFloat(args.rowData['ManeCurrentYearSales'] || 0) +
        parseFloat(args.rowData['OthersCurrentYearSales'] || 0);
      let previousYearSalesTotal = parseFloat(args.rowData['IFFPreviousYearSales'] || 0) +
        parseFloat(args.rowData['FirmenichPreviousYearSales'] || 0) +
        parseFloat(args.rowData['GivaudanPreviousYearSales'] || 0) +
        parseFloat(args.rowData['SymrisePreviousYearSales'] || 0) +
        parseFloat(args.rowData['TakasagoPreviousYearSales'] || 0) +
        parseFloat(args.rowData['ManePreviousYearSales'] || 0) +
        parseFloat(args.rowData['OthersPreviousYearSales'] || 0);

      let previousYearRefreshSalesTotal = parseFloat(args.rowData['IFFPreviousYearRefreshSales'] || 0) +
        parseFloat(args.rowData['FirmenichPreviousYearRefreshSales'] || 0) +
        parseFloat(args.rowData['GivaudanPreviousYearRefreshSales'] || 0) +
        parseFloat(args.rowData['SymrisePreviousYearRefreshSales'] || 0) +
        parseFloat(args.rowData['TakasagoPreviousYearRefreshSales'] || 0) +
        parseFloat(args.rowData['ManePreviousYearRefreshSales'] || 0) +
        parseFloat(args.rowData['OthersPreviousYearRefreshSales'] || 0);

      let currentYearEncapTotal = parseFloat(args.rowData['IFFCurrentYearEncapsulation'] || 0) +
        parseFloat(args.rowData['FirmenichCurrentYearEncapsulation'] || 0) +
        parseFloat(args.rowData['GivaudanCurrentYearEncapsulation'] || 0) +
        parseFloat(args.rowData['SymriseCurrentYearEncapsulation'] || 0) +
        parseFloat(args.rowData['TakasagoCurrentYearEncapsulation'] || 0) +
        parseFloat(args.rowData['OthersCurrentYearEncapsulation'] || 0);
      let previousYearEncapTotal = parseFloat(args.rowData['IFFPreviousYearEncapsulation'] || 0) +
        parseFloat(args.rowData['FirmenichPreviousYearEncapsulation'] || 0) +
        parseFloat(args.rowData['GivaudanPreviousYearEncapsulation'] || 0) +
        parseFloat(args.rowData['SymrisePreviousYearEncapsulation'] || 0) +
        parseFloat(args.rowData['TakasagoPreviousYearEncapsulation'] || 0) +
        parseFloat(args.rowData['OthersPreviousYearEncapsulation'] || 0);

      let previousYearRefreshEncapTotal = parseFloat(args.rowData['IFFPreviousYearRefreshEncapsulation'] || 0) +
        parseFloat(args.rowData['FirmenichPreviousYearRefreshEncapsulation'] || 0) +
        parseFloat(args.rowData['GivaudanPreviousYearRefreshEncapsulation'] || 0) +
        parseFloat(args.rowData['SymrisePreviousYearRefreshEncapsulation'] || 0) +
        parseFloat(args.rowData['TakasagoPreviousYearRefreshEncapsulation'] || 0) +
        parseFloat(args.rowData['OthersPreviousYearRefreshEncapsulation'] || 0);

      dataCopy['TotalCurrentYearSales'] = currentYearSalesTotal;
      dataCopy['IFFCurrentYearTP'] = currentYearSalesTotal;
      dataCopy['FirmenichCurrentYearTP'] = currentYearSalesTotal;
      dataCopy['GivaudanCurrentYearTP'] = currentYearSalesTotal;
      dataCopy['SymriseCurrentYearTP'] = currentYearSalesTotal;
      dataCopy['TakasagoCurrentYearTP'] = currentYearSalesTotal;
      dataCopy['ManeCurrentYearTP'] = currentYearSalesTotal;
      dataCopy['OthersCurrentYearTP'] = currentYearSalesTotal;

      dataCopy['TotalPreviousYearRefreshSales'] = previousYearRefreshSalesTotal;
      dataCopy['IFFPreviousYearTP'] = previousYearRefreshSalesTotal;
      dataCopy['FirmenichPreviousYearTP'] = previousYearRefreshSalesTotal;
      dataCopy['GivaudanPreviousYearTP'] = previousYearRefreshSalesTotal;
      dataCopy['SymrisePreviousYearTP'] = previousYearRefreshSalesTotal;
      dataCopy['TakasagoPreviousYearTP'] = previousYearRefreshSalesTotal;
      dataCopy['ManePreviousYearTP'] = previousYearRefreshSalesTotal;
      dataCopy['OthersPreviousYearTP'] = previousYearRefreshSalesTotal;

      dataCopy['IFFCurrentYearSalesMP'] = parseFloat(args.rowData['IFFCurrentYearSales'] || 0);
      dataCopy['IFFTotalConsumption'] = parseFloat(args.rowData['IFFCurrentYearSales'] || 0);
      dataCopy['FirmenichCurrentYearSalesMP'] = parseFloat(args.rowData['FirmenichCurrentYearSales'] || 0);
      dataCopy['GivaudanCurrentYearSalesMP'] = parseFloat(args.rowData['GivaudanCurrentYearSales'] || 0);
      dataCopy['SymriseCurrentYearSalesMP'] = parseFloat(args.rowData['SymriseCurrentYearSales'] || 0);
      dataCopy['TakasagoCurrentYearSalesMP'] = parseFloat(args.rowData['TakasagoCurrentYearSales'] || 0);
      dataCopy['OthersCurrentYearSalesMP'] = parseFloat(args.rowData['OthersCurrentYearSales'] || 0);

      dataCopy['IFFPreviousYearSalesMP'] = parseFloat(args.rowData['IFFPreviousYearSales'] || 0);
      dataCopy['FirmenichPreviousYearSalesMP'] = parseFloat(args.rowData['FirmenichPreviousYearSales'] || 0);
      dataCopy['GivaudanPreviousYearSalesMP'] = parseFloat(args.rowData['GivaudanPreviousYearSales'] || 0);
      dataCopy['SymrisePreviousYearSalesMP'] = parseFloat(args.rowData['SymrisePreviousYearSales'] || 0);
      dataCopy['TakasagoPreviousYearSalesMP'] = parseFloat(args.rowData['TakasagoPreviousYearSales'] || 0);
      dataCopy['OthersPreviousYearSalesMP'] = parseFloat(args.rowData['OthersPreviousYearSales'] || 0);

      dataCopy['IFFPreviousYearRefreshSalesMP'] = parseFloat(args.rowData['IFFPreviousYearRefreshSales'] || 0);
      dataCopy['FirmenichPreviousYearRefreshSalesMP'] = parseFloat(args.rowData['FirmenichPreviousYearRefreshSales'] || 0);
      dataCopy['GivaudanPreviousYearRefreshSalesMP'] = parseFloat(args.rowData['GivaudanPreviousYearRefreshSales'] || 0);
      dataCopy['SymrisePreviousYearRefreshSalesMP'] = parseFloat(args.rowData['SymrisePreviousYearRefreshSales'] || 0);
      dataCopy['TakasagoPreviousYearRefreshSalesMP'] = parseFloat(args.rowData['TakasagoPreviousYearRefreshSales'] || 0);
      dataCopy['OthersPreviousYearRefreshSalesMP'] = parseFloat(args.rowData['OthersPreviousYearRefreshSales'] || 0);

      dataCopy['TotalCurEncap'] = currentYearEncapTotal;
      dataCopy['TotalPrevEncap'] = previousYearEncapTotal;
      dataCopy['TotalPrevRefEncap'] = previousYearRefreshEncapTotal;
      let exwPrice = parseFloat(dataCopy['CurrentCspExw'] || 0);
      let dosage = parseFloat(dataCopy['CurrentDosage'] || 0);
      let exwPrevPrice = parseFloat(dataCopy['PrevCspExw'] || 0);
      let dosagePrev = parseFloat(dataCopy['PrevDosage'] || 0);
      dataCopy['CurrentDosageCPT'] = Number(Number(exwPrice) * (Number(dosage) / 100) * 1000) || 0;
      dataCopy['PrevDosageCPT'] = Number(Number(exwPrevPrice) * (Number(dosagePrev) / 100) * 1000) || 0;

      dataCopy['Country1ValueOfConsumption'] = Number(dataCopy['IFFCurrentYearSales'] * (dataCopy['Country1PercentageOfConsumption'] / 100)) || 0;
      dataCopy['Country2ValueOfConsumption'] = Number(dataCopy['IFFCurrentYearSales'] * (dataCopy['Country2PercentageOfConsumption'] / 100)) || 0;
      dataCopy['Country3ValueOfConsumption'] = Number(dataCopy['IFFCurrentYearSales'] * (dataCopy['Country3PercentageOfConsumption'] / 100)) || 0;
      dataCopy['Country4ValueOfConsumption'] = Number(dataCopy['IFFCurrentYearSales'] * (dataCopy['Country4PercentageOfConsumption'] / 100)) || 0;

      dataCopy['RowPercentage'] = parseFloat(dataCopy['Country1PercentageOfConsumption'] || 0) +
        parseFloat(dataCopy['Country2PercentageOfConsumption'] || 0) +
        parseFloat(dataCopy['Country3PercentageOfConsumption'] || 0) +
        parseFloat(dataCopy['Country4PercentageOfConsumption'] || 0);

      dataCopy["IFFCurrentYearAvailabilitySales"] = this.calculateSales(currentYearSalesTotal, parseFloat(args.rowData['IFFCurrentYearAvailability'] || 0));
      dataCopy["IFFPreviousYearAvailabilitySales"] = this.calculateSales(previousYearSalesTotal, parseFloat(args.rowData['IFFPreviousYearAvailability'] || 0));
      dataCopy["FirmenichCurrentYearAvailabilitySales"] = this.calculateSales(currentYearSalesTotal, parseFloat(args.rowData['FirmenichCurrentYearAvailability'] || 0));
      dataCopy["FirmenichPreviousYearAvailabilitySales"] = this.calculateSales(previousYearRefreshSalesTotal, parseFloat(args.rowData['FirmenichPreviousYearAvailability'] || 0));
      dataCopy["GivaudanCurrentYearAvailabilitySales"] = this.calculateSales(currentYearSalesTotal, parseFloat(args.rowData['GivaudanCurrentYearAvailability'] || 0));
      dataCopy["GivaudanPreviousYearAvailabilitySales"] = this.calculateSales(previousYearRefreshSalesTotal, parseFloat(args.rowData['GivaudanPreviousYearAvailability'] || 0));
      dataCopy["SymriseCurrentYearAvailabilitySales"] = this.calculateSales(currentYearSalesTotal, parseFloat(args.rowData['SymriseCurrentYearAvailability'] || 0));
      dataCopy["SymrisePreviousYearAvailabilitySales"] = this.calculateSales(previousYearRefreshSalesTotal, parseFloat(args.rowData['SymrisePreviousYearAvailability'] || 0));
      dataCopy["TakasagoCurrentYearAvailabilitySales"] = this.calculateSales(currentYearSalesTotal, parseFloat(args.rowData['TakasagoCurrentYearAvailability'] || 0));
      dataCopy["TakasagoPreviousYearAvailabilitySales"] = this.calculateSales(previousYearRefreshSalesTotal, parseFloat(args.rowData['TakasagoPreviousYearAvailability'] || 0));
      dataCopy["ManeCurrentYearAvailabilitySales"] = this.calculateSales(currentYearSalesTotal, parseFloat(args.rowData['ManeCurrentYearAvailability'] || 0));
      dataCopy["ManePreviousYearAvailabilitySales"] = this.calculateSales(previousYearRefreshSalesTotal, parseFloat(args.rowData['ManePreviousYearAvailability'] || 0));
      dataCopy["OthersCurrentYearAvailabilitySales"] = this.calculateSales(currentYearSalesTotal, parseFloat(args.rowData['OthersCurrentYearAvailability'] || 0));
      dataCopy["OthersPreviousYearAvailabilitySales"] = this.calculateSales(previousYearRefreshSalesTotal, parseFloat(args.rowData['OthersPreviousYearAvailability'] || 0));
      this.grid.getRowObjectFromUID(uid).data = dataCopy;
      this.grid.updateRow(parseInt(args.cell.parentElement.getAttribute('aria-rowindex')), this.grid.getRowObjectFromUID(uid).data);
      this.addOrReplace(this.grid.getRowObjectFromUID(uid).data);
    }

    if (args.columnName !== "IsPrivate") {
      args.cell.classList.add('editCell');
    }
    if (args.columnName == "IsPrivate") {
      args.rowData["IsPrivate"] = args.value;
      var params = { cell: args.cell, column: args.columnObject, data: args.rowData };
      this.customiseCell(params);
    }
  }
  /**
   * @name calculateSales
   * @param totalSales total Sales value of the Year ( Current Year / Previous Year / Previous Year Refresh )
   * @param currentSales Sales value of the Brand( IFF, Firmenich, Givaudan, Symrise, Takasago, Mane, Others) 
   * of that year ( Current Year / Previous Year / Previous Year Refresh )
   */
  public calculateSales(totalSales, currentSales) {
    return totalSales * currentSales / 100;
  }

  changeItems(args: any) {
    var elem = document.createElement('span');
    var text = '';
    let getVariableName = Object.keys(args);
    if (getVariableName.length > 0 && args[getVariableName[0]] == "Select All") {
      text = "Select All";
    }
    else {
      const intl: Internationalization = new Internationalization();
      const nFormatter = intl.formatNumber(Number(args.CurrentDosage), { format: " 0 '%'" });
      text = nFormatter;
    }
    elem.innerHTML = text;
    return [elem];
  }
  public openExchangeRateDialog(): void {
    // const createDialogRef = this.dialog.open(ExchangeRateComponent, {
    //   disableClose: true,
    //   width: '1320px'
    // });
    // createDialogRef.afterClosed().subscribe(createDialogResp => {
    // });
  }

  public openShortCutKeys(): void {
    // const createDialogRef = this.dialog.open(ShortcutKeysComponent, {
    //   disableClose: true,
    //   width: '650px'
    // });
    // createDialogRef.afterClosed().subscribe(createDialogResp => {
    // });
  }

  public onBulkSave(isSubmit) {
    // this.appBroadCast.onUpdateAppSpinnerPrompt('Saving record(s)...');
    const body = Object.values(this.prepareCommercialTasks(isSubmit));
    // this.appData.put(this.appData.url.updateBulkTaskDetails, [], body).subscribe(() => {
    //   // this.grid.editModule.batchSave();
    //   this.hasUnsavedChanges = false;
    //   this.appBroadCast.onUpdateAppSpinnerPrompt('');
    //   if (isSubmit) {
    //     this.toastr.success('Task(s) completed successfully', '', { timeOut: 5000 });
    //     this.router.navigate(['/commercial']);
    //   } else {
    //     this.toastr.success('Task(s) drafted successfully', '', { timeOut: 5000 });
    //   }
    // },
    //   (err) => {
    //     this.appBroadCast.onUpdateAppSpinnerPrompt('');
    //     this.toastr.error(err.message);
    //   }
    // );

  }
  private prepareCommercialTasks(isSubmit) {
    this.aggregateCalculation.isAggregateRow2Calculated = false;
    this.aggregateCalculation.isAggregateRow3Calculated = false;
    this.batchData = this.grid.editModule.getBatchChanges();
    this.batchData.changedRecords = this.updatePayload;
    this.grid.editModule.batchSave();
    if (isSubmit == true) {
      this.updatePayload = this.grid.dataSource;

      this.updatePayload.forEach(element => {
        let status;
        if (element.BusinessUnit && element.BusinessUnit.toLowerCase() === 'ff') {
          status = (this.isVaildMPTab.indexOf(element['taskId']) === -1 &&
            this.isVaildBATab.indexOf(element['taskId']) === -1);
        }
        else {
          status = (this.isVaildMPTab.indexOf(element['taskId']) === -1 &&
            this.isVaildBATab.indexOf(element['taskId']) === -1 &&
            this.isVaildMETab.indexOf(element['taskId']) === -1 &&
            this.isVaildCCTab.indexOf(element['taskId']) === -1);
        }
        element['StatusId'] = (isSubmit && status ? TaskStatus.Completed : TaskStatus.Draft);
      });
    }
    return this.updatePayload || [];
  }
  public addOrReplace(rowObject) {
    if (rowObject && rowObject.taskId) {
      this.updatePayload[rowObject.taskId] = rowObject;
    }
  }
  public click(event: any) {
    var cell = parentsUntil((event.target as any), 'e-rowcell');
    setTimeout(() => {
      if (!this.grid.isEdit) {
        if (cell && cell.classList && cell.classList.contains('e-rowcell')) {
          const index: number = parseInt((cell as any).getAttribute('Index'), 10);
          const colindex: number = parseInt((cell as any).getAttribute('aria-colindex'), 10);
          const field: string = this.grid.getColumns()[colindex].field;
          this.grid.editModule.editCell(index, field);
          setTimeout(() => {
            (this.grid.editModule.formObj.element.querySelector('input.e-field') as any).select();
          }, 200);
        }
      }
    }, 100);
  }
  public load(event) {
    let filterColumns = ['PrevDosage', 'CurrentDosage', 'IFFCurrentYearAvailability', 'IFFPreviousYearAvailability', 'FirmenichCurrentYearAvailability', 'FirmenichPreviousYearAvailability', 'GivaudanCurrentYearAvailability', 'GivaudanPreviousYearAvailability', 'SymriseCurrentYearAvailability', 'SymrisePreviousYearAvailability', 'TakasagoCurrentYearAvailability', 'TakasagoPreviousYearAvailability', 'ManeCurrentYearAvailability', 'ManePreviousYearAvailability', 'OthersCurrentYearAvailability', 'OthersPreviousYearAvailability', 'Country1PercentageOfConsumption', 'Country2PercentageOfConsumption', 'Country3PercentageOfConsumption', 'Country4PercentageOfConsumption'];
    filterColumns.forEach((element) => {
      this.grid.getColumnByField(element).getFilterItemTemplate = () => {
        return this.changeItems;
      };
      this.grid.on('filter-menu-close', () => {
        this.grid.getColumnByField(element).getFilterItemTemplate = () => {
          return this.changeItems;
        };
      })
    });
    this.grid.element.addEventListener('keydown', this.keypress1.bind(this));
    // , { passive: true} 
  }
  public dataBound(event) {
    if (this.grid.getFrozenColumns()) {
      (this.grid.element.querySelectorAll('.e-table')[1] as any).style.width = '100%';
      (this.grid.contentModule.getMovableContent().firstElementChild as any).style.width = '100%';
    }
    setTimeout(() => {
      this.aggregateTextFormat();
    }, 100);
  }
  public aggregateTextFormat() {
    var grid = (<any>document.getElementById('grid')).ej2_instances[0];
    var cells = grid.element.querySelectorAll('.e-summarycell:not(.e-hide)');
    for (let i = 0; i < cells.length; i++) {
      if (cells[i]) {
        let id = cells[i].getAttribute('e-mappinguid');
        if (id) {
          cells[i].classList.add(grid.getColumnByUid(id).field);
        }
        cells[i].classList.add("Index" + cells[i].parentElement.rowIndex);
      }
    }
    let footer = grid.element.querySelector('.e-frozenfootercontent');
    let trs = footer.querySelectorAll('tr');
    for (let i = 0; i < trs.length; i++) {
      let len = grid.getHeaderTable().querySelectorAll('.e-headercell:not(.e-hide)').length;
      trs[i].innerHTML = '';
      let td = document.createElement('td');
      td.classList.add('e-summarycell', 'e-footer-text');
      if (this.TabSelectionSettings.CurrentSelection === "Potential") {
        if (i == 0) {
          td.innerHTML = 'Total Potential $ in 000s';
          td.classList.add('e-Total-backgtound');
        } else if (i == 1) {
          td.innerHTML = 'Market Share in %';
        } else if (i == 2) {
          td.innerHTML = 'Growth Rate 2019 vs 2018';
        } else {
          td.innerHTML = '';
        }
      }
      if (this.TabSelectionSettings.CurrentSelection === "Availability") {
        if (i == 0) {
          td.innerHTML = 'Total Availability $ in 000s';
          td.classList.add('e-Total-backgtound');
        } else if (i == 1) {
          td.innerHTML = 'Total Availability in %';
        } else {
          td.innerHTML = '';
        }
      }
      if (this.TabSelectionSettings.CurrentSelection === "Encapsulation") {
        if (i == 0) {
          td.innerHTML = 'Total $ in 000s';
          td.classList.add('e-Total-backgtound');
        } else if (i == 1) {
          td.innerHTML = 'ENCAP % on Total';
        } else if (i == 2) {
          td.innerHTML = 'Market Share %';
        } else {
          td.innerHTML = '';
        }
      }
      if (this.TabSelectionSettings.CurrentSelection === "Consumption") {
        if (i == 0) {
          td.innerHTML = 'Total Consumption $ in 000s';
          td.classList.add('e-Total-backgtound');
        } else {
          td.innerHTML = '';
        }
      }
      td.setAttribute('colspan', len);
      trs[i].appendChild(td);
    }
  }

  /**
   * @name rowLevelIndicator
   * @param args args of cell
   * @param InvalidIds Invalid tab task IDs
   * @param tabName name of the tab
   * @description Cell Customization add valid task css and remove if invalid
   */
  public rowLevelIndicator(args, InvalidIds, tabName) {
    let taskId = args.data['taskId'];
    if (this.TabSelectionSettings.CurrentSelection == tabName && InvalidIds.indexOf(taskId) > -1) {
      if (args.cell.classList.contains('validRow') == true) {
        args.cell.classList.remove('validRow');
      }
    }
    else {
      if (this.TabSelectionSettings.CurrentSelection == tabName && args.cell.classList.contains('validRow') == false) {
        args.cell.classList.add('validRow');
      }
    }
  }

  /**
   * @name customiseCell
   * @param args 
   * @description syncfusion QueryCellInfo event will use this method to Cell Customization
   */
  public customiseCell(args: QueryCellInfoEventArgs) {
    if (args.column.field === "Country") {
      if (this.TabSelectionSettings.CurrentSelection == 'Potential') {
        this.rowLevelIndicator(args, this.isVaildMPTab, 'Potential');
      } else if (this.TabSelectionSettings.CurrentSelection == 'Availability') {
        this.rowLevelIndicator(args, this.isVaildBATab, 'Availability');
      } else if (this.TabSelectionSettings.CurrentSelection == 'Encapsulation') {
        this.rowLevelIndicator(args, this.isVaildMETab, 'Encapsulation');
      } else if (this.TabSelectionSettings.CurrentSelection == 'Consumption') {
        this.rowLevelIndicator(args, this.isVaildCCTab, 'Consumption');
      }
    }
    if (args.column.field == "IsPrivate") {
      //Here, we have bind the Radio in Status column
      let element = args.cell.querySelectorAll('input');
      for (var i = 0; i < element.length; i++) {
        let radioBtn: RadioButton = new RadioButton();
        if (element[i].classList.contains("GridcolYes")) {
          radioBtn.label = "Yes"
          if (args.data["IsPrivate"] == true) {
            radioBtn.checked = true;
          }
        } else if (element[i].classList.contains("GridcolNo")) {
          radioBtn.label = "No"
          if (args.data["IsPrivate"] == false) {
            radioBtn.checked = true;
          }
        }
        radioBtn.disabled = true;
        radioBtn.appendTo(element[i]);
      }
    }
    if (args.column && args.column.field) {
      let columnName = args.column.field;
      this.validateRecords(args, false);
      let percentFields = ['RowPercentage', 'PrevDosage', 'CurrentDosage', 'IFFCurrentYearAvailability', 'IFFPreviousYearAvailability', 'FirmenichCurrentYearAvailability', 'FirmenichPreviousYearAvailability', 'GivaudanCurrentYearAvailability', 'GivaudanPreviousYearAvailability', 'SymriseCurrentYearAvailability', 'SymrisePreviousYearAvailability', 'TakasagoCurrentYearAvailability', 'TakasagoPreviousYearAvailability', 'ManeCurrentYearAvailability', 'ManePreviousYearAvailability', 'OthersCurrentYearAvailability', 'OthersPreviousYearAvailability', 'Country1PercentageOfConsumption', 'Country2PercentageOfConsumption', 'Country3PercentageOfConsumption', 'Country4PercentageOfConsumption'];
      if (args.column.field && (percentFields.includes(columnName) === true)) {
        const intl: Internationalization = new Internationalization();
        let col = args.column.field;
        // const nFormatter = intl.formatNumber(Number((args.data as any)[col]), { format: " 0 '%'" });
        const nFormatter = (args.data as any)[col] !== null ? Number((args.data as any)[col]) + ' %' : '';
        (args.cell as any).innerText = nFormatter;
      }
    }
  }

  public validateEncapFields(args, colName, field) {
    let isValid = false;
    let textContent = (args.data[colName] === null || isNaN(args.data[colName]) === true) ? null : Number(args.data[colName]);
    let potentialValue = Number(args.data[field]);
    if (textContent === null) {
      isValid = false
    }
    else if (args.cell && potentialValue < textContent) {
      if (potentialValue > 0) {
        isValid = false;
      } else if (potentialValue < 0) {
        if (textContent == 0) {
          isValid = true;
        } else {
          isValid = false;
        }
      }
    } else {
      isValid = true;
    }
    return isValid;
  }
  public validateRecords(args, onSave) {
    let columnName = '';
    if (onSave === true) {
      args.data = args.rowData;
      columnName = args.columnName;
    } else {
      columnName = args.column.field;
    }
    // this.data.splice(this.data.indexOf(msg), 1)
    // MP Tab
    let mpSalesValid = true;
    let mpCommentValid = true;
    if ((args.data['FirmenichCurrentYearSales'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true) ||
      (args.data['FirmenichPreviousYearRefreshSales'] == null || isNaN(args.data['FirmenichPreviousYearRefreshSales']) === true) ||
      (args.data['GivaudanCurrentYearSales'] == null || isNaN(args.data['GivaudanCurrentYearSales']) === true) ||
      (args.data['GivaudanPreviousYearRefreshSales'] == null || isNaN(args.data['GivaudanPreviousYearRefreshSales']) === true) ||
      (args.data['SymriseCurrentYearSales'] == null || isNaN(args.data['SymriseCurrentYearSales']) === true) ||
      (args.data['SymrisePreviousYearRefreshSales'] == null || isNaN(args.data['SymrisePreviousYearRefreshSales']) === true) ||
      (args.data['TakasagoCurrentYearSales'] == null || isNaN(args.data['TakasagoCurrentYearSales']) === true) ||
      (args.data['TakasagoPreviousYearRefreshSales'] == null || isNaN(args.data['TakasagoPreviousYearRefreshSales']) === true) ||
      (args.data['ManeCurrentYearSales'] == null || isNaN(args.data['ManeCurrentYearSales']) === true) ||
      (args.data['ManePreviousYearRefreshSales'] == null || isNaN(args.data['ManePreviousYearRefreshSales']) === true) ||
      (args.data['OthersCurrentYearSales'] == null || isNaN(args.data['OthersCurrentYearSales']) === true) ||
      (args.data['OthersPreviousYearRefreshSales'] == null || isNaN(args.data['OthersPreviousYearRefreshSales']) === true)) {
      mpSalesValid = false;
    } else {
      mpSalesValid = true;
    }
    if (args.data['FirmenichPreviousYearRefreshSales'] !== args.data['FirmenichPreviousYearSales'] ||
      args.data['GivaudanPreviousYearRefreshSales'] !== args.data['GivaudanPreviousYearSales'] ||
      args.data['SymrisePreviousYearRefreshSales'] !== args.data['SymrisePreviousYearSales'] ||
      args.data['TakasagoPreviousYearRefreshSales'] !== args.data['TakasagoPreviousYearSales'] ||
      args.data['ManePreviousYearRefreshSales'] !== args.data['ManePreviousYearSales'] ||
      args.data['OthersPreviousYearRefreshSales'] !== args.data['OthersPreviousYearSales']) {
      if (args.data['Comments'] && args.data['Comments'].trim(' ').length > 0) {
        mpCommentValid = true;
      }
      else {
        mpCommentValid = false;
      }
    } else {
      mpCommentValid = true;
    }
    if (mpSalesValid == false || mpCommentValid == false) {
      if (this.isVaildMPTab.indexOf(args.data['taskId']) == -1) {
        this.isVaildMPTab.push(args.data['taskId']);
      }
    }
    else {
      let index = this.isVaildMPTab.indexOf(args.data['taskId']);
      if (index > -1) {
        this.isVaildMPTab.splice(index, 1);
      }
    }

    let isPercentnullBATab = false;
    let isPercentValueValid = false;
    if ((args.data['IFFCurrentYearAvailability'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true) ||
      (args.data['GivaudanCurrentYearAvailability'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true) ||
      (args.data['FirmenichCurrentYearAvailability'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true) ||
      (args.data['SymriseCurrentYearAvailability'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true) ||
      (args.data['TakasagoCurrentYearAvailability'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true) ||
      (args.data['ManeCurrentYearAvailability'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true) ||
      (args.data['OthersCurrentYearAvailability'] == null || isNaN(args.data['FirmenichCurrentYearSales']) === true)) {
      isPercentnullBATab = true;
    } else {
      isPercentnullBATab = false;
    }

    if ((args.data['IFFCurrentYearAvailability'] >= 0 && args.data['IFFCurrentYearAvailability'] <= 100) &&
      (args.data['GivaudanCurrentYearAvailability'] >= 0 && args.data['GivaudanCurrentYearAvailability'] <= 100) &&
      (args.data['FirmenichCurrentYearAvailability'] >= 0 && args.data['FirmenichCurrentYearAvailability'] <= 100) &&
      (args.data['SymriseCurrentYearAvailability'] >= 0 && args.data['SymriseCurrentYearAvailability'] <= 100) &&
      (args.data['TakasagoCurrentYearAvailability'] >= 0 && args.data['TakasagoCurrentYearAvailability'] <= 100) &&
      (args.data['ManeCurrentYearAvailability'] >= 0 && args.data['ManeCurrentYearAvailability'] <= 100) &&
      (args.data['OthersCurrentYearAvailability'] >= 0 && args.data['OthersCurrentYearAvailability'] <= 100)) {
      isPercentValueValid = true;
    }
    else {
      isPercentValueValid = false;
    }

    if (isPercentValueValid == false || isPercentnullBATab == true) {
      if (this.isVaildBATab.indexOf(args.data['taskId']) == -1) {
        this.isVaildBATab.push(args.data['taskId']);
      }
    }
    else {
      let index = this.isVaildBATab.indexOf(args.data['taskId']);
      if (index > -1) {
        this.isVaildBATab.splice(index, 1);
      }
    }

    let isPercentnullCCTab = false;
    let isCCPercentValueValid = false;
    if ((args.data['Country1PercentageOfConsumption'] == null || isNaN(args.data['Country1PercentageOfConsumption']) === true) ||
      (args.data['Country2PercentageOfConsumption'] == null || isNaN(args.data['Country2PercentageOfConsumption']) === true) ||
      (args.data['Country3PercentageOfConsumption'] == null || isNaN(args.data['Country3PercentageOfConsumption']) === true) ||
      (args.data['Country4PercentageOfConsumption'] == null || isNaN(args.data['Country4PercentageOfConsumption']) === true)) {
      isPercentnullCCTab = true;
    } else {
      isPercentnullCCTab = false;
    }
    if ((args.data['Country1PercentageOfConsumption'] >= 0 && args.data['Country1PercentageOfConsumption'] <= 100) &&
      (args.data['Country2PercentageOfConsumption'] >= 0 && args.data['Country2PercentageOfConsumption'] <= 100) &&
      (args.data['Country3PercentageOfConsumption'] >= 0 && args.data['Country3PercentageOfConsumption'] <= 100) &&
      (args.data['Country4PercentageOfConsumption'] >= 0 && args.data['Country4PercentageOfConsumption'] <= 100)) {
      isCCPercentValueValid = true;
    }
    else {
      isCCPercentValueValid = false;
    }
    if (isCCPercentValueValid == false || isPercentnullCCTab == true) {
      if (this.isVaildCCTab.indexOf(args.data['taskId']) == -1) {
        this.isVaildCCTab.push(args.data['taskId']);
      }
    }
    else {
      let index = this.isVaildCCTab.indexOf(args.data['taskId']);
      if (index > -1) {
        this.isVaildCCTab.splice(index, 1);
      }
    }

    let ecapInvalidIds = [];
    let fieldsToValidate = ['IFFCurrentYearEncapsulation', 'IFFPreviousYearRefreshEncapsulation', 'FirmenichCurrentYearEncapsulation', 'FirmenichPreviousYearRefreshEncapsulation', 'GivaudanCurrentYearEncapsulation', 'GivaudanPreviousYearRefreshEncapsulation', 'SymriseCurrentYearEncapsulation', 'SymrisePreviousYearRefreshEncapsulation', 'TakasagoCurrentYearEncapsulation', 'TakasagoPreviousYearRefreshEncapsulation', 'OthersCurrentYearEncapsulation', 'OthersPreviousYearRefreshEncapsulation'];
    fieldsToValidate.forEach((columnName) => {
      switch (columnName) {
        case 'IFFCurrentYearEncapsulation': {
          let isVaild = this.validateEncapFields(args, columnName, 'IFFCurrentYearSales');
          if (isVaild === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'IFFPreviousYearRefreshEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'IFFPreviousYearRefreshSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'FirmenichCurrentYearEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'FirmenichCurrentYearSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'FirmenichPreviousYearRefreshEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'FirmenichPreviousYearRefreshSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'GivaudanCurrentYearEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'GivaudanCurrentYearSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'GivaudanPreviousYearRefreshEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'GivaudanPreviousYearRefreshSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'SymriseCurrentYearEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'SymriseCurrentYearSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'SymrisePreviousYearRefreshEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'SymrisePreviousYearRefreshSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'TakasagoCurrentYearEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'TakasagoCurrentYearSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'TakasagoPreviousYearRefreshEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'TakasagoPreviousYearRefreshSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
        case 'OthersCurrentYearEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'OthersCurrentYearSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }

        case 'OthersPreviousYearRefreshEncapsulation': {
          let isValid = this.validateEncapFields(args, columnName, 'OthersPreviousYearRefreshSales');
          if (isValid === false) {
            ecapInvalidIds.push(args.data['taskId']);
          }
          break;
        }
      }
    });
    if (ecapInvalidIds.length > 0) {
      if (this.isVaildMETab.indexOf(args.data['taskId']) == -1) {
        this.isVaildMETab.push(args.data['taskId']);
      }
    }
    else {
      let index = this.isVaildMETab.indexOf(args.data['taskId']);
      if (index > -1) {
        this.isVaildMETab.splice(index, 1);
      }
    }
    // // let uid = args.cell.parentElement.getAttribute('data-uid');
    // var rData = parentsUntil(args.cell, 'e-rowcell');
    // // let uid = rData.parentElement.getAttribute('data-uid');
    // // if(uid){
    // //   this.grid.getRowObjectFromUID(uid).data = args.data;
    // //   this.grid.updateRow(parseInt(args.cell.parentElement.getAttribute('aria-rowindex')), this.grid.getRowObjectFromUID(uid).data);
    // //   console.log(args.data['taskId'],args.data);      
    // // }

    switch (columnName) {
      case 'FirmenichCurrentYearSales':
      case 'FirmenichPreviousYearRefreshSales':
      case 'GivaudanCurrentYearSales':
      case 'GivaudanPreviousYearRefreshSales':
      case 'SymriseCurrentYearSales':
      case 'SymrisePreviousYearRefreshSales':
      case 'TakasagoCurrentYearSales':
      case 'TakasagoPreviousYearRefreshSales':
      case 'ManeCurrentYearSales':
      case 'ManePreviousYearRefreshSales':
      case 'OthersCurrentYearSales':
      case 'OthersPreviousYearRefreshSales': {
        if (args.cell) {
          if ((args.data[columnName] === null || isNaN(args.data[columnName]) === true)) {
            if (args.cell.classList.contains('e-errorvalue') == false) {
              args.cell.classList.add('e-errorvalue');
            }
          }
          else {
            if (args.cell.classList.contains('e-errorvalue') == true) {
              args.cell.classList.remove('e-errorvalue');
            }
          }
        }
        break;
      }

      case 'IFFCurrentYearEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'IFFCurrentYearSales');
        break;
      }
      case 'IFFPreviousYearRefreshEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'IFFPreviousYearRefreshSales');
        break;
      }
      case 'FirmenichCurrentYearEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'FirmenichCurrentYearSales');
        break;
      }
      case 'FirmenichPreviousYearRefreshEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'FirmenichPreviousYearRefreshSales');
        break;
      }
      case 'GivaudanCurrentYearEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'GivaudanCurrentYearSales');
        break;
      }
      case 'GivaudanPreviousYearRefreshEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'GivaudanPreviousYearRefreshSales');
        break;
      }
      case 'SymriseCurrentYearEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'SymriseCurrentYearSales');
        break;
      }
      case 'SymrisePreviousYearRefreshEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'SymrisePreviousYearRefreshSales');
        break;
      }
      case 'TakasagoCurrentYearEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'TakasagoCurrentYearSales');
        break;
      }
      case 'TakasagoPreviousYearRefreshEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'TakasagoPreviousYearRefreshSales');
        break;
      }
      case 'OthersCurrentYearEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'OthersCurrentYearSales');
        break;
      }

      case 'OthersPreviousYearRefreshEncapsulation': {
        this.cssErrorIndicator(args, columnName, 'OthersPreviousYearRefreshSales');
        break;
      }

      case 'CurrentDosage':
      case 'IFFCurrentYearAvailability':
      case 'GivaudanCurrentYearAvailability':
      case 'FirmenichCurrentYearAvailability':
      case 'SymriseCurrentYearAvailability':
      case 'TakasagoCurrentYearAvailability':
      case 'ManeCurrentYearAvailability':
      case 'OthersCurrentYearAvailability':
      case 'Country1PercentageOfConsumption':
      case 'Country2PercentageOfConsumption':
      case 'Country3PercentageOfConsumption':
      case 'Country4PercentageOfConsumption': {
        if (args.cell) {
          let value = args.data[columnName];
          if ((value > 100 || value < 0) || value == null) {
            if (args.cell.classList.contains('e-errorvalue') == false) {
              args.cell.classList.add('e-errorvalue');
            }
          } else {
            if (args.cell.classList.contains('e-errorvalue') == true) {
              args.cell.classList.remove('e-errorvalue');
            }
          }
        }
        break;
      }
      case 'Comments': {
        if (args.data['FirmenichPreviousYearRefreshSales'] !== args.data['FirmenichPreviousYearSales'] ||
          args.data['GivaudanPreviousYearRefreshSales'] !== args.data['GivaudanPreviousYearSales'] ||
          args.data['SymrisePreviousYearRefreshSales'] !== args.data['SymrisePreviousYearSales'] ||
          args.data['TakasagoPreviousYearRefreshSales'] !== args.data['TakasagoPreviousYearSales'] ||
          args.data['OthersPreviousYearRefreshSales'] !== args.data['OthersPreviousYearSales']) {
          if (args.data['Comments'] == null) {
            if (args.cell.classList.contains('e-errorvalue') == false) {
              args.cell.classList.add('e-errorvalue');
            }
          }
          if (args.cell.textContent && args.cell.textContent.trim(' ').length > 0) {
            if (args.cell.classList.contains('e-errorvalue') == true) {
              args.cell.classList.remove('e-errorvalue');
            }
          }
          else {
            if (args.cell.classList.contains('e-errorvalue') == false) {
              args.cell.classList.add('e-errorvalue');
            }
          }
        } else {
          if (args.cell.classList.contains('e-errorvalue') == true) {
            args.cell.classList.remove('e-errorvalue');
          }
        }
        break;
      }
    }
    // console.log('MP ',this.isVaildMPTab, 'BA',this.isVaildBATab, 'ME ',this.isVaildMETab, 'CC ',this.isVaildCCTab);
  }

  public cssErrorIndicator(args, colName, field) {
    let textContent = (args.data[colName] === null || isNaN(args.data[colName]) === true) ? null : Number(args.data[colName]);
    let potentialValue = Number(args.data[field]);
    if (args.cell && textContent === null) {
      if (args.cell.classList.contains('e-errorvalue') == false) {
        args.cell.classList.add('e-errorvalue');
      }
    }
    else if (args.cell && potentialValue < textContent) {
      if (potentialValue > 0) {
        if (args.cell.classList.contains('e-errorvalue') == false) {
          args.cell.classList.add('e-errorvalue');
        }
      }
      if (potentialValue < 0) {
        if (textContent != 0) {
          if (args.cell.classList.contains('e-errorvalue') == false) {
            args.cell.classList.add('e-errorvalue');
          }
        }
        if (textContent == 0) {
          if (args.cell.classList.contains('e-errorvalue') == true) {
            args.cell.classList.remove('e-errorvalue');
          }
        }
      }
    } else {
      if (args.cell.classList.contains('e-errorvalue') == true) {
        args.cell.classList.remove('e-errorvalue');
      }
    }
  }

  public canDeactivate() {
    if (this.hasUnsavedChanges) {
      return false;
    } else {
      return true;
    }
  }
  public getDateValidation() {
    const presentDate = new Date();
    const dueDate = new Date(this.userInfo.DueDate);
    return (presentDate > dueDate);
  }

  public beforeOpenColumnChooser(args) {
    (this.grid.columnChooserModule as any).dlgObj.beforeOpen = function (e) {
      let checkBoxList: any = (this.grid.columnChooserModule as any).dlgDiv.querySelectorAll('.e-cclist');
      for (let i: number = 0; i < checkBoxList.length; i++) {
        let checkboxName = checkBoxList[i].querySelector('.e-label');
        let chekboxEle: any = parentsUntil(checkboxName, 'e-checkbox-wrapper');
        if (checkboxName.innerHTML.toLowerCase() === 'sec enduse' || checkboxName.innerHTML.toLowerCase() === 'brand') {
          if (!chekboxEle.classList.contains('e-checkbox-disabled')) {
            chekboxEle.classList.add('e-checkbox-disabled');
          }
        }
        if (checkboxName.innerHTML == 'Select All') {
          chekboxEle.style.display = 'none';
        }
      }
    }.bind(this);
  }

  /**
   * @name: getFilterData
   * @description: get values from filtered grid list and retuns the datasource of all filtered data to user.
  */
  public getFilterData() {
    let query = this.grid.renderModule.data.generateQuery();
    let idx;
    for (let i = 0; i < query.queries.length; i++) {
      if (query.queries[i].fn == 'onPage') {
        idx = i;
        break;
      }
    }
    query.queries.splice(idx, 1)
    let result = this.grid.renderModule.data.dataManager.executeLocal(query);
    return result || [];
  }

  /** 
   * COMMON CALCULATION PART
   * 
   * */
  public getMarketShare(yearlySales: number, totalYearSales: number): number {
    let marketShare = Number(yearlySales) / Number(totalYearSales);
    let marketShareValue = isFinite(marketShare) ? marketShare : null;
    return isNaN(marketShareValue) ? 0 : marketShareValue;

  }

  public getGrowthRate(currentSales: number, previousRefreshSales: number): number {
    let growthRate = (Number(currentSales) / Number(previousRefreshSales)) - 1;
    return isFinite(growthRate) ? growthRate : null;
  }

  public getAvailabilityBasedSales = (availabilityPercent, totalSales) => {
    return totalSales * (availabilityPercent / 100) || 0;
  }

  public getTotalAvailabilityPercent(totalAvailability, totalSales) {
    return (totalAvailability / totalSales);
  }
  public getEncapProportion(totalPotential: number, marketEncap: number): number {
    let proportion = (Number(marketEncap) / Number(totalPotential));
    return isFinite(proportion) ? proportion : null;
  }

  public getMarketEncapShare(yearlyEncap: number, totalYearEncap: number): number {
    let marketShare = Number(yearlyEncap) / Number(totalYearEncap);
    return isFinite(marketShare) ? marketShare : null;
  }
  public updateAggregateFieldsDOM() {
    let data: any = this.getFilterData();
    // let FieldName = args.columnName;
    // let MPtabFields = ['FirmenichCurrentYearSales', 'FirmenichPreviousYearRefreshSales', 'GivaudanCurrentYearSales', 'GivaudanPreviousYearRefreshSales'
    //   , 'SymriseCurrentYearSales', 'SymrisePreviousYearRefreshSales', 'TakasagoCurrentYearSales', 'TakasagoPreviousYearRefreshSales',
    //   'OthersCurrentYearSales', 'OthersPreviousYearRefreshSales'];
    if (this.TabSelectionSettings.CurrentSelection == 'Potential') {
      if (data && Array.isArray(data) && data.length > 0) {
        let GivaudanCurrentYearSales = 0;
        let GivaudanPreviousYearRefreshSales = 0;
        let IFFCurrentYearSales = 0;
        let IFFPreviousYearRefreshSales = 0;
        let FirmenichCurrentYearSales = 0;
        let FirmenichPreviousYearRefreshSales = 0;
        let SymriseCurrentYearSales = 0;
        let SymrisePreviousYearRefreshSales = 0;
        let TakasagoCurrentYearSales = 0;
        let TakasagoPreviousYearRefreshSales = 0;
        let ManeCurrentYearSales = 0;
        let ManePreviousYearRefreshSales = 0;
        let OthersCurrentYearSales = 0;
        let OthersPreviousYearRefreshSales = 0;
        let curYearTotal = 0;
        let prevYearRefTotal = 0;
        data.forEach((item) => {
          let curYearValue = parseFloat(item['FirmenichCurrentYearSales'] || 0) +
            parseFloat(item['IFFCurrentYearSales'] || 0) +
            parseFloat(item['GivaudanCurrentYearSales'] || 0) +
            parseFloat(item['SymriseCurrentYearSales'] || 0) +
            parseFloat(item['TakasagoCurrentYearSales'] || 0) +
            parseFloat(item['ManeCurrentYearSales'] || 0) +
            parseFloat(item['OthersCurrentYearSales'] || 0);
          let prevYearRefValue = parseFloat(item['IFFPreviousYearRefreshSales'] || 0) +
            parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0) +
            parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0) +
            parseFloat(item['SymrisePreviousYearRefreshSales'] || 0) +
            parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0) +
            parseFloat(item['ManePreviousYearRefreshSales'] || 0) +
            parseFloat(item['OthersPreviousYearRefreshSales'] || 0);
          curYearTotal += curYearValue;
          prevYearRefTotal += prevYearRefValue;
          GivaudanCurrentYearSales += (parseFloat(item['GivaudanCurrentYearSales'] || 0));
          GivaudanPreviousYearRefreshSales += (parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0));
          IFFCurrentYearSales += (parseFloat(item['IFFCurrentYearSales'] || 0));
          IFFPreviousYearRefreshSales += (parseFloat(item['IFFPreviousYearRefreshSales'] || 0));
          FirmenichCurrentYearSales += (parseFloat(item['FirmenichCurrentYearSales'] || 0));
          FirmenichPreviousYearRefreshSales += (parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0));
          SymriseCurrentYearSales += (parseFloat(item['SymriseCurrentYearSales'] || 0));
          SymrisePreviousYearRefreshSales += (parseFloat(item['SymrisePreviousYearRefreshSales'] || 0));
          TakasagoCurrentYearSales += (parseFloat(item['TakasagoCurrentYearSales'] || 0));
          TakasagoPreviousYearRefreshSales += (parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0));
          ManeCurrentYearSales += (parseFloat(item['ManeCurrentYearSales'] || 0));
          ManePreviousYearRefreshSales += (parseFloat(item['ManePreviousYearRefreshSales'] || 0));
          OthersCurrentYearSales += (parseFloat(item['OthersCurrentYearSales'] || 0));
          OthersPreviousYearRefreshSales += (parseFloat(item['OthersPreviousYearRefreshSales'] || 0));
        });

        let columnsToUpdate = [
          'IFFCurrentYearSales',
          'IFFPreviousYearRefreshSales',
          'FirmenichCurrentYearSales',
          'FirmenichPreviousYearRefreshSales',
          'GivaudanCurrentYearSales',
          'GivaudanPreviousYearRefreshSales',
          'SymriseCurrentYearSales',
          'SymrisePreviousYearRefreshSales',
          'TakasagoCurrentYearSales',
          'TakasagoPreviousYearRefreshSales',
          'OthersCurrentYearSales',
          'OthersPreviousYearRefreshSales'];
        columnsToUpdate.forEach((columnNameToUpdate) => {
          switch (columnNameToUpdate) {
            case 'IFFCurrentYearSales': {
              let IFF_CURRENTYEAR_SALES = this.getMarketShare(IFFCurrentYearSales, curYearTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(IFF_CURRENTYEAR_SALES) == false ? (IFF_CURRENTYEAR_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(IFFCurrentYearSales, IFFPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('IFFPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }

            case 'IFFPreviousYearRefreshSales': {
              let IFF_PREVIOUSYEARREF_SALES = this.getMarketShare(IFFPreviousYearRefreshSales, prevYearRefTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(IFF_PREVIOUSYEARREF_SALES) == false ? (IFF_PREVIOUSYEARREF_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(IFFCurrentYearSales, IFFPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('IFFPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }

            case 'FirmenichCurrentYearSales': {
              let FIRMENICH_CURRENTYEAR_SALES = this.getMarketShare(FirmenichCurrentYearSales, curYearTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(FIRMENICH_CURRENTYEAR_SALES) == false ? (FIRMENICH_CURRENTYEAR_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(FirmenichCurrentYearSales, FirmenichPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('FirmenichPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }

            case 'FirmenichPreviousYearRefreshSales': {
              let FIRMENICH_PREVIOUSYEARREF_SALES = this.getMarketShare(FirmenichPreviousYearRefreshSales, prevYearRefTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(FIRMENICH_PREVIOUSYEARREF_SALES) == false ? (FIRMENICH_PREVIOUSYEARREF_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(FirmenichCurrentYearSales, FirmenichPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('FirmenichPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }
            case 'GivaudanCurrentYearSales': {
              let GIVAUDAN_CURRENTYEAR_SALES = this.getMarketShare(GivaudanCurrentYearSales, curYearTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(GIVAUDAN_CURRENTYEAR_SALES) == false ? (GIVAUDAN_CURRENTYEAR_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(GivaudanCurrentYearSales, GivaudanPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('GivaudanPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }

            case 'GivaudanPreviousYearRefreshSales': {
              let GIVAUDAN_PREVIOUSYEARREF_SALES = this.getMarketShare(GivaudanPreviousYearRefreshSales, prevYearRefTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(GIVAUDAN_PREVIOUSYEARREF_SALES) == false ? (GIVAUDAN_PREVIOUSYEARREF_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(GivaudanCurrentYearSales, GivaudanPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('GivaudanPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }
            case 'SymriseCurrentYearSales': {
              let SYMRISE_CURRENTYEAR_SALES = this.getMarketShare(SymriseCurrentYearSales, curYearTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(SYMRISE_CURRENTYEAR_SALES) == false ? (SYMRISE_CURRENTYEAR_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(SymriseCurrentYearSales, SymrisePreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('SymrisePreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }

            case 'SymrisePreviousYearRefreshSales': {
              let SYMRISE_PREVIOUSYEARREF_SALES = this.getMarketShare(SymrisePreviousYearRefreshSales, prevYearRefTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(SYMRISE_PREVIOUSYEARREF_SALES) == false ? (SYMRISE_PREVIOUSYEARREF_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(SymriseCurrentYearSales, SymrisePreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('SymrisePreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }
            case 'TakasagoCurrentYearSales': {
              let TAKASAGO_CURRENTYEAR_SALES = this.getMarketShare(TakasagoCurrentYearSales, curYearTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(TAKASAGO_CURRENTYEAR_SALES) == false ? (TAKASAGO_CURRENTYEAR_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(TakasagoCurrentYearSales, TakasagoPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('TakasagoPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }

            case 'TakasagoPreviousYearRefreshSales': {
              let TAKASAGO_PREVIOUSYEARREF_SALES = this.getMarketShare(TakasagoPreviousYearRefreshSales, prevYearRefTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(TAKASAGO_PREVIOUSYEARREF_SALES) == false ? (TAKASAGO_PREVIOUSYEARREF_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(TakasagoCurrentYearSales, TakasagoPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('TakasagoPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;

              break;
            }
            case 'ManeCurrentYearSales': {
              let MANE_CURRENTYEAR_SALES = this.getMarketShare(ManeCurrentYearSales, curYearTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(MANE_CURRENTYEAR_SALES) == false ? (MANE_CURRENTYEAR_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(ManeCurrentYearSales, ManePreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('ManePreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;
              break;
            }

            case 'ManePreviousYearRefreshSales': {
              let MANE_PREVIOUSYEARREF_SALES = this.getMarketShare(ManePreviousYearRefreshSales, prevYearRefTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(MANE_PREVIOUSYEARREF_SALES) == false ? (MANE_PREVIOUSYEARREF_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(ManeCurrentYearSales, ManePreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('ManePreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;

              break;
            }
            case 'OthersCurrentYearSales': {
              let OTHERS_CURRENTYEAR_SALES = this.getMarketShare(OthersCurrentYearSales, curYearTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(OTHERS_CURRENTYEAR_SALES) == false ? (OTHERS_CURRENTYEAR_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(OthersCurrentYearSales, OthersPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('OthersPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;

              break;
            }

            case 'OthersPreviousYearRefreshSales': {
              let OTHERS_PREVIOUSYEARREF_SALES = this.getMarketShare(OthersPreviousYearRefreshSales, prevYearRefTotal);
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              aggregateCell.innerHTML = isNaN(OTHERS_PREVIOUSYEARREF_SALES) == false ? (OTHERS_PREVIOUSYEARREF_SALES * 100).toFixed(1) + '%' : "NA";

              let growthRateValue = this.getGrowthRate(OthersCurrentYearSales, OthersPreviousYearRefreshSales);
              let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
              let selector2 = "[e-mappinguid=\'" + (this.grid.getColumnByField('OthersPreviousYearRefreshSales') as any).uid + "\']";
              let growthRateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector2);
              growthRateCell.innerHTML = growthRate;


              break;
            }
          }
        });
        let growthRateValue = this.getGrowthRate(curYearTotal, prevYearRefTotal);
        let growthRate = isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? '0' : this.percentPipe.transform(growthRateValue, '1.0-1');
        let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField('TotalPreviousYearRefreshSales') as any).uid + "\']";
        let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector1);
        aggregateCell.innerHTML = growthRate;
      }
    }
    // let BAtabFields = ['IFFCurrentYearAvailability', 'FirmenichCurrentYearAvailability', 'GivaudanCurrentYearAvailability',
    //   'SymriseCurrentYearAvailability', 'TakasagoCurrentYearAvailability', 'OthersCurrentYearAvailability'];
    if (this.TabSelectionSettings.CurrentSelection == 'Availability') {
      if (data && Array.isArray(data) && data.length > 0) {
        let IFFCurrentYearAvailability = 0;
        let FirmenichCurrentYearAvailability = 0;
        let GivaudanCurrentYearAvailability = 0;
        let SymriseCurrentYearAvailability = 0;
        let TakasagoCurrentYearAvailability = 0;
        let ManeCurrentYearAvailability = 0;
        let OthersCurrentYearAvailability = 0;
        let curYearTotal = 0;
        data.forEach((item) => {
          let curYearValue = parseFloat(item['FirmenichCurrentYearSales'] || 0) +
            parseFloat(item['IFFCurrentYearSales'] || 0) +
            parseFloat(item['GivaudanCurrentYearSales'] || 0) +
            parseFloat(item['SymriseCurrentYearSales'] || 0) +
            parseFloat(item['TakasagoCurrentYearSales'] || 0) +
            parseFloat(item['ManeCurrentYearSales'] || 0) +
            parseFloat(item['OthersCurrentYearSales'] || 0);
          curYearTotal += curYearValue;
          IFFCurrentYearAvailability += this.getAvailabilityBasedSales(item['IFFCurrentYearAvailability'], curYearValue);
          FirmenichCurrentYearAvailability += this.getAvailabilityBasedSales(item['FirmenichCurrentYearAvailability'], curYearValue);
          GivaudanCurrentYearAvailability += this.getAvailabilityBasedSales(item['GivaudanCurrentYearAvailability'], curYearValue);
          SymriseCurrentYearAvailability += this.getAvailabilityBasedSales(item['SymriseCurrentYearAvailability'], curYearValue);
          TakasagoCurrentYearAvailability += this.getAvailabilityBasedSales(item['TakasagoCurrentYearAvailability'], curYearValue);
          ManeCurrentYearAvailability += this.getAvailabilityBasedSales(item['ManeCurrentYearAvailability'], curYearValue);
          OthersCurrentYearAvailability += this.getAvailabilityBasedSales(item['OthersCurrentYearAvailability'], curYearValue);
        });
        let columnsToUpdate = [
          'IFFCurrentYearAvailability',
          'FirmenichCurrentYearAvailability',
          'GivaudanCurrentYearAvailability',
          'SymriseCurrentYearAvailability',
          'TakasagoCurrentYearAvailability',
          'OthersCurrentYearAvailability'];
        columnsToUpdate.forEach((columnNameToUpdate) => {
          switch (columnNameToUpdate) {
            case 'IFFCurrentYearAvailability': {
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
              let intl: Internationalization = new Internationalization();
              let nFormatter: Function = intl.getNumberFormat({ format: 'C0', currency: 'USD' });
              let result = nFormatter(IFFCurrentYearAvailability) || '0';
              aggregateCell.innerHTML = result;
              let precentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              precentCell.innerHTML = this.percentPipe.transform(this.getTotalAvailabilityPercent(IFFCurrentYearAvailability, curYearTotal), '1.0-1');
              break;
            }
            case 'FirmenichCurrentYearAvailability': {
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
              let intl: Internationalization = new Internationalization();
              let nFormatter: Function = intl.getNumberFormat({ format: 'C0', currency: 'USD' });
              let result = nFormatter(FirmenichCurrentYearAvailability) || '0';
              aggregateCell.innerHTML = result;
              let precentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              precentCell.innerHTML = this.percentPipe.transform(this.getTotalAvailabilityPercent(FirmenichCurrentYearAvailability, curYearTotal), '1.0-1');
              break;
            }
            case 'GivaudanCurrentYearAvailability': {
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
              let intl: Internationalization = new Internationalization();
              let nFormatter: Function = intl.getNumberFormat({ format: 'C0', currency: 'USD' });
              let result = nFormatter(GivaudanCurrentYearAvailability) || '0';
              aggregateCell.innerHTML = result;
              let precentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              precentCell.innerHTML = this.percentPipe.transform(this.getTotalAvailabilityPercent(GivaudanCurrentYearAvailability, curYearTotal), '1.0-1');
              break;
            }
            case 'SymriseCurrentYearAvailability': {
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
              let intl: Internationalization = new Internationalization();
              let nFormatter: Function = intl.getNumberFormat({ format: 'C0', currency: 'USD' });
              let result = nFormatter(SymriseCurrentYearAvailability) || '0';
              aggregateCell.innerHTML = result;
              let precentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              precentCell.innerHTML = this.percentPipe.transform(this.getTotalAvailabilityPercent(SymriseCurrentYearAvailability, curYearTotal), '1.0-1');
              break;
            }
            case 'TakasagoCurrentYearAvailability': {
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
              let intl: Internationalization = new Internationalization();
              let nFormatter: Function = intl.getNumberFormat({ format: 'C0', currency: 'USD' });
              let result = nFormatter(TakasagoCurrentYearAvailability) || '0';
              aggregateCell.innerHTML = result;
              let precentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              precentCell.innerHTML = this.percentPipe.transform(this.getTotalAvailabilityPercent(TakasagoCurrentYearAvailability, curYearTotal), '1.0-1');
              break;
            }
            case 'ManeCurrentYearAvailability': {
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
              let intl: Internationalization = new Internationalization();
              let nFormatter: Function = intl.getNumberFormat({ format: 'C0', currency: 'USD' });
              let result = nFormatter(ManeCurrentYearAvailability) || '0';
              aggregateCell.innerHTML = result;
              let precentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              precentCell.innerHTML = this.percentPipe.transform(this.getTotalAvailabilityPercent(ManeCurrentYearAvailability, curYearTotal), '1.0-1');
              break;
            }
            case 'OthersCurrentYearAvailability': {
              let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(columnNameToUpdate) as any).uid + "\']";
              let aggregateCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
              let intl: Internationalization = new Internationalization();
              let nFormatter: Function = intl.getNumberFormat({ format: 'C0', currency: 'USD' });
              let result = nFormatter(OthersCurrentYearAvailability) || '0';
              aggregateCell.innerHTML = result;
              let precentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
              precentCell.innerHTML = this.percentPipe.transform(this.getTotalAvailabilityPercent(OthersCurrentYearAvailability, curYearTotal), '1.0-1');
              break;
            }
          }
        });
      }
    }
    // let MEtabFields = ['IFFCurrentYearEncapsulation', 'IFFPreviousYearRefreshEncapsulation', 'FirmenichCurrentYearEncapsulation',
    //   'FirmenichPreviousYearRefreshEncapsulation', 'GivaudanCurrentYearEncapsulation', 'GivaudanPreviousYearRefreshEncapsulation',
    //   'SymriseCurrentYearEncapsulation', 'SymrisePreviousYearRefreshEncapsulation', 'TakasagoCurrentYearEncapsulation', 'TakasagoPreviousYearRefreshEncapsulation',
    //   'OthersCurrentYearEncapsulation', 'OthersPreviousYearRefreshEncapsulation'];
    if (this.TabSelectionSettings.CurrentSelection == 'Encapsulation') {
      if (data && Array.isArray(data) && data.length > 0) {
        //Market Potential fields
        let curYearTotal = 0;
        let prevYearTotal = 0;
        let prevYearRefTotal = 0;
        let IFFCurrentYearSales = 0;
        let IFFPreviousYearSales = 0;
        let IFFPreviousYearRefreshSales = 0;
        let FirmenichCurrentYearSales = 0;
        let FirmenichPreviousYearSales = 0;
        let FirmenichPreviousYearRefreshSales = 0;
        let GivaudanCurrentYearSales = 0;
        let GivaudanPreviousYearSales = 0;
        let GivaudanPreviousYearRefreshSales = 0;
        let SymriseCurrentYearSales = 0;
        let SymrisePreviousYearSales = 0;
        let SymrisePreviousYearRefreshSales = 0;
        let TakasagoCurrentYearSales = 0;
        let TakasagoPreviousYearSales = 0;
        let TakasagoPreviousYearRefreshSales = 0;
        let ManeCurrentYearSales = 0;
        let ManePreviousYearSales = 0;
        let ManePreviousYearRefreshSales = 0;
        let OthersCurrentYearSales = 0;
        let OthersPreviousYearSales = 0;
        let OthersPreviousYearRefreshSales = 0;
        // ENCAP
        let curYearEncap = 0;
        let prevYearEncap = 0;
        let prevYearRefEncap = 0;
        let IFFCurrentYearEncap = 0;
        let IFFPreviousYearEncap = 0;
        let IFFPreviousYearRefreshEncap = 0;
        let FirmenichCurrentYearEncap = 0;
        let FirmenichPreviousYearEncap = 0;
        let FirmenichPreviousYearRefreshEncap = 0;
        let GivaudanCurrentYearEncap = 0;
        let GivaudanPreviousYearEncap = 0;
        let GivaudanPreviousYearRefreshEncap = 0;
        let SymriseCurrentYearEncap = 0;
        let SymrisePreviousYearEncap = 0;
        let SymrisePreviousYearRefreshEncap = 0;
        let TakasagoCurrentYearEncap = 0;
        let TakasagoPreviousYearEncap = 0;
        let TakasagoPreviousYearRefreshEncap = 0;
        let OthersCurrentYearEncap = 0;
        let OthersPreviousYearEncap = 0;
        let OthersPreviousYearRefreshEncap = 0;
        data.forEach(item => {
          let curYearValue = parseFloat(item['FirmenichCurrentYearSales'] || 0) +
            parseFloat(item['IFFCurrentYearSales'] || 0) +
            parseFloat(item['GivaudanCurrentYearSales'] || 0) +
            parseFloat(item['SymriseCurrentYearSales'] || 0) +
            parseFloat(item['TakasagoCurrentYearSales'] || 0) +
            parseFloat(item['ManeCurrentYearSales'] || 0) +
            parseFloat(item['OthersCurrentYearSales'] || 0);
          let prevYearValue = parseFloat(item['IFFPreviousYearSales'] || 0) +
            parseFloat(item['FirmenichPreviousYearSales'] || 0) +
            parseFloat(item['GivaudanPreviousYearSales'] || 0) +
            parseFloat(item['SymrisePreviousYearSales'] || 0) +
            parseFloat(item['TakasagoPreviousYearSales'] || 0) +
            parseFloat(item['ManePreviousYearSales'] || 0) +
            parseFloat(item['OthersPreviousYearSales'] || 0);
          let prevYearRefValue = parseFloat(item['IFFPreviousYearRefreshSales'] || 0) +
            parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0) +
            parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0) +
            parseFloat(item['SymrisePreviousYearRefreshSales'] || 0) +
            parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0) +
            parseFloat(item['ManePreviousYearRefreshSales'] || 0) +
            parseFloat(item['OthersPreviousYearRefreshSales'] || 0);
          curYearTotal += curYearValue;
          prevYearTotal += prevYearValue;
          prevYearRefTotal += prevYearRefValue;
          IFFCurrentYearSales += (parseFloat(item['IFFCurrentYearSales'] || 0));
          IFFPreviousYearSales += (parseFloat(item['IFFPreviousYearSales'] || 0));
          IFFPreviousYearRefreshSales += (parseFloat(item['IFFPreviousYearRefreshSales'] || 0));
          GivaudanCurrentYearSales += (parseFloat(item['GivaudanCurrentYearSales'] || 0));
          GivaudanPreviousYearSales += (parseFloat(item['GivaudanPreviousYearSales'] || 0));
          GivaudanPreviousYearRefreshSales += (parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0));
          FirmenichCurrentYearSales += (parseFloat(item['FirmenichCurrentYearSales'] || 0));
          FirmenichPreviousYearSales += (parseFloat(item['FirmenichPreviousYearSales'] || 0));
          FirmenichPreviousYearRefreshSales += (parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0));
          SymriseCurrentYearSales += (parseFloat(item['SymriseCurrentYearSales'] || 0));
          SymrisePreviousYearSales += (parseFloat(item['SymrisePreviousYearSales'] || 0));
          SymrisePreviousYearRefreshSales += (parseFloat(item['SymrisePreviousYearRefreshSales'] || 0));
          TakasagoCurrentYearSales += (parseFloat(item['TakasagoCurrentYearSales'] || 0));
          TakasagoPreviousYearSales += (parseFloat(item['TakasagoPreviousYearSales'] || 0));
          TakasagoPreviousYearRefreshSales += (parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0));
          ManeCurrentYearSales += (parseFloat(item['ManeCurrentYearSales'] || 0));
          ManePreviousYearSales += (parseFloat(item['ManePreviousYearSales'] || 0));
          ManePreviousYearRefreshSales += (parseFloat(item['ManePreviousYearRefreshSales'] || 0));
          OthersCurrentYearSales += (parseFloat(item['OthersCurrentYearSales'] || 0));
          OthersPreviousYearSales += (parseFloat(item['OthersPreviousYearSales'] || 0));
          OthersPreviousYearRefreshSales += (parseFloat(item['OthersPreviousYearRefreshSales'] || 0));
          let currentYearEncapTotal = parseFloat(item['IFFCurrentYearEncapsulation'] || 0) +
            parseFloat(item['FirmenichCurrentYearEncapsulation'] || 0) +
            parseFloat(item['GivaudanCurrentYearEncapsulation'] || 0) +
            parseFloat(item['SymriseCurrentYearEncapsulation'] || 0) +
            parseFloat(item['TakasagoCurrentYearEncapsulation'] || 0) +
            parseFloat(item['OthersCurrentYearEncapsulation'] || 0);
          let previousYearEncapTotal = parseFloat(item['IFFPreviousYearEncapsulation'] || 0) +
            parseFloat(item['FirmenichPreviousYearEncapsulation'] || 0) +
            parseFloat(item['GivaudanPreviousYearEncapsulation'] || 0) +
            parseFloat(item['SymrisePreviousYearEncapsulation'] || 0) +
            parseFloat(item['TakasagoPreviousYearEncapsulation'] || 0) +
            parseFloat(item['OthersPreviousYearEncapsulation'] || 0);
          let previousYearRefreshEncapTotal = parseFloat(item['IFFPreviousYearRefreshEncapsulation'] || 0) +
            parseFloat(item['FirmenichPreviousYearRefreshEncapsulation'] || 0) +
            parseFloat(item['GivaudanPreviousYearRefreshEncapsulation'] || 0) +
            parseFloat(item['SymrisePreviousYearRefreshEncapsulation'] || 0) +
            parseFloat(item['TakasagoPreviousYearRefreshEncapsulation'] || 0) +
            parseFloat(item['OthersPreviousYearRefreshEncapsulation'] || 0);
          curYearEncap += currentYearEncapTotal;
          prevYearEncap += previousYearEncapTotal;
          prevYearRefEncap += previousYearRefreshEncapTotal;
          IFFCurrentYearEncap += (parseFloat(item['IFFCurrentYearEncapsulation'] || 0));
          IFFPreviousYearEncap += (parseFloat(item['IFFPreviousYearEncapsulation'] || 0));
          IFFPreviousYearRefreshEncap += (parseFloat(item['IFFPreviousYearRefreshEncapsulation'] || 0));
          GivaudanCurrentYearEncap += (parseFloat(item['GivaudanCurrentYearEncapsulation'] || 0));
          GivaudanPreviousYearEncap += (parseFloat(item['GivaudanPreviousYearEncapsulation'] || 0));
          GivaudanPreviousYearRefreshEncap += (parseFloat(item['GivaudanPreviousYearRefreshEncapsulation'] || 0));
          FirmenichCurrentYearEncap += (parseFloat(item['FirmenichCurrentYearEncapsulation'] || 0));
          FirmenichPreviousYearEncap += (parseFloat(item['FirmenichPreviousYearEncapsulation'] || 0));
          FirmenichPreviousYearRefreshEncap += (parseFloat(item['FirmenichPreviousYearRefreshEncapsulation'] || 0));
          SymriseCurrentYearEncap += (parseFloat(item['SymriseCurrentYearEncapsulation'] || 0));
          SymrisePreviousYearEncap += (parseFloat(item['SymrisePreviousYearEncapsulation'] || 0));
          SymrisePreviousYearRefreshEncap += (parseFloat(item['SymrisePreviousYearRefreshEncapsulation'] || 0));
          TakasagoCurrentYearEncap += (parseFloat(item['TakasagoCurrentYearEncapsulation'] || 0));
          TakasagoPreviousYearEncap += (parseFloat(item['TakasagoPreviousYearEncapsulation'] || 0));
          TakasagoPreviousYearRefreshEncap += (parseFloat(item['TakasagoPreviousYearRefreshEncapsulation'] || 0));
          OthersCurrentYearEncap += (parseFloat(item['OthersCurrentYearEncapsulation'] || 0));
          OthersPreviousYearEncap += (parseFloat(item['OthersPreviousYearEncapsulation'] || 0));
          OthersPreviousYearRefreshEncap += (parseFloat(item['OthersPreviousYearRefreshEncapsulation'] || 0));
        });
        let columnsToUpdate = [
          'IFFCurrentYearEncapsulation',
          'IFFPreviousYearRefreshEncapsulation',
          'FirmenichCurrentYearEncapsulation',
          'FirmenichPreviousYearRefreshEncapsulation',
          'GivaudanCurrentYearEncapsulation',
          'GivaudanPreviousYearRefreshEncapsulation',
          'SymriseCurrentYearEncapsulation',
          'SymrisePreviousYearRefreshEncapsulation',
          'TakasagoCurrentYearEncapsulation',
          'TakasagoPreviousYearRefreshEncapsulation',
          'OthersCurrentYearEncapsulation',
          'OthersPreviousYearRefreshEncapsulation'
        ];
        columnsToUpdate.forEach((columnToUpdate) => {
          switch (columnToUpdate) {
            case 'IFFCurrentYearEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, IFFCurrentYearSales, IFFCurrentYearEncap, curYearEncap);
              break;
            }
            case 'IFFPreviousYearRefreshEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, IFFPreviousYearRefreshSales, IFFPreviousYearRefreshEncap, prevYearRefEncap);
              break;
            }
            case 'FirmenichCurrentYearEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, FirmenichCurrentYearSales, FirmenichCurrentYearEncap, curYearEncap);
              break;
            }
            case 'FirmenichPreviousYearRefreshEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, FirmenichPreviousYearRefreshSales, FirmenichPreviousYearRefreshEncap, prevYearRefEncap);
              break;
            }
            case 'GivaudanCurrentYearEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, GivaudanCurrentYearSales, GivaudanCurrentYearEncap, curYearEncap);
              break;
            }
            case 'GivaudanPreviousYearRefreshEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, GivaudanPreviousYearRefreshSales, GivaudanPreviousYearRefreshEncap, prevYearRefEncap);
              break;
            }
            case 'SymriseCurrentYearEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, SymriseCurrentYearSales, SymriseCurrentYearEncap, curYearEncap);
              break;
            }
            case 'SymrisePreviousYearRefreshEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, SymrisePreviousYearRefreshSales, SymrisePreviousYearRefreshEncap, prevYearRefEncap);
              break;
            }
            case 'TakasagoCurrentYearEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, TakasagoCurrentYearSales, TakasagoCurrentYearEncap, curYearEncap);
              break;
            }
            case 'TakasagoPreviousYearRefreshEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, TakasagoPreviousYearRefreshSales, TakasagoPreviousYearRefreshEncap, prevYearRefEncap);
              break;
            }
            case 'OthersCurrentYearEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, OthersCurrentYearSales, OthersCurrentYearEncap, curYearEncap);
              break;
            }
            case 'OthersPreviousYearRefreshEncapsulation': {
              this.encapDOMUpdate(columnToUpdate, OthersPreviousYearRefreshSales, OthersPreviousYearRefreshEncap, prevYearRefEncap);
              break;
            }
          }
        });
        let curEncapSelector = "[e-mappinguid=\'" + (this.grid.getColumnByField('TotalCurEncap') as any).uid + "\']";
        let prevEncapSelector = "[e-mappinguid=\'" + (this.grid.getColumnByField('TotalPrevEncap') as any).uid + "\']";
        let prevRefEncapSelector = "[e-mappinguid=\'" + (this.grid.getColumnByField('TotalPrevRefEncap') as any).uid + "\']";

        let curEncapCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(curEncapSelector);
        let prevEncapCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(prevEncapSelector);
        let prevRefEncapCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(prevRefEncapSelector);

        let curEncapValue = this.getEncapProportion(curYearTotal, curYearEncap);
        let prevEncapValue = this.getEncapProportion(prevYearTotal, prevYearEncap);
        let prevRefEncapValue = this.getEncapProportion(prevYearRefTotal, prevYearRefEncap);

        curEncapCell.innerHTML = this.percentPipe.transform(curEncapValue, '1.0-1') || '0';
        prevEncapCell.innerHTML = this.percentPipe.transform(prevEncapValue, '1.0-1') || '0';
        prevRefEncapCell.innerHTML = this.percentPipe.transform(prevRefEncapValue, '1.0-1') || '0';
      }
    }
  }
  public encapDOMUpdate(FieldName, curCompanySales, curCompanyEncap, totalYearEncap) {
    let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField(FieldName) as any).uid + "\']";
    let ENCAPPercentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[1].querySelector(selector1);
    let EncapPercentValue = this.getEncapProportion(curCompanySales, curCompanyEncap);
    let result = this.percentPipe.transform(EncapPercentValue, '1.0-1') || '0';
    ENCAPPercentCell.innerHTML = result;
    let marketSharePrecentCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector(selector1);
    marketSharePrecentCell.innerHTML = this.percentPipe.transform(this.getMarketEncapShare(curCompanyEncap, totalYearEncap), '1.0-1');
  }

  // public updateCalculatedFieldsDOM(args) {
  //   let data: any = this.grid.dataSource;
  //   let FieldName = args.columnName;
  //   if (FieldName === "FirmenichCurrentYearSales") {
  //     let index = this.grid.getColumnIndexByField(FieldName);
  //     // args.cell.parentElement.querySelector('[aria-colindex="8"]');
  //     // let selector = '[aria-colindex="8"]';
  //     let selector = "[aria-colindex=\'" + (index) + "\']";
  //     // args.cell.parentElement.querySelector(selector).innerHTML = "34";
  //     // this.grid.getColumnByField('TotalCurrentYearSales').uid
  //     // this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector('[e-mappinguid="grid-column8"]').innerHTML = "234%"
  //     // this.grid.getColumnByField('TotalPreviousYearRefreshSales').uid
  //     // this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[2].querySelector('[e-mappinguid="grid-column9"]').innerHTML = "23324%"
  //   }
  //   switch (FieldName) {
  //     case "Country1PercentageOfConsumption": {
  //       let currentValue = args.rowData['IFFCurrentYearSales'] * (args.value / 100);
  //       let previousValue = 0;
  //       // if(args.rowData['Country1PercentageOfConsumption'] == args.previousValue){
  //       //   previousValue = args.rowData['IFFCurrentYearSales'] * (args.rowData['Country1PercentageOfConsumption'] / 100);
  //       // }else{
  //       previousValue = args.rowData['IFFCurrentYearSales'] * (args.previousValue / 100);
  //       // }
  //       let index = this.grid.getColumnIndexByField(FieldName);
  //       // args.cell.parentElement.querySelector('[aria-colindex="8"]');
  //       // let selector = '[aria-colindex="8"]';
  //       let selector = "[aria-colindex=\'" + (index + 1) + "\']";
  //       args.cell.parentElement.querySelector(selector).innerHTML = currentValue;
  //       let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField('Country1ValueOfConsumption') as any).uid + "\']";
  //       let consumption1ValueCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
  //       let cellValue = consumption1ValueCell.innerHTML.replace(/[$ OR \s]/g, "");
  //       let calcField = Number(cellValue) + (currentValue - previousValue);
  //       consumption1ValueCell.innerHTML = "$" + calcField.toString();
  //       break;
  //     }
  //     // case "Country1PercentageOfConsumption": {
  //     //   let Country1PercentageOfConsumption = 0;
  //     //   data.forEach(element => {
  //     //     if (args.rowData.taskId === element['taskId']) {
  //     //       Country1PercentageOfConsumption += element['IFFCurrentYearSales'] * args.value / 100;
  //     //     } else {
  //     //       Country1PercentageOfConsumption += element['IFFCurrentYearSales'] * element['Country1PercentageOfConsumption'] / 100;
  //     //     }
  //     //   });
  //     //   let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField('Country1ValueOfConsumption') as any).uid + "\']";
  //     //   let consumption1ValueCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
  //     //   consumption1ValueCell.innerHTML = "$" + Country1PercentageOfConsumption.toString();
  //     //   break;
  //     // }
  //     case "Country2PercentageOfConsumption": {
  //       let Country2PercentageOfConsumption = 0;
  //       data.forEach(element => {
  //         if (args.rowData.taskId === element['taskId']) {
  //           Country2PercentageOfConsumption += element['IFFCurrentYearSales'] * args.value / 100;
  //         } else {
  //           Country2PercentageOfConsumption += element['IFFCurrentYearSales'] * element['Country2PercentageOfConsumption'] / 100;
  //         }
  //       });
  //       let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField('Country2ValueOfConsumption') as any).uid + "\']";
  //       let ConsuptionValueCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
  //       ConsuptionValueCell.innerHTML = "$" + Country2PercentageOfConsumption.toString();
  //       break;
  //     }
  //     case "Country3PercentageOfConsumption": {
  //       let Country3PercentageOfConsumption = 0;
  //       data.forEach(element => {
  //         if (args.rowData.taskId === element['taskId']) {
  //           Country3PercentageOfConsumption += element['IFFCurrentYearSales'] * args.value / 100;
  //         } else {
  //           Country3PercentageOfConsumption += element['IFFCurrentYearSales'] * element['Country3PercentageOfConsumption'] / 100;
  //         }
  //       });
  //       let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField('Country3ValueOfConsumption') as any).uid + "\']";
  //       let ConsuptionValueCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
  //       ConsuptionValueCell.innerHTML = "$" + Country3PercentageOfConsumption.toString();
  //       break;
  //     }
  //     case "Country4PercentageOfConsumption": {
  //       let Country4PercentageOfConsumption = 0;
  //       data.forEach(element => {
  //         if (args.rowData.taskId === element['taskId']) {
  //           Country4PercentageOfConsumption += element['IFFCurrentYearSales'] * args.value / 100;
  //         } else {
  //           Country4PercentageOfConsumption += element['IFFCurrentYearSales'] * element['Country4PercentageOfConsumption'] / 100;
  //         }
  //       });
  //       let selector1 = "[e-mappinguid=\'" + (this.grid.getColumnByField('Country4ValueOfConsumption') as any).uid + "\']";
  //       let ConsuptionValueCell = this.grid.element.querySelector('.e-movablefootercontent').querySelectorAll('.e-summaryrow')[0].querySelector(selector1);
  //       ConsuptionValueCell.innerHTML = "$" + Country4PercentageOfConsumption.toString();
  //       break;
  //     }
  //     default: {
  //       break;
  //     }
  //   }
  // }
}
//   public data: Object[];
//   public editSettings: Object;
//   public toolbar: string[];
//   public orderidrules: Object;
//   public customeridrules: Object;
//   public freightrules: Object;
//   public editparams: Object;
//   public pageSettings: Object;
//   constructor() { }

//   ngOnInit() {
//     this.data = [
//       {
//         "OrderID": 10248,
//         "CustomerID": "VINET",
//         "EmployeeID": 5,
//         "OrderDate": "1996-07-04T00:00:00Z",
//         "RequiredDate": "1996-08-01T00:00:00Z",
//         "ShippedDate": "1996-07-16T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 32.3800,
//         "ShipName": "Vins et alcools Chevalier",
//         "ShipAddress": "59 rue de l'Abbaye",
//         "ShipCity": "Reims",
//         "ShipRegion": null,
//         "ShipPostalCode": "51100",
//         "ShipCountry": "France"
//       },
//       {
//         "OrderID": 10249,
//         "CustomerID": "TOMSP",
//         "EmployeeID": 6,
//         "OrderDate": "1996-07-05T00:00:00Z",
//         "RequiredDate": "1996-08-16T00:00:00Z",
//         "ShippedDate": "1996-07-10T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 11.6100,
//         "ShipName": "Toms Spezialit\u00e4ten",
//         "ShipAddress": "Luisenstr. 48",
//         "ShipCity": "M\u00fcnster",
//         "ShipRegion": null,
//         "ShipPostalCode": "44087",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10250,
//         "CustomerID": "HANAR",
//         "EmployeeID": 4,
//         "OrderDate": "1996-07-08T00:00:00Z",
//         "RequiredDate": "1996-08-05T00:00:00Z",
//         "ShippedDate": "1996-07-12T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 65.8300,
//         "ShipName": "Hanari Carnes",
//         "ShipAddress": "Rua do Pa\u00e7o, 67",
//         "ShipCity": "Rio de Janeiro",
//         "ShipRegion": "RJ",
//         "ShipPostalCode": "05454-876",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10251,
//         "CustomerID": "VICTE",
//         "EmployeeID": 3,
//         "OrderDate": "1996-07-08T00:00:00Z",
//         "RequiredDate": "1996-08-05T00:00:00Z",
//         "ShippedDate": "1996-07-15T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 41.3400,
//         "ShipName": "Victuailles en stock",
//         "ShipAddress": "2, rue du Commerce",
//         "ShipCity": "Lyon",
//         "ShipRegion": null,
//         "ShipPostalCode": "69004",
//         "ShipCountry": "France"
//       },
//       {
//         "OrderID": 10252,
//         "CustomerID": "SUPRD",
//         "EmployeeID": 4,
//         "OrderDate": "1996-07-09T00:00:00Z",
//         "RequiredDate": "1996-08-06T00:00:00Z",
//         "ShippedDate": "1996-07-11T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 51.3000,
//         "ShipName": "Supr\u00eames d\u00e9lices",
//         "ShipAddress": "Boulevard Tirou, 255",
//         "ShipCity": "Charleroi",
//         "ShipRegion": null,
//         "ShipPostalCode": "B-6000",
//         "ShipCountry": "Belgium"
//       },
//       {
//         "OrderID": 10253,
//         "CustomerID": "HANAR",
//         "EmployeeID": 3,
//         "OrderDate": "1996-07-10T00:00:00Z",
//         "RequiredDate": "1996-07-24T00:00:00Z",
//         "ShippedDate": "1996-07-16T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 58.1700,
//         "ShipName": "Hanari Carnes",
//         "ShipAddress": "Rua do Pa\u00e7o, 67",
//         "ShipCity": "Rio de Janeiro",
//         "ShipRegion": "RJ",
//         "ShipPostalCode": "05454-876",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10254,
//         "CustomerID": "CHOPS",
//         "EmployeeID": 5,
//         "OrderDate": "1996-07-11T00:00:00Z",
//         "RequiredDate": "1996-08-08T00:00:00Z",
//         "ShippedDate": "1996-07-23T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 22.9800,
//         "ShipName": "Chop-suey Chinese",
//         "ShipAddress": "Hauptstr. 31",
//         "ShipCity": "Bern",
//         "ShipRegion": null,
//         "ShipPostalCode": "3012",
//         "ShipCountry": "Switzerland"
//       },
//       {
//         "OrderID": 10255,
//         "CustomerID": "RICSU",
//         "EmployeeID": 9,
//         "OrderDate": "1996-07-12T00:00:00Z",
//         "RequiredDate": "1996-08-09T00:00:00Z",
//         "ShippedDate": "1996-07-15T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 148.3300,
//         "ShipName": "Richter Supermarkt",
//         "ShipAddress": "Starenweg 5",
//         "ShipCity": "Gen\u00e8ve",
//         "ShipRegion": null,
//         "ShipPostalCode": "1204",
//         "ShipCountry": "Switzerland"
//       },
//       {
//         "OrderID": 10256,
//         "CustomerID": "WELLI",
//         "EmployeeID": 3,
//         "OrderDate": "1996-07-15T00:00:00Z",
//         "RequiredDate": "1996-08-12T00:00:00Z",
//         "ShippedDate": "1996-07-17T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 13.9700,
//         "ShipName": "Wellington Importadora",
//         "ShipAddress": "Rua do Mercado, 12",
//         "ShipCity": "Resende",
//         "ShipRegion": "SP",
//         "ShipPostalCode": "08737-363",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10257,
//         "CustomerID": "HILAA",
//         "EmployeeID": 4,
//         "OrderDate": "1996-07-16T00:00:00Z",
//         "RequiredDate": "1996-08-13T00:00:00Z",
//         "ShippedDate": "1996-07-22T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 81.9100,
//         "ShipName": "HILARION-Abastos",
//         "ShipAddress": "Carrera 22 con Ave. Carlos Soublette #8-35",
//         "ShipCity": "San Crist\u00f3bal",
//         "ShipRegion": "T\u00e1chira",
//         "ShipPostalCode": "5022",
//         "ShipCountry": "Venezuela"
//       },
//       {
//         "OrderID": 10258,
//         "CustomerID": "ERNSH",
//         "EmployeeID": 1,
//         "OrderDate": "1996-07-17T00:00:00Z",
//         "RequiredDate": "1996-08-14T00:00:00Z",
//         "ShippedDate": "1996-07-23T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 140.5100,
//         "ShipName": "Ernst Handel",
//         "ShipAddress": "Kirchgasse 6",
//         "ShipCity": "Graz",
//         "ShipRegion": null,
//         "ShipPostalCode": "8010",
//         "ShipCountry": "Austria"
//       },
//       {
//         "OrderID": 10259,
//         "CustomerID": "CENTC",
//         "EmployeeID": 4,
//         "OrderDate": "1996-07-18T00:00:00Z",
//         "RequiredDate": "1996-08-15T00:00:00Z",
//         "ShippedDate": "1996-07-25T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 3.2500,
//         "ShipName": "Centro comercial Moctezuma",
//         "ShipAddress": "Sierras de Granada 9993",
//         "ShipCity": "M\u00e9xico D.F.",
//         "ShipRegion": null,
//         "ShipPostalCode": "05022",
//         "ShipCountry": "Mexico"
//       },
//       {
//         "OrderID": 10260,
//         "CustomerID": "OTTIK",
//         "EmployeeID": 4,
//         "OrderDate": "1996-07-19T00:00:00Z",
//         "RequiredDate": "1996-08-16T00:00:00Z",
//         "ShippedDate": "1996-07-29T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 55.0900,
//         "ShipName": "Ottilies K\u00e4seladen",
//         "ShipAddress": "Mehrheimerstr. 369",
//         "ShipCity": "K\u00f6ln",
//         "ShipRegion": null,
//         "ShipPostalCode": "50739",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10261,
//         "CustomerID": "QUEDE",
//         "EmployeeID": 4,
//         "OrderDate": "1996-07-19T00:00:00Z",
//         "RequiredDate": "1996-08-16T00:00:00Z",
//         "ShippedDate": "1996-07-30T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 3.0500,
//         "ShipName": "Que Del\u00edcia",
//         "ShipAddress": "Rua da Panificadora, 12",
//         "ShipCity": "Rio de Janeiro",
//         "ShipRegion": "RJ",
//         "ShipPostalCode": "02389-673",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10262,
//         "CustomerID": "RATTC",
//         "EmployeeID": 8,
//         "OrderDate": "1996-07-22T00:00:00Z",
//         "RequiredDate": "1996-08-19T00:00:00Z",
//         "ShippedDate": "1996-07-25T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 48.2900,
//         "ShipName": "Rattlesnake Canyon Grocery",
//         "ShipAddress": "2817 Milton Dr.",
//         "ShipCity": "Albuquerque",
//         "ShipRegion": "NM",
//         "ShipPostalCode": "87110",
//         "ShipCountry": "USA"
//       },
//       {
//         "OrderID": 10263,
//         "CustomerID": "ERNSH",
//         "EmployeeID": 9,
//         "OrderDate": "1996-07-23T00:00:00Z",
//         "RequiredDate": "1996-08-20T00:00:00Z",
//         "ShippedDate": "1996-07-31T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 146.0600,
//         "ShipName": "Ernst Handel",
//         "ShipAddress": "Kirchgasse 6",
//         "ShipCity": "Graz",
//         "ShipRegion": null,
//         "ShipPostalCode": "8010",
//         "ShipCountry": "Austria"
//       },
//       {
//         "OrderID": 10264,
//         "CustomerID": "FOLKO",
//         "EmployeeID": 6,
//         "OrderDate": "1996-07-24T00:00:00Z",
//         "RequiredDate": "1996-08-21T00:00:00Z",
//         "ShippedDate": "1996-08-23T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 3.6700,
//         "ShipName": "Folk och f\u00e4 HB",
//         "ShipAddress": "\u00c5kergatan 24",
//         "ShipCity": "Br\u00e4cke",
//         "ShipRegion": null,
//         "ShipPostalCode": "S-844 67",
//         "ShipCountry": "Sweden"
//       },
//       {
//         "OrderID": 10265,
//         "CustomerID": "BLONP",
//         "EmployeeID": 2,
//         "OrderDate": "1996-07-25T00:00:00Z",
//         "RequiredDate": "1996-08-22T00:00:00Z",
//         "ShippedDate": "1996-08-12T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 55.2800,
//         "ShipName": "Blondel p\u00e8re et fils",
//         "ShipAddress": "24, place Kl\u00e9ber",
//         "ShipCity": "Strasbourg",
//         "ShipRegion": null,
//         "ShipPostalCode": "67000",
//         "ShipCountry": "France"
//       },
//       {
//         "OrderID": 10266,
//         "CustomerID": "WARTH",
//         "EmployeeID": 3,
//         "OrderDate": "1996-07-26T00:00:00Z",
//         "RequiredDate": "1996-09-06T00:00:00Z",
//         "ShippedDate": "1996-07-31T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 25.7300,
//         "ShipName": "Wartian Herkku",
//         "ShipAddress": "Torikatu 38",
//         "ShipCity": "Oulu",
//         "ShipRegion": null,
//         "ShipPostalCode": "90110",
//         "ShipCountry": "Finland"
//       },
//       {
//         "OrderID": 10267,
//         "CustomerID": "FRANK",
//         "EmployeeID": 4,
//         "OrderDate": "1996-07-29T00:00:00Z",
//         "RequiredDate": "1996-08-26T00:00:00Z",
//         "ShippedDate": "1996-08-06T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 208.5800,
//         "ShipName": "Frankenversand",
//         "ShipAddress": "Berliner Platz 43",
//         "ShipCity": "M\u00fcnchen",
//         "ShipRegion": null,
//         "ShipPostalCode": "80805",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10268,
//         "CustomerID": "GROSR",
//         "EmployeeID": 8,
//         "OrderDate": "1996-07-30T00:00:00Z",
//         "RequiredDate": "1996-08-27T00:00:00Z",
//         "ShippedDate": "1996-08-02T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 66.2900,
//         "ShipName": "GROSELLA-Restaurante",
//         "ShipAddress": "5\u00aa Ave. Los Palos Grandes",
//         "ShipCity": "Caracas",
//         "ShipRegion": "DF",
//         "ShipPostalCode": "1081",
//         "ShipCountry": "Venezuela"
//       },
//       {
//         "OrderID": 10269,
//         "CustomerID": "WHITC",
//         "EmployeeID": 5,
//         "OrderDate": "1996-07-31T00:00:00Z",
//         "RequiredDate": "1996-08-14T00:00:00Z",
//         "ShippedDate": "1996-08-09T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 4.5600,
//         "ShipName": "White Clover Markets",
//         "ShipAddress": "1029 - 12th Ave. S.",
//         "ShipCity": "Seattle",
//         "ShipRegion": "WA",
//         "ShipPostalCode": "98124",
//         "ShipCountry": "USA"
//       },
//       {
//         "OrderID": 10270,
//         "CustomerID": "WARTH",
//         "EmployeeID": 1,
//         "OrderDate": "1996-08-01T00:00:00Z",
//         "RequiredDate": "1996-08-29T00:00:00Z",
//         "ShippedDate": "1996-08-02T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 136.5400,
//         "ShipName": "Wartian Herkku",
//         "ShipAddress": "Torikatu 38",
//         "ShipCity": "Oulu",
//         "ShipRegion": null,
//         "ShipPostalCode": "90110",
//         "ShipCountry": "Finland"
//       },
//       {
//         "OrderID": 10271,
//         "CustomerID": "SPLIR",
//         "EmployeeID": 6,
//         "OrderDate": "1996-08-01T00:00:00Z",
//         "RequiredDate": "1996-08-29T00:00:00Z",
//         "ShippedDate": "1996-08-30T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 4.5400,
//         "ShipName": "Split Rail Beer & Ale",
//         "ShipAddress": "P.O. Box 555",
//         "ShipCity": "Lander",
//         "ShipRegion": "WY",
//         "ShipPostalCode": "82520",
//         "ShipCountry": "USA"
//       },
//       {
//         "OrderID": 10272,
//         "CustomerID": "RATTC",
//         "EmployeeID": 6,
//         "OrderDate": "1996-08-02T00:00:00Z",
//         "RequiredDate": "1996-08-30T00:00:00Z",
//         "ShippedDate": "1996-08-06T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 98.0300,
//         "ShipName": "Rattlesnake Canyon Grocery",
//         "ShipAddress": "2817 Milton Dr.",
//         "ShipCity": "Albuquerque",
//         "ShipRegion": "NM",
//         "ShipPostalCode": "87110",
//         "ShipCountry": "USA"
//       },
//       {
//         "OrderID": 10273,
//         "CustomerID": "QUICK",
//         "EmployeeID": 3,
//         "OrderDate": "1996-08-05T00:00:00Z",
//         "RequiredDate": "1996-09-02T00:00:00Z",
//         "ShippedDate": "1996-08-12T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 76.0700,
//         "ShipName": "QUICK-Stop",
//         "ShipAddress": "Taucherstra\u00dfe 10",
//         "ShipCity": "Cunewalde",
//         "ShipRegion": null,
//         "ShipPostalCode": "01307",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10274,
//         "CustomerID": "VINET",
//         "EmployeeID": 6,
//         "OrderDate": "1996-08-06T00:00:00Z",
//         "RequiredDate": "1996-09-03T00:00:00Z",
//         "ShippedDate": "1996-08-16T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 6.0100,
//         "ShipName": "Vins et alcools Chevalier",
//         "ShipAddress": "59 rue de l'Abbaye",
//         "ShipCity": "Reims",
//         "ShipRegion": null,
//         "ShipPostalCode": "51100",
//         "ShipCountry": "France"
//       },
//       {
//         "OrderID": 10275,
//         "CustomerID": "MAGAA",
//         "EmployeeID": 1,
//         "OrderDate": "1996-08-07T00:00:00Z",
//         "RequiredDate": "1996-09-04T00:00:00Z",
//         "ShippedDate": "1996-08-09T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 26.9300,
//         "ShipName": "Magazzini Alimentari Riuniti",
//         "ShipAddress": "Via Ludovico il Moro 22",
//         "ShipCity": "Bergamo",
//         "ShipRegion": null,
//         "ShipPostalCode": "24100",
//         "ShipCountry": "Italy"
//       },
//       {
//         "OrderID": 10276,
//         "CustomerID": "TORTU",
//         "EmployeeID": 8,
//         "OrderDate": "1996-08-08T00:00:00Z",
//         "RequiredDate": "1996-08-22T00:00:00Z",
//         "ShippedDate": "1996-08-14T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 13.8400,
//         "ShipName": "Tortuga Restaurante",
//         "ShipAddress": "Avda. Azteca 123",
//         "ShipCity": "M\u00e9xico D.F.",
//         "ShipRegion": null,
//         "ShipPostalCode": "05033",
//         "ShipCountry": "Mexico"
//       },
//       {
//         "OrderID": 10277,
//         "CustomerID": "MORGK",
//         "EmployeeID": 2,
//         "OrderDate": "1996-08-09T00:00:00Z",
//         "RequiredDate": "1996-09-06T00:00:00Z",
//         "ShippedDate": "1996-08-13T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 125.7700,
//         "ShipName": "Morgenstern Gesundkost",
//         "ShipAddress": "Heerstr. 22",
//         "ShipCity": "Leipzig",
//         "ShipRegion": null,
//         "ShipPostalCode": "04179",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10278,
//         "CustomerID": "BERGS",
//         "EmployeeID": 8,
//         "OrderDate": "1996-08-12T00:00:00Z",
//         "RequiredDate": "1996-09-09T00:00:00Z",
//         "ShippedDate": "1996-08-16T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 92.6900,
//         "ShipName": "Berglunds snabbk\u00f6p",
//         "ShipAddress": "Berguvsv\u00e4gen  8",
//         "ShipCity": "Lule\u00e5",
//         "ShipRegion": null,
//         "ShipPostalCode": "S-958 22",
//         "ShipCountry": "Sweden"
//       },
//       {
//         "OrderID": 10279,
//         "CustomerID": "LEHMS",
//         "EmployeeID": 8,
//         "OrderDate": "1996-08-13T00:00:00Z",
//         "RequiredDate": "1996-09-10T00:00:00Z",
//         "ShippedDate": "1996-08-16T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 25.8300,
//         "ShipName": "Lehmanns Marktstand",
//         "ShipAddress": "Magazinweg 7",
//         "ShipCity": "Frankfurt a.M.",
//         "ShipRegion": null,
//         "ShipPostalCode": "60528",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10280,
//         "CustomerID": "BERGS",
//         "EmployeeID": 2,
//         "OrderDate": "1996-08-14T00:00:00Z",
//         "RequiredDate": "1996-09-11T00:00:00Z",
//         "ShippedDate": "1996-09-12T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 8.9800,
//         "ShipName": "Berglunds snabbk\u00f6p",
//         "ShipAddress": "Berguvsv\u00e4gen  8",
//         "ShipCity": "Lule\u00e5",
//         "ShipRegion": null,
//         "ShipPostalCode": "S-958 22",
//         "ShipCountry": "Sweden"
//       },
//       {
//         "OrderID": 10281,
//         "CustomerID": "ROMEY",
//         "EmployeeID": 4,
//         "OrderDate": "1996-08-14T00:00:00Z",
//         "RequiredDate": "1996-08-28T00:00:00Z",
//         "ShippedDate": "1996-08-21T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 2.9400,
//         "ShipName": "Romero y tomillo",
//         "ShipAddress": "Gran V\u00eda, 1",
//         "ShipCity": "Madrid",
//         "ShipRegion": null,
//         "ShipPostalCode": "28001",
//         "ShipCountry": "Spain"
//       },
//       {
//         "OrderID": 10282,
//         "CustomerID": "ROMEY",
//         "EmployeeID": 4,
//         "OrderDate": "1996-08-15T00:00:00Z",
//         "RequiredDate": "1996-09-12T00:00:00Z",
//         "ShippedDate": "1996-08-21T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 12.6900,
//         "ShipName": "Romero y tomillo",
//         "ShipAddress": "Gran V\u00eda, 1",
//         "ShipCity": "Madrid",
//         "ShipRegion": null,
//         "ShipPostalCode": "28001",
//         "ShipCountry": "Spain"
//       },
//       {
//         "OrderID": 10283,
//         "CustomerID": "LILAS",
//         "EmployeeID": 3,
//         "OrderDate": "1996-08-16T00:00:00Z",
//         "RequiredDate": "1996-09-13T00:00:00Z",
//         "ShippedDate": "1996-08-23T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 84.8100,
//         "ShipName": "LILA-Supermercado",
//         "ShipAddress": "Carrera 52 con Ave. Bol\u00edvar #65-98 Llano Largo",
//         "ShipCity": "Barquisimeto",
//         "ShipRegion": "Lara",
//         "ShipPostalCode": "3508",
//         "ShipCountry": "Venezuela"
//       },
//       {
//         "OrderID": 10284,
//         "CustomerID": "LEHMS",
//         "EmployeeID": 4,
//         "OrderDate": "1996-08-19T00:00:00Z",
//         "RequiredDate": "1996-09-16T00:00:00Z",
//         "ShippedDate": "1996-08-27T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 76.5600,
//         "ShipName": "Lehmanns Marktstand",
//         "ShipAddress": "Magazinweg 7",
//         "ShipCity": "Frankfurt a.M.",
//         "ShipRegion": null,
//         "ShipPostalCode": "60528",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10285,
//         "CustomerID": "QUICK",
//         "EmployeeID": 1,
//         "OrderDate": "1996-08-20T00:00:00Z",
//         "RequiredDate": "1996-09-17T00:00:00Z",
//         "ShippedDate": "1996-08-26T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 76.8300,
//         "ShipName": "QUICK-Stop",
//         "ShipAddress": "Taucherstra\u00dfe 10",
//         "ShipCity": "Cunewalde",
//         "ShipRegion": null,
//         "ShipPostalCode": "01307",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10286,
//         "CustomerID": "QUICK",
//         "EmployeeID": 8,
//         "OrderDate": "1996-08-21T00:00:00Z",
//         "RequiredDate": "1996-09-18T00:00:00Z",
//         "ShippedDate": "1996-08-30T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 229.2400,
//         "ShipName": "QUICK-Stop",
//         "ShipAddress": "Taucherstra\u00dfe 10",
//         "ShipCity": "Cunewalde",
//         "ShipRegion": null,
//         "ShipPostalCode": "01307",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10287,
//         "CustomerID": "RICAR",
//         "EmployeeID": 8,
//         "OrderDate": "1996-08-22T00:00:00Z",
//         "RequiredDate": "1996-09-19T00:00:00Z",
//         "ShippedDate": "1996-08-28T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 12.7600,
//         "ShipName": "Ricardo Adocicados",
//         "ShipAddress": "Av. Copacabana, 267",
//         "ShipCity": "Rio de Janeiro",
//         "ShipRegion": "RJ",
//         "ShipPostalCode": "02389-890",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10288,
//         "CustomerID": "REGGC",
//         "EmployeeID": 4,
//         "OrderDate": "1996-08-23T00:00:00Z",
//         "RequiredDate": "1996-09-20T00:00:00Z",
//         "ShippedDate": "1996-09-03T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 7.4500,
//         "ShipName": "Reggiani Caseifici",
//         "ShipAddress": "Strada Provinciale 124",
//         "ShipCity": "Reggio Emilia",
//         "ShipRegion": null,
//         "ShipPostalCode": "42100",
//         "ShipCountry": "Italy"
//       },
//       {
//         "OrderID": 10289,
//         "CustomerID": "BSBEV",
//         "EmployeeID": 7,
//         "OrderDate": "1996-08-26T00:00:00Z",
//         "RequiredDate": "1996-09-23T00:00:00Z",
//         "ShippedDate": "1996-08-28T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 22.7700,
//         "ShipName": "B's Beverages",
//         "ShipAddress": "Fauntleroy Circus",
//         "ShipCity": "London",
//         "ShipRegion": null,
//         "ShipPostalCode": "EC2 5NT",
//         "ShipCountry": "UK"
//       },
//       {
//         "OrderID": 10290,
//         "CustomerID": "COMMI",
//         "EmployeeID": 8,
//         "OrderDate": "1996-08-27T00:00:00Z",
//         "RequiredDate": "1996-09-24T00:00:00Z",
//         "ShippedDate": "1996-09-03T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 79.7000,
//         "ShipName": "Com\u00e9rcio Mineiro",
//         "ShipAddress": "Av. dos Lus\u00edadas, 23",
//         "ShipCity": "Sao Paulo",
//         "ShipRegion": "SP",
//         "ShipPostalCode": "05432-043",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10291,
//         "CustomerID": "QUEDE",
//         "EmployeeID": 6,
//         "OrderDate": "1996-08-27T00:00:00Z",
//         "RequiredDate": "1996-09-24T00:00:00Z",
//         "ShippedDate": "1996-09-04T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 6.4000,
//         "ShipName": "Que Del\u00edcia",
//         "ShipAddress": "Rua da Panificadora, 12",
//         "ShipCity": "Rio de Janeiro",
//         "ShipRegion": "RJ",
//         "ShipPostalCode": "02389-673",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10292,
//         "CustomerID": "TRADH",
//         "EmployeeID": 1,
//         "OrderDate": "1996-08-28T00:00:00Z",
//         "RequiredDate": "1996-09-25T00:00:00Z",
//         "ShippedDate": "1996-09-02T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 1.3500,
//         "ShipName": "Tradi\u00e7ao Hipermercados",
//         "ShipAddress": "Av. In\u00eas de Castro, 414",
//         "ShipCity": "Sao Paulo",
//         "ShipRegion": "SP",
//         "ShipPostalCode": "05634-030",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10293,
//         "CustomerID": "TORTU",
//         "EmployeeID": 1,
//         "OrderDate": "1996-08-29T00:00:00Z",
//         "RequiredDate": "1996-09-26T00:00:00Z",
//         "ShippedDate": "1996-09-11T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 21.1800,
//         "ShipName": "Tortuga Restaurante",
//         "ShipAddress": "Avda. Azteca 123",
//         "ShipCity": "M\u00e9xico D.F.",
//         "ShipRegion": null,
//         "ShipPostalCode": "05033",
//         "ShipCountry": "Mexico"
//       },
//       {
//         "OrderID": 10294,
//         "CustomerID": "RATTC",
//         "EmployeeID": 4,
//         "OrderDate": "1996-08-30T00:00:00Z",
//         "RequiredDate": "1996-09-27T00:00:00Z",
//         "ShippedDate": "1996-09-05T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 147.2600,
//         "ShipName": "Rattlesnake Canyon Grocery",
//         "ShipAddress": "2817 Milton Dr.",
//         "ShipCity": "Albuquerque",
//         "ShipRegion": "NM",
//         "ShipPostalCode": "87110",
//         "ShipCountry": "USA"
//       },
//       {
//         "OrderID": 10295,
//         "CustomerID": "VINET",
//         "EmployeeID": 2,
//         "OrderDate": "1996-09-02T00:00:00Z",
//         "RequiredDate": "1996-09-30T00:00:00Z",
//         "ShippedDate": "1996-09-10T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 1.1500,
//         "ShipName": "Vins et alcools Chevalier",
//         "ShipAddress": "59 rue de l'Abbaye",
//         "ShipCity": "Reims",
//         "ShipRegion": null,
//         "ShipPostalCode": "51100",
//         "ShipCountry": "France"
//       },
//       {
//         "OrderID": 10296,
//         "CustomerID": "LILAS",
//         "EmployeeID": 6,
//         "OrderDate": "1996-09-03T00:00:00Z",
//         "RequiredDate": "1996-10-01T00:00:00Z",
//         "ShippedDate": "1996-09-11T00:00:00Z",
//         "ShipVia": 1,
//         "Freight": 0.1200,
//         "ShipName": "LILA-Supermercado",
//         "ShipAddress": "Carrera 52 con Ave. Bol\u00edvar #65-98 Llano Largo",
//         "ShipCity": "Barquisimeto",
//         "ShipRegion": "Lara",
//         "ShipPostalCode": "3508",
//         "ShipCountry": "Venezuela"
//       },
//       {
//         "OrderID": 10297,
//         "CustomerID": "BLONP",
//         "EmployeeID": 5,
//         "OrderDate": "1996-09-04T00:00:00Z",
//         "RequiredDate": "1996-10-16T00:00:00Z",
//         "ShippedDate": "1996-09-10T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 5.7400,
//         "ShipName": "Blondel p\u00e8re et fils",
//         "ShipAddress": "24, place Kl\u00e9ber",
//         "ShipCity": "Strasbourg",
//         "ShipRegion": null,
//         "ShipPostalCode": "67000",
//         "ShipCountry": "France"
//       },
//       {
//         "OrderID": 10298,
//         "CustomerID": "HUNGO",
//         "EmployeeID": 6,
//         "OrderDate": "1996-09-05T00:00:00Z",
//         "RequiredDate": "1996-10-03T00:00:00Z",
//         "ShippedDate": "1996-09-11T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 168.2200,
//         "ShipName": "Hungry Owl All-Night Grocers",
//         "ShipAddress": "8 Johnstown Road",
//         "ShipCity": "Cork",
//         "ShipRegion": "Co. Cork",
//         "ShipPostalCode": null,
//         "ShipCountry": "Ireland"
//       },
//       {
//         "OrderID": 10299,
//         "CustomerID": "RICAR",
//         "EmployeeID": 4,
//         "OrderDate": "1996-09-06T00:00:00Z",
//         "RequiredDate": "1996-10-04T00:00:00Z",
//         "ShippedDate": "1996-09-13T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 29.7600,
//         "ShipName": "Ricardo Adocicados",
//         "ShipAddress": "Av. Copacabana, 267",
//         "ShipCity": "Rio de Janeiro",
//         "ShipRegion": "RJ",
//         "ShipPostalCode": "02389-890",
//         "ShipCountry": "Brazil"
//       },
//       {
//         "OrderID": 10300,
//         "CustomerID": "MAGAA",
//         "EmployeeID": 2,
//         "OrderDate": "1996-09-09T00:00:00Z",
//         "RequiredDate": "1996-10-07T00:00:00Z",
//         "ShippedDate": "1996-09-18T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 17.6800,
//         "ShipName": "Magazzini Alimentari Riuniti",
//         "ShipAddress": "Via Ludovico il Moro 22",
//         "ShipCity": "Bergamo",
//         "ShipRegion": null,
//         "ShipPostalCode": "24100",
//         "ShipCountry": "Italy"
//       },
//       {
//         "OrderID": 10301,
//         "CustomerID": "WANDK",
//         "EmployeeID": 8,
//         "OrderDate": "1996-09-09T00:00:00Z",
//         "RequiredDate": "1996-10-07T00:00:00Z",
//         "ShippedDate": "1996-09-17T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 45.0800,
//         "ShipName": "Die Wandernde Kuh",
//         "ShipAddress": "Adenauerallee 900",
//         "ShipCity": "Stuttgart",
//         "ShipRegion": null,
//         "ShipPostalCode": "70563",
//         "ShipCountry": "Germany"
//       },
//       {
//         "OrderID": 10302,
//         "CustomerID": "SUPRD",
//         "EmployeeID": 4,
//         "OrderDate": "1996-09-10T00:00:00Z",
//         "RequiredDate": "1996-10-08T00:00:00Z",
//         "ShippedDate": "1996-10-09T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 6.2700,
//         "ShipName": "Supr\u00eames d\u00e9lices",
//         "ShipAddress": "Boulevard Tirou, 255",
//         "ShipCity": "Charleroi",
//         "ShipRegion": null,
//         "ShipPostalCode": "B-6000",
//         "ShipCountry": "Belgium"
//       },
//       {
//         "OrderID": 10303,
//         "CustomerID": "GODOS",
//         "EmployeeID": 7,
//         "OrderDate": "1996-09-11T00:00:00Z",
//         "RequiredDate": "1996-10-09T00:00:00Z",
//         "ShippedDate": "1996-09-18T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 107.8300,
//         "ShipName": "Godos Cocina T\u00edpica",
//         "ShipAddress": "C/ Romero, 33",
//         "ShipCity": "Sevilla",
//         "ShipRegion": null,
//         "ShipPostalCode": "41101",
//         "ShipCountry": "Spain"
//       },
//       {
//         "OrderID": 10304,
//         "CustomerID": "TORTU",
//         "EmployeeID": 1,
//         "OrderDate": "1996-09-12T00:00:00Z",
//         "RequiredDate": "1996-10-10T00:00:00Z",
//         "ShippedDate": "1996-09-17T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 63.7900,
//         "ShipName": "Tortuga Restaurante",
//         "ShipAddress": "Avda. Azteca 123",
//         "ShipCity": "M\u00e9xico D.F.",
//         "ShipRegion": null,
//         "ShipPostalCode": "05033",
//         "ShipCountry": "Mexico"
//       },
//       {
//         "OrderID": 10305,
//         "CustomerID": "OLDWO",
//         "EmployeeID": 8,
//         "OrderDate": "1996-09-13T00:00:00Z",
//         "RequiredDate": "1996-10-11T00:00:00Z",
//         "ShippedDate": "1996-10-09T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 257.6200,
//         "ShipName": "Old World Delicatessen",
//         "ShipAddress": "2743 Bering St.",
//         "ShipCity": "Anchorage",
//         "ShipRegion": "AK",
//         "ShipPostalCode": "99508",
//         "ShipCountry": "USA"
//       },
//       {
//         "OrderID": 10306,
//         "CustomerID": "ROMEY",
//         "EmployeeID": 1,
//         "OrderDate": "1996-09-16T00:00:00Z",
//         "RequiredDate": "1996-10-14T00:00:00Z",
//         "ShippedDate": "1996-09-23T00:00:00Z",
//         "ShipVia": 3,
//         "Freight": 7.5600,
//         "ShipName": "Romero y tomillo",
//         "ShipAddress": "Gran V\u00eda, 1",
//         "ShipCity": "Madrid",
//         "ShipRegion": null,
//         "ShipPostalCode": "28001",
//         "ShipCountry": "Spain"
//       },
//       {
//         "OrderID": 10307,
//         "CustomerID": "LONEP",
//         "EmployeeID": 2,
//         "OrderDate": "1996-09-17T00:00:00Z",
//         "RequiredDate": "1996-10-15T00:00:00Z",
//         "ShippedDate": "1996-09-25T00:00:00Z",
//         "ShipVia": 2,
//         "Freight": 0.5600,
//         "ShipName": "Lonesome Pine Restaurant",
//         "ShipAddress": "89 Chiaroscuro Rd.",
//         "ShipCity": "Portland",
//         "ShipRegion": "OR",
//         "ShipPostalCode": "97219",
//         "ShipCountry": "USA"
//       }
//     ];
//     this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Batch' };
//     this.toolbar = ['ColumnChooser'];
//     this.orderidrules = { required: true, number: true };
//     this.customeridrules = { required: true };
//     this.freightrules =  { required: true };
//     this.editparams = { params: { popupHeight: '300px' }};
//     this.pageSettings = {pageCount: 5};
//   }
//   public canDeactivate(){
// return false;
//   }

// }
