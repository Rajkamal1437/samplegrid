import { Component, OnInit, ViewChild } from '@angular/core';
import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { PercentPipe } from '@angular/common';
import { SharedConstant } from '../shared-constant.config';
import { ValidationService } from './validation.service';
import { Internationalization } from '@syncfusion/ej2-base';


@Injectable({
    providedIn: 'root',
})
export class AggregateCalculationService implements OnInit {
    public curYearTotal = 0;
    public prevYearTotal = 0;
    public prevYearRefTotal = 0;
    public IFFCurrentYearSales = 0;
    public IFFPreviousYearSales = 0;
    public IFFPreviousYearRefreshSales = 0;
    public FirmenichCurrentYearSales = 0;
    public FirmenichPreviousYearSales = 0;
    public FirmenichPreviousYearRefreshSales = 0;
    public GivaudanCurrentYearSales = 0;
    public GivaudanPreviousYearSales = 0;
    public GivaudanPreviousYearRefreshSales = 0;
    public SymriseCurrentYearSales = 0;
    public SymrisePreviousYearSales = 0;
    public SymrisePreviousYearRefreshSales = 0;
    public TakasagoCurrentYearSales = 0;
    public TakasagoPreviousYearSales = 0;
    public TakasagoPreviousYearRefreshSales = 0;
    public OthersCurrentYearSales = 0;
    public OthersPreviousYearSales = 0;
    public OthersPreviousYearRefreshSales = 0;

    //flags
    public isAggregateRow2Calculated = false;
    public isAggregateRow3Calculated = false;

    //growthRate 
    public curYearGrowthTotal = 0;
    public prevYearRefGrowthTotal = 0;
    public IFFCurrentYearTotal = 0;
    public IFFPreviousYearRefreshTotal = 0;
    public FirmenichCurrentYearTotal = 0;
    public FirmenichPreviousYearRefreshTotal = 0;
    public GivaudanCurrentYearTotal = 0;
    public GivaudanPreviousYearRefreshTotal = 0;
    public SymriseCurrentYearTotal = 0;
    public SymrisePreviousYearRefreshTotal = 0;
    public TakasagoCurrentYearTotal = 0;
    public TakasagoPreviousYearRefreshTotal = 0;
    public OthersCurrentYearTotal = 0;
    public OthersPreviousYearRefreshTotal = 0;
    //aggregate Calculation
    public Country1PercentageOfConsumption = 0;
    public Country2PercentageOfConsumption = 0;
    public Country3PercentageOfConsumption = 0;
    public Country4PercentageOfConsumption = 0;
    // Total Avalilablity
    public IFFCurrentYearAvailability = 0;
    public IFFPreviousYearAvailability = 0;
    public FirmenichCurrentYearAvailability = 0;
    public FirmenichPreviousYearAvailability = 0;
    public GivaudanCurrentYearAvailability = 0;
    public GivaudanPreviousYearAvailability = 0;
    public SymriseCurrentYearAvailability = 0;
    public SymrisePreviousYearAvailability = 0;
    public TakasagoCurrentYearAvailability = 0;
    public TakasagoPreviousYearAvailability = 0;
    public OthersCurrentYearAvailability = 0;
    public OthersPreviousYearAvailability = 0;
    // Encap
    public curYearEncap = 0;
    public prevYearEncap = 0;
    public prevYearRefEncap = 0;
    public IFFCurrentYearEncap = 0;
    public IFFPreviousYearEncap = 0;
    public IFFPreviousYearRefreshEncap = 0;
    public FirmenichCurrentYearEncap = 0;
    public FirmenichPreviousYearEncap = 0;
    public FirmenichPreviousYearRefreshEncap = 0;
    public GivaudanCurrentYearEncap = 0;
    public GivaudanPreviousYearEncap = 0;
    public GivaudanPreviousYearRefreshEncap = 0;
    public SymriseCurrentYearEncap = 0;
    public SymrisePreviousYearEncap = 0;
    public SymrisePreviousYearRefreshEncap = 0;
    public TakasagoCurrentYearEncap = 0;
    public TakasagoPreviousYearEncap = 0;
    public TakasagoPreviousYearRefreshEncap = 0;
    public OthersCurrentYearEncap = 0;
    public OthersPreviousYearEncap = 0;
    public OthersPreviousYearRefreshEncap = 0;

    ngOnInit() {

    }

    constructor(private validationService: ValidationService,
        private percentPipe: PercentPipe) {

    }
    /** 
     * COMMON CALCUATION PART
     * 
     * */
    public getMarketShare(yearlySales: number, totalYearSales: number): number {
        let marketShare = Number(yearlySales) / Number(totalYearSales);
        return isFinite(marketShare) ? marketShare : 0;
    }

    public getGrowthRate(currentSales: number, previousRefreshSales: number): number {
        let growthRate = (Number(currentSales) / Number(previousRefreshSales)) - 1;
        return isFinite(growthRate) ? growthRate : 0;
    }

    public getEncapProportion(totalPotential: number, marketEncap: number): number {
        let proportion = (Number(marketEncap) / Number(totalPotential));
        return isFinite(proportion) ? proportion : 0;
    }

    public getMarketEncapShare(yearlyEncap: number, totalYearEncap: number): number {
        let marketShare = Number(yearlyEncap) / Number(totalYearEncap);
        return isFinite(marketShare) ? marketShare : 0;
    }

    public calculateTotal(data: object, fields: Array<string>) {
        let totalValue = 0;
        if (fields && fields.length > 0 && data) {
            fields.forEach((item) => {
                totalValue = totalValue + parseFloat(data[item] || 0);
            });
        }
        return totalValue;
    }
    public getAvailabilityBasedSales = (availabilityPercent, totalSales) => {
        return totalSales * (availabilityPercent / 100) || 0;
    }

    public getTotalAvailabilityPercent(totalAvailability, totalSales) {
        return (totalAvailability / totalSales) || 0;
    }

    /** 
     * TOTAL SALES AGGREGATE
     * 
     * **/
    public getGridInstance() {
        return (<any>document.getElementById('grid')).ej2_instances[0];
    }

    /**
     * @name: getFilterData
     * @description: get values from filtered grid list and retuns the datasource of all filtered data to user.
    */
    public getFilterData() {
        let query = this.getGridInstance().renderModule.data.generateQuery();
        let idx;
        for (let i = 0; i < query.queries.length; i++) {
            if (query.queries[i].fn == 'onPage') {
                idx = i;
                break;
            }
        }
        query.queries.splice(idx, 1)
        let result = this.getGridInstance().renderModule.data.dataManager.executeLocal(query);
        return result || [];
    }

    /**
    * calculateAggregateRow2
    */
    public calculateAggregateRow2 = (data: any, column: any) => {
        let griddata = this.getFilterData();
        if (griddata && Array.isArray(griddata) && griddata.length > 0 && this.isAggregateRow2Calculated == false) {
            //Market Potential fields
            this.curYearTotal = 0;
            this.prevYearTotal = 0;
            this.prevYearRefTotal = 0;
            this.IFFCurrentYearSales = 0;
            this.IFFPreviousYearSales = 0;
            this.IFFPreviousYearRefreshSales = 0;
            this.FirmenichCurrentYearSales = 0;
            this.FirmenichPreviousYearSales = 0;
            this.FirmenichPreviousYearRefreshSales = 0;
            this.GivaudanCurrentYearSales = 0;
            this.GivaudanPreviousYearSales = 0;
            this.GivaudanPreviousYearRefreshSales = 0;
            this.SymriseCurrentYearSales = 0;
            this.SymrisePreviousYearSales = 0;
            this.SymrisePreviousYearRefreshSales = 0;
            this.TakasagoCurrentYearSales = 0;
            this.TakasagoPreviousYearSales = 0;
            this.TakasagoPreviousYearRefreshSales = 0;
            this.OthersCurrentYearSales = 0;
            this.OthersPreviousYearSales = 0;
            //countryconsumption
            this.OthersPreviousYearRefreshSales = 0;
            this.Country1PercentageOfConsumption = 0;
            this.Country2PercentageOfConsumption = 0;
            this.Country3PercentageOfConsumption = 0;
            this.Country4PercentageOfConsumption = 0;
            this.IFFCurrentYearAvailability = 0;
            //grandtotalAvailablity
            this.IFFPreviousYearAvailability = 0;
            this.FirmenichCurrentYearAvailability = 0;
            this.FirmenichPreviousYearAvailability = 0;
            this.GivaudanCurrentYearAvailability = 0;
            this.GivaudanPreviousYearAvailability = 0;
            this.SymriseCurrentYearAvailability = 0;
            this.SymrisePreviousYearAvailability = 0;
            this.TakasagoCurrentYearAvailability = 0;
            this.TakasagoPreviousYearAvailability = 0;
            this.OthersCurrentYearAvailability = 0;
            this.OthersPreviousYearAvailability = 0;
            //Encapsulation
            this.curYearEncap = 0;
            this.prevYearEncap = 0;
            this.prevYearRefEncap = 0;
            this.IFFCurrentYearEncap = 0;
            this.IFFPreviousYearEncap = 0;
            this.IFFPreviousYearRefreshEncap = 0;
            this.FirmenichCurrentYearEncap = 0;
            this.FirmenichPreviousYearEncap = 0;
            this.FirmenichPreviousYearRefreshEncap = 0;
            this.GivaudanCurrentYearEncap = 0;
            this.GivaudanPreviousYearEncap = 0;
            this.GivaudanPreviousYearRefreshEncap = 0;
            this.SymriseCurrentYearEncap = 0;
            this.SymrisePreviousYearEncap = 0;
            this.SymrisePreviousYearRefreshEncap = 0;
            this.TakasagoCurrentYearEncap = 0;
            this.TakasagoPreviousYearEncap = 0;
            this.TakasagoPreviousYearRefreshEncap = 0;
            this.OthersCurrentYearEncap = 0;
            this.OthersPreviousYearEncap = 0;
            this.OthersPreviousYearRefreshEncap = 0;
            griddata.forEach((item) => {
                let curYearValue = parseFloat(item['FirmenichCurrentYearSales'] || 0) +
                    parseFloat(item['IFFCurrentYearSales'] || 0) +
                    parseFloat(item['GivaudanCurrentYearSales'] || 0) +
                    parseFloat(item['SymriseCurrentYearSales'] || 0) +
                    parseFloat(item['TakasagoCurrentYearSales'] || 0) +
                    parseFloat(item['OthersCurrentYearSales'] || 0);
                let prevYearValue = parseFloat(item['IFFPreviousYearSales'] || 0) +
                    parseFloat(item['FirmenichPreviousYearSales'] || 0) +
                    parseFloat(item['GivaudanPreviousYearSales'] || 0) +
                    parseFloat(item['SymrisePreviousYearSales'] || 0) +
                    parseFloat(item['TakasagoPreviousYearSales'] || 0) +
                    parseFloat(item['OthersPreviousYearSales'] || 0);
                let prevYearRefValue = parseFloat(item['IFFPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['SymrisePreviousYearRefreshSales'] || 0) +
                    parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['OthersPreviousYearRefreshSales'] || 0);
                this.curYearTotal += curYearValue;
                this.prevYearTotal += prevYearValue;
                this.prevYearRefTotal += prevYearRefValue;
                this.IFFCurrentYearSales += (parseFloat(item['IFFCurrentYearSales'] || 0));
                this.IFFPreviousYearSales += (parseFloat(item['IFFPreviousYearSales'] || 0));
                this.IFFPreviousYearRefreshSales += (parseFloat(item['IFFPreviousYearRefreshSales'] || 0));
                this.GivaudanCurrentYearSales += (parseFloat(item['GivaudanCurrentYearSales'] || 0));
                this.GivaudanPreviousYearSales += (parseFloat(item['GivaudanPreviousYearSales'] || 0));
                this.GivaudanPreviousYearRefreshSales += (parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0));
                this.FirmenichCurrentYearSales += (parseFloat(item['FirmenichCurrentYearSales'] || 0));
                this.FirmenichPreviousYearSales += (parseFloat(item['FirmenichPreviousYearSales'] || 0));
                this.FirmenichPreviousYearRefreshSales += (parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0));
                this.SymriseCurrentYearSales += (parseFloat(item['SymriseCurrentYearSales'] || 0));
                this.SymrisePreviousYearSales += (parseFloat(item['SymrisePreviousYearSales'] || 0));
                this.SymrisePreviousYearRefreshSales += (parseFloat(item['SymrisePreviousYearRefreshSales'] || 0));
                this.TakasagoCurrentYearSales += (parseFloat(item['TakasagoCurrentYearSales'] || 0));
                this.TakasagoPreviousYearSales += (parseFloat(item['TakasagoPreviousYearSales'] || 0));
                this.TakasagoPreviousYearRefreshSales += (parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0));
                this.OthersCurrentYearSales += (parseFloat(item['OthersCurrentYearSales'] || 0));
                this.OthersPreviousYearSales += (parseFloat(item['OthersPreviousYearSales'] || 0));
                this.OthersPreviousYearRefreshSales += (parseFloat(item['OthersPreviousYearRefreshSales'] || 0));
                this.Country1PercentageOfConsumption += item['IFFCurrentYearSales'] * (item['Country1PercentageOfConsumption'] / 100);
                this.Country2PercentageOfConsumption += item['IFFCurrentYearSales'] * (item['Country2PercentageOfConsumption'] / 100);
                this.Country3PercentageOfConsumption += item['IFFCurrentYearSales'] * (item['Country3PercentageOfConsumption'] / 100);
                this.Country4PercentageOfConsumption += item['IFFCurrentYearSales'] * (item['Country4PercentageOfConsumption'] / 100);
                this.IFFCurrentYearAvailability += this.getAvailabilityBasedSales(item['IFFCurrentYearAvailability'], curYearValue);
                this.IFFPreviousYearAvailability += this.getAvailabilityBasedSales(item['IFFPreviousYearAvailability'], prevYearRefValue);
                this.FirmenichCurrentYearAvailability += this.getAvailabilityBasedSales(item['FirmenichCurrentYearAvailability'], curYearValue);
                this.FirmenichPreviousYearAvailability += this.getAvailabilityBasedSales(item['FirmenichPreviousYearAvailability'], prevYearRefValue);
                this.GivaudanCurrentYearAvailability += this.getAvailabilityBasedSales(item['GivaudanCurrentYearAvailability'], curYearValue);
                this.GivaudanPreviousYearAvailability += this.getAvailabilityBasedSales(item['GivaudanPreviousYearAvailability'], prevYearRefValue);
                this.SymriseCurrentYearAvailability += this.getAvailabilityBasedSales(item['SymriseCurrentYearAvailability'], curYearValue);
                this.SymrisePreviousYearAvailability += this.getAvailabilityBasedSales(item['SymrisePreviousYearAvailability'], prevYearRefValue);
                this.TakasagoCurrentYearAvailability += this.getAvailabilityBasedSales(item['TakasagoCurrentYearAvailability'], curYearValue);
                this.TakasagoPreviousYearAvailability += this.getAvailabilityBasedSales(item['TakasagoPreviousYearAvailability'], prevYearRefValue);
                this.OthersCurrentYearAvailability += this.getAvailabilityBasedSales(item['OthersCurrentYearAvailability'], curYearValue);
                this.OthersPreviousYearAvailability += this.getAvailabilityBasedSales(item['OthersPreviousYearAvailability'], prevYearRefValue);

                let currentYearEncapTotal = parseFloat(item['IFFCurrentYearEncapsulation'] || 0) +
                    parseFloat(item['FirmenichCurrentYearEncapsulation'] || 0) +
                    parseFloat(item['GivaudanCurrentYearEncapsulation'] || 0) +
                    parseFloat(item['SymriseCurrentYearEncapsulation'] || 0) +
                    parseFloat(item['TakasagoCurrentYearEncapsulation'] || 0) +
                    parseFloat(item['OthersCurrentYearEncapsulation'] || 0);
                let previousYearEncapTotal = parseFloat(item['IFFPreviousYearEncapsulation'] || 0) +
                    parseFloat(item['FirmenichPreviousYearEncapsulation'] || 0) +
                    parseFloat(item['GivaudanPreviousYearEncapsulation'] || 0) +
                    parseFloat(item['SymrisePreviousYearEncapsulation'] || 0) +
                    parseFloat(item['TakasagoPreviousYearEncapsulation'] || 0) +
                    parseFloat(item['OthersPreviousYearEncapsulation'] || 0);
                let previousYearRefreshEncapTotal = parseFloat(item['IFFPreviousYearRefreshEncapsulation'] || 0) +
                    parseFloat(item['FirmenichPreviousYearRefreshEncapsulation'] || 0) +
                    parseFloat(item['GivaudanPreviousYearRefreshEncapsulation'] || 0) +
                    parseFloat(item['SymrisePreviousYearRefreshEncapsulation'] || 0) +
                    parseFloat(item['TakasagoPreviousYearRefreshEncapsulation'] || 0) +
                    parseFloat(item['OthersPreviousYearRefreshEncapsulation'] || 0);
                this.curYearEncap += currentYearEncapTotal;
                this.prevYearEncap += previousYearEncapTotal;
                this.prevYearRefEncap += previousYearRefreshEncapTotal;
                this.IFFCurrentYearEncap += (parseFloat(item['IFFCurrentYearEncapsulation'] || 0));
                this.IFFPreviousYearEncap += (parseFloat(item['IFFPreviousYearEncapsulation'] || 0));
                this.IFFPreviousYearRefreshEncap += (parseFloat(item['IFFPreviousYearRefreshEncapsulation'] || 0));
                this.GivaudanCurrentYearEncap += (parseFloat(item['GivaudanCurrentYearEncapsulation'] || 0));
                this.GivaudanPreviousYearEncap += (parseFloat(item['GivaudanPreviousYearEncapsulation'] || 0));
                this.GivaudanPreviousYearRefreshEncap += (parseFloat(item['GivaudanPreviousYearRefreshEncapsulation'] || 0));
                this.FirmenichCurrentYearEncap += (parseFloat(item['FirmenichCurrentYearEncapsulation'] || 0));
                this.FirmenichPreviousYearEncap += (parseFloat(item['FirmenichPreviousYearEncapsulation'] || 0));
                this.FirmenichPreviousYearRefreshEncap += (parseFloat(item['FirmenichPreviousYearRefreshEncapsulation'] || 0));
                this.SymriseCurrentYearEncap += (parseFloat(item['SymriseCurrentYearEncapsulation'] || 0));
                this.SymrisePreviousYearEncap += (parseFloat(item['SymrisePreviousYearEncapsulation'] || 0));
                this.SymrisePreviousYearRefreshEncap += (parseFloat(item['SymrisePreviousYearRefreshEncapsulation'] || 0));
                this.TakasagoCurrentYearEncap += (parseFloat(item['TakasagoCurrentYearEncapsulation'] || 0));
                this.TakasagoPreviousYearEncap += (parseFloat(item['TakasagoPreviousYearEncapsulation'] || 0));
                this.TakasagoPreviousYearRefreshEncap += (parseFloat(item['TakasagoPreviousYearRefreshEncapsulation'] || 0));
                this.OthersCurrentYearEncap += (parseFloat(item['OthersCurrentYearEncapsulation'] || 0));
                this.OthersPreviousYearEncap += (parseFloat(item['OthersPreviousYearEncapsulation'] || 0));
                this.OthersPreviousYearRefreshEncap += (parseFloat(item['OthersPreviousYearRefreshEncapsulation'] || 0));
            })
            this.isAggregateRow2Calculated = true;
        }

        let fieldName = column.field;
        if (this.isAggregateRow2Calculated == true) {
            switch (fieldName) {
                case SharedConstant.TOTAL_CURRENTYEAR_SALES: {
                    return this.curYearTotal || 0;
                }
                case SharedConstant.TOTAL_PREVIOUSYEAR_REFRESH_SALES: {
                    return this.prevYearRefTotal  || 0;
                }
                case SharedConstant.IFF_CURRENTYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.IFFCurrentYearSales, this.curYearTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.IFF_PREVIOUSYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.IFFPreviousYearSales, this.prevYearTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.FIRMENICH_CURRENTYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.FirmenichCurrentYearSales, this.curYearTotal);

                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.FIRMENICH_PREVIOUSYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.FirmenichPreviousYearSales, this.prevYearTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.FIRMENICH_PREVIOUSYEARREF_SALES: {
                    let marketShareValue = this.getMarketShare(this.FirmenichPreviousYearRefreshSales, this.prevYearRefTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                // GIVAUDAN
                case SharedConstant.GIVAUDAN_CURRENTYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.GivaudanCurrentYearSales, this.curYearTotal);

                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.GIVAUDAN_PREVIOUSYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.GivaudanPreviousYearSales, this.prevYearTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.GIVAUDAN_PREVIOUSYEARREF_SALES: {
                    let marketShareValue = this.getMarketShare(this.GivaudanPreviousYearRefreshSales, this.prevYearRefTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                // SYMRISE
                case SharedConstant.SYMRISE_CURRENTYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.SymriseCurrentYearSales, this.curYearTotal);

                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.SYMRISE_PREVIOUSYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.SymrisePreviousYearSales, this.prevYearTotal);

                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.SYMRISE_PREVIOUSYEARREF_SALES: {
                    let marketShareValue = this.getMarketShare(this.SymrisePreviousYearRefreshSales, this.prevYearRefTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                // TAKASAGO
                case SharedConstant.TAKASAGO_CURRENTYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.TakasagoCurrentYearSales, this.curYearTotal);

                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.TAKASAGO_PREVIOUSYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.TakasagoPreviousYearSales, this.prevYearTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.TAKASAGO_PREVIOUSYEARREF_SALES: {
                    let marketShareValue = this.getMarketShare(this.TakasagoPreviousYearRefreshSales, this.prevYearRefTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                //others
                case SharedConstant.OTHERS_CURRENTYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.OthersCurrentYearSales, this.curYearTotal);

                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.OTHERS_PREVIOUSYEAR_SALES: {
                    let marketShareValue = this.getMarketShare(this.OthersPreviousYearSales, this.prevYearTotal);

                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case SharedConstant.OTHERS_PREVIOUSYEARREF_SALES: {
                    let marketShareValue = this.getMarketShare(this.OthersPreviousYearRefreshSales, this.prevYearRefTotal);
                    return isNaN(marketShareValue) ? 0 : marketShareValue;
                }
                case 'Country1ValueOfConsumption': {
                    return Number(this.Country1PercentageOfConsumption);
                }
                case 'Country2ValueOfConsumption': {
                    return Number(this.Country2PercentageOfConsumption);
                }
                case 'Country3ValueOfConsumption': {
                    return Number(this.Country3PercentageOfConsumption);
                }
                case 'Country4ValueOfConsumption': {
                    return Number(this.Country4PercentageOfConsumption);
                }
                case 'IFFCurrentYearAvailability': {
                    return this.IFFCurrentYearAvailability;
                }
                case 'IFFPreviousYearAvailability': {
                    return this.IFFPreviousYearAvailability;
                }
                case 'FirmenichCurrentYearAvailability': {
                    return this.FirmenichCurrentYearAvailability;
                }
                case 'FirmenichPreviousYearAvailability': {
                    return this.FirmenichPreviousYearAvailability;
                }
                case 'GivaudanCurrentYearAvailability': {
                    return this.GivaudanCurrentYearAvailability;
                }

                case 'GivaudanPreviousYearAvailability': {
                    return this.GivaudanPreviousYearAvailability;
                }
                case 'SymriseCurrentYearAvailability': {
                    return this.SymriseCurrentYearAvailability;
                }
                case 'SymrisePreviousYearAvailability': {
                    return this.SymrisePreviousYearAvailability;
                }
                case 'TakasagoCurrentYearAvailability': {
                    return this.TakasagoCurrentYearAvailability;
                }
                case 'TakasagoPreviousYearAvailability': {
                    return this.TakasagoPreviousYearAvailability;
                }
                case 'OthersCurrentYearAvailability': {
                    return this.OthersCurrentYearAvailability;
                }
                case 'OthersPreviousYearAvailability': {
                    return this.OthersPreviousYearAvailability;
                }
                case 'IFFCurrentYearSalesMP': {
                    return this.IFFCurrentYearSales;
                }
                case 'IFFCurrentYearEncapsulation': {
                    return this.IFFCurrentYearEncap;
                }
                case 'IFFPreviousYearSalesMP': {
                    return this.IFFPreviousYearSales;
                }
                case 'IFFPreviousYearEncapsulation': {
                    return this.IFFPreviousYearEncap;
                }
                case 'IFFPreviousYearRefreshSalesMP': {
                    return this.IFFPreviousYearRefreshSales;
                }
                case 'IFFPreviousYearRefreshEncapsulation': {
                    return this.IFFPreviousYearRefreshEncap;
                }
                case 'FirmenichCurrentYearSalesMP': {
                    return this.FirmenichCurrentYearSales;
                }
                case 'FirmenichCurrentYearEncapsulation': {
                    return this.FirmenichCurrentYearEncap;
                }
                case 'FirmenichPreviousYearSalesMP': {
                    return this.FirmenichPreviousYearSales;
                }
                case 'FirmenichPreviousYearEncapsulation': {
                    return this.FirmenichPreviousYearEncap;
                }
                case 'FirmenichPreviousYearRefreshSalesMP': {
                    return this.FirmenichPreviousYearRefreshSales;
                }
                case 'FirmenichPreviousYearRefreshEncapsulation': {
                    return this.FirmenichPreviousYearRefreshEncap;
                }
                case 'GivaudanCurrentYearSalesMP': {
                    return this.GivaudanCurrentYearSales;
                }
                case 'GivaudanCurrentYearEncapsulation': {
                    return this.GivaudanCurrentYearEncap;
                }
                case 'GivaudanPreviousYearSalesMP': {
                    return this.GivaudanPreviousYearSales;
                }
                case 'GivaudanPreviousYearEncapsulation': {
                    return this.GivaudanPreviousYearEncap;
                }
                case 'GivaudanPreviousYearRefreshSalesMP': {
                    return this.GivaudanPreviousYearRefreshSales;
                }
                case 'GivaudanPreviousYearRefreshEncapsulation': {
                    return this.GivaudanPreviousYearRefreshEncap;
                }
                case 'SymriseCurrentYearSalesMP': {
                    return this.SymriseCurrentYearSales;
                }
                case 'SymriseCurrentYearEncapsulation': {
                    return this.SymriseCurrentYearEncap;
                }
                case 'SymrisePreviousYearSalesMP': {
                    return this.SymrisePreviousYearSales;
                }
                case 'SymrisePreviousYearEncapsulation': {
                    return this.SymrisePreviousYearEncap;
                }
                case 'SymrisePreviousYearRefreshSalesMP': {
                    return this.SymrisePreviousYearRefreshSales;
                }
                case 'SymrisePreviousYearRefreshEncapsulation': {
                    return this.SymrisePreviousYearRefreshEncap;
                }
                case 'TakasagoCurrentYearSalesMP': {
                    return this.TakasagoCurrentYearSales;
                }
                case 'TakasagoCurrentYearEncapsulation': {
                    return this.TakasagoCurrentYearEncap;
                }
                case 'TakasagoPreviousYearSalesMP': {
                    return this.TakasagoPreviousYearSales;
                }
                case 'TakasagoPreviousYearEncapsulation': {
                    return this.TakasagoPreviousYearEncap;
                }
                case 'TakasagoPreviousYearRefreshSalesMP': {
                    return this.TakasagoPreviousYearRefreshSales;
                }
                case 'TakasagoPreviousYearRefreshEncapsulation': {
                    return this.TakasagoPreviousYearRefreshEncap;
                }
                case 'OthersCurrentYearSalesMP': {
                    return this.OthersCurrentYearSales;
                }
                case 'OthersCurrentYearEncapsulation': {
                    return this.OthersCurrentYearEncap;
                }
                case 'OthersPreviousYearSalesMP': {
                    return this.OthersPreviousYearSales;
                }
                case 'OthersPreviousYearEncapsulation': {
                    return this.OthersPreviousYearEncap;
                }
                case 'OthersPreviousYearRefreshSalesMP': {
                    return this.OthersPreviousYearRefreshSales;
                }
                case 'OthersPreviousYearRefreshEncapsulation': {
                    return this.OthersPreviousYearRefreshEncap;
                }
                case 'TotalCurEncap': {
                    return this.curYearEncap;
                }
                case 'TotalPrevEncap': {
                    return this.prevYearEncap;
                }
                case 'TotalPrevRefEncap': {
                    return this.prevYearRefEncap;
                }
                default:
                    return 0;
            }
        } else {
            return 0;
        }
    }

    /**
     * calculateAggregateRow3
     */
    public calculateAggregateRow3 = (data: any, column: any) => {
        try {
            let griddata = this.getFilterData();
            if (griddata && Array.isArray(griddata) && griddata.length > 0 && this.isAggregateRow3Calculated == false) {
                this.curYearGrowthTotal = 0;
                this.prevYearRefGrowthTotal = 0;
                this.IFFCurrentYearTotal = 0;
                this.IFFPreviousYearRefreshTotal = 0;
                this.FirmenichCurrentYearTotal = 0;
                this.FirmenichPreviousYearRefreshTotal = 0;
                this.GivaudanCurrentYearTotal = 0;
                this.GivaudanPreviousYearRefreshTotal = 0;
                this.SymriseCurrentYearTotal = 0;
                this.SymrisePreviousYearRefreshTotal = 0;
                this.TakasagoCurrentYearTotal = 0;
                this.TakasagoPreviousYearRefreshTotal = 0;
                this.OthersCurrentYearTotal = 0;
                this.OthersPreviousYearRefreshTotal = 0;
                griddata.forEach((item) => {
                    let curYearValue = parseFloat(item['FirmenichCurrentYearSales'] || 0) +
                    parseFloat(item['IFFCurrentYearSales'] || 0) +
                    parseFloat(item['GivaudanCurrentYearSales'] || 0) +
                    parseFloat(item['SymriseCurrentYearSales'] || 0) +
                    parseFloat(item['TakasagoCurrentYearSales'] || 0) +
                    parseFloat(item['OthersCurrentYearSales'] || 0);
                let prevYearValue = parseFloat(item['IFFPreviousYearSales'] || 0) +
                    parseFloat(item['FirmenichPreviousYearSales'] || 0) +
                    parseFloat(item['GivaudanPreviousYearSales'] || 0) +
                    parseFloat(item['SymrisePreviousYearSales'] || 0) +
                    parseFloat(item['TakasagoPreviousYearSales'] || 0) +
                    parseFloat(item['OthersPreviousYearSales'] || 0);
                let prevYearRefValue = parseFloat(item['IFFPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['SymrisePreviousYearRefreshSales'] || 0) +
                    parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0) +
                    parseFloat(item['OthersPreviousYearRefreshSales'] || 0);
                    this.curYearGrowthTotal += curYearValue;
                    // let fields = ['IFFPreviousYearRefreshSales', 'FirmenichPreviousYearRefreshSales', 'GivaudanPreviousYearRefreshSales', 'SymrisePreviousYearRefreshSales', 'TakasagoPreviousYearRefreshSales', 'OthersPreviousYearRefreshSales'];
                    // let result = this.calculateTotal(item, fields);
                    let result = parseFloat(item['IFFPreviousYearRefreshSales'] || 0) +
                        parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0) +
                        parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0) +
                        parseFloat(item['SymrisePreviousYearRefreshSales'] || 0) +
                        parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0) +
                        parseFloat(item['OthersPreviousYearRefreshSales'] || 0);
                    this.prevYearRefGrowthTotal += result;
                    this.IFFCurrentYearTotal += (parseFloat(item['IFFCurrentYearSales'] || 0));
                    this.IFFPreviousYearRefreshTotal += (parseFloat(item['IFFPreviousYearRefreshSales'] || 0));
                    this.GivaudanCurrentYearTotal += (parseFloat(item['GivaudanCurrentYearSales'] || 0));
                    this.GivaudanPreviousYearRefreshTotal += (parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0));
                    this.FirmenichCurrentYearTotal += (parseFloat(item['FirmenichCurrentYearSales'] || 0));
                    this.FirmenichPreviousYearRefreshTotal += (parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0));
                    this.SymriseCurrentYearTotal += (parseFloat(item['SymriseCurrentYearSales'] || 0));
                    this.SymrisePreviousYearRefreshTotal += (parseFloat(item['SymrisePreviousYearRefreshSales'] || 0));
                    this.TakasagoCurrentYearTotal += (parseFloat(item['TakasagoCurrentYearSales'] || 0));
                    this.TakasagoPreviousYearRefreshTotal += (parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0));
                    this.OthersCurrentYearTotal += (parseFloat(item['OthersCurrentYearSales'] || 0));
                    this.OthersPreviousYearRefreshTotal += (parseFloat(item['OthersPreviousYearRefreshSales'] || 0));
                })
                this.isAggregateRow3Calculated = true;
            }
            let fieldName = column.field;
            if (this.isAggregateRow3Calculated == true) {
                console.log(fieldName);
                
                switch (fieldName) {
                    case SharedConstant.TOTAL_PREVIOUSYEAR_REFRESH_SALES: {
                        let growthRateValue = this.getGrowthRate(this.curYearGrowthTotal, this.prevYearRefGrowthTotal);
                        return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : this.percentPipe.transform(growthRateValue, '1.0-1');
                    }
                    case SharedConstant.IFF_PREVIOUSYEARREF_SALES: {
                        let growthRateValue = this.getGrowthRate(this.IFFCurrentYearTotal, this.IFFPreviousYearRefreshTotal);
                        console.log("REF", this.IFFCurrentYearTotal, this.IFFPreviousYearRefreshTotal);
                        
                        return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : this.percentPipe.transform(growthRateValue, '1.0-1');
                    }
                    case SharedConstant.FIRMENICH_PREVIOUSYEARREF_SALES: {
                        let growthRateValue = this.getGrowthRate(this.FirmenichCurrentYearTotal, this.FirmenichPreviousYearRefreshTotal);
                        return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : this.percentPipe.transform(growthRateValue, '1.0-1');
                    }
                    case SharedConstant.GIVAUDAN_PREVIOUSYEARREF_SALES: {
                        let growthRateValue = this.getGrowthRate(this.GivaudanCurrentYearTotal, this.GivaudanPreviousYearRefreshTotal);
                        return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : this.percentPipe.transform(growthRateValue, '1.0-1');
                    }
                    case SharedConstant.SYMRISE_PREVIOUSYEARREF_SALES: {
                        let growthRateValue = this.getGrowthRate(this.SymriseCurrentYearTotal, this.SymrisePreviousYearRefreshTotal);
                        return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : this.percentPipe.transform(growthRateValue, '1.0-1');
                    }
                    case SharedConstant.TAKASAGO_PREVIOUSYEARREF_SALES: {
                        let growthRateValue = this.getGrowthRate(this.TakasagoCurrentYearTotal, this.TakasagoPreviousYearRefreshTotal);

                        return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : this.percentPipe.transform(growthRateValue, '1.0-1');
                    }
                    case SharedConstant.OTHERS_PREVIOUSYEARREF_SALES: {
                        let growthRateValue = this.getGrowthRate(this.OthersCurrentYearTotal, this.OthersPreviousYearRefreshTotal);
                        return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : this.percentPipe.transform(growthRateValue, '1.0-1');
                    }
                    case 'IFFCurrentYearAvailability':
                    case 'FirmenichCurrentYearAvailability':
                    case 'GivaudanCurrentYearAvailability':
                    case 'SymriseCurrentYearAvailability':
                    case 'TakasagoCurrentYearAvailability':
                    case 'OthersCurrentYearAvailability': {
                        let getGTAvailablity = this.calculateAggregateRow2(griddata, column);
                        return this.getTotalAvailabilityPercent(getGTAvailablity, this.curYearTotal);
                    }
                    case 'IFFPreviousYearAvailability':
                    case 'FirmenichPreviousYearAvailability':
                    case 'GivaudanPreviousYearAvailability':
                    case 'SymrisePreviousYearAvailability':
                    case 'TakasagoPreviousYearAvailability':
                    case 'OthersPreviousYearAvailability': {
                        let getGTAvailablity = this.calculateAggregateRow2(griddata, column);
                        return this.getTotalAvailabilityPercent(getGTAvailablity, this.prevYearRefTotal);
                    }
                    case 'TotalCurEncap': {
                        return this.percentPipe.transform(this.getEncapProportion(this.curYearTotal, this.curYearEncap), '1.0-1');
                    }
                    case 'TotalPrevEncap': {
                        return this.percentPipe.transform(this.getEncapProportion(this.prevYearTotal, this.prevYearEncap), '1.0-1');
                    }
                    case 'TotalPrevRefEncap': {
                        return this.percentPipe.transform(this.getEncapProportion(this.prevYearRefTotal, this.prevYearRefEncap), '1.0-1');
                    }
                    case 'IFFCurrentYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.IFFCurrentYearSales, this.IFFCurrentYearEncap), '1.0-1');
                    }
                    case 'IFFPreviousYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.IFFPreviousYearSales, this.IFFPreviousYearEncap), '1.0-1');
                    }
                    case 'IFFPreviousYearRefreshEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.IFFPreviousYearRefreshSales, this.IFFPreviousYearRefreshEncap), '1.0-1');
                    }
                    // Firmenich
                    case 'FirmenichCurrentYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.FirmenichCurrentYearSales, this.FirmenichCurrentYearEncap), '1.0-1');
                    }
                    case 'FirmenichPreviousYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.FirmenichPreviousYearSales, this.FirmenichPreviousYearEncap), '1.0-1');
                    }
                    case 'FirmenichPreviousYearRefreshEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.FirmenichPreviousYearRefreshSales, this.FirmenichPreviousYearRefreshEncap), '1.0-1');
                    }
                    case 'GivaudanCurrentYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.GivaudanCurrentYearSales, this.GivaudanCurrentYearEncap), '1.0-1');
                    }
                    case 'GivaudanPreviousYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.GivaudanPreviousYearSales, this.GivaudanPreviousYearEncap), '1.0-1');
                    }
                    case 'GivaudanPreviousYearRefreshEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.GivaudanPreviousYearRefreshSales, this.GivaudanPreviousYearRefreshEncap), '1.0-1');
                    }
                    case 'SymriseCurrentYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.SymriseCurrentYearSales, this.SymriseCurrentYearEncap), '1.0-1');
                    }
                    case 'SymrisePreviousYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.SymrisePreviousYearSales, this.SymrisePreviousYearEncap), '1.0-1');
                    }
                    case 'SymrisePreviousYearRefreshEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.SymrisePreviousYearRefreshSales, this.SymrisePreviousYearRefreshEncap), '1.0-1');
                    }

                    case 'TakasagoCurrentYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.TakasagoCurrentYearSales, this.TakasagoCurrentYearEncap), '1.0-1');
                    }
                    case 'TakasagoPreviousYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.TakasagoPreviousYearSales, this.TakasagoPreviousYearEncap), '1.0-1');
                    }
                    case 'TakasagoPreviousYearRefreshEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.TakasagoPreviousYearRefreshSales, this.TakasagoPreviousYearRefreshEncap), '1.0-1');
                    }

                    case 'OthersCurrentYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.OthersCurrentYearSales, this.OthersCurrentYearEncap), '1.0-1');
                    }
                    case 'OthersPreviousYearEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.OthersPreviousYearSales, this.OthersPreviousYearEncap), '1.0-1');
                    }
                    case 'OthersPreviousYearRefreshEncapsulation': {
                        return this.percentPipe.transform(this.getEncapProportion(this.OthersPreviousYearRefreshSales, this.OthersPreviousYearRefreshEncap), '1.0-1');
                    }
                    default: {
                        return 0;
                    }
                }
            } else {
                return 0;
            }
        } catch (err) {
            console.log(err);
        }
    }
    public calculateMarketShareME = (data: any, column: any) => {
        let fieldName = column.field;
        if (this.isAggregateRow3Calculated === true && this.isAggregateRow2Calculated === true) {
            switch (fieldName) {
                //IFF Encap
                case 'IFFCurrentYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.IFFCurrentYearEncap, this.curYearEncap), '1.0-1');
                }
                case 'IFFPreviousYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.IFFPreviousYearEncap, this.prevYearEncap), '1.0-1');
                }
                case 'IFFPreviousYearRefreshEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.IFFPreviousYearRefreshEncap, this.prevYearRefEncap), '1.0-1');
                }
                //Fermenich Encap
                case 'FirmenichCurrentYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.FirmenichCurrentYearEncap, this.curYearEncap), '1.0-1');
                }
                case 'FirmenichPreviousYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.FirmenichPreviousYearEncap, this.prevYearEncap), '1.0-1');
                }
                case 'FirmenichPreviousYearRefreshEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.FirmenichPreviousYearRefreshEncap, this.prevYearRefEncap), '1.0-1');
                }
                //Givaudan Encap
                case 'GivaudanCurrentYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.GivaudanCurrentYearEncap, this.curYearEncap), '1.0-1');
                }
                case 'GivaudanPreviousYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.GivaudanPreviousYearEncap, this.prevYearEncap), '1.0-1');
                }
                case 'GivaudanPreviousYearRefreshEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.GivaudanPreviousYearRefreshEncap, this.prevYearRefEncap), '1.0-1');
                }
                //Symrise Encap
                case 'SymriseCurrentYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.SymriseCurrentYearEncap, this.curYearEncap), '1.0-1');
                }
                case 'SymrisePreviousYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.SymrisePreviousYearEncap, this.prevYearEncap), '1.0-1');
                }
                case 'SymrisePreviousYearRefreshEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.SymrisePreviousYearRefreshEncap, this.prevYearRefEncap), '1.0-1');
                }
                //Takasago Encap
                case 'TakasagoCurrentYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.TakasagoCurrentYearEncap, this.curYearEncap), '1.0-1');
                }
                case 'TakasagoPreviousYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.TakasagoPreviousYearEncap, this.prevYearEncap), '1.0-1');
                }
                case 'TakasagoPreviousYearRefreshEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.TakasagoPreviousYearRefreshEncap, this.prevYearRefEncap), '1.0-1');
                }
                //Others Encap
                case 'OthersCurrentYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.OthersCurrentYearEncap, this.curYearEncap), '1.0-1');
                }
                case 'OthersPreviousYearEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.OthersPreviousYearEncap, this.prevYearEncap), '1.0-1');
                }
                case 'OthersPreviousYearRefreshEncapsulation': {
                    return this.percentPipe.transform(this.getMarketEncapShare(this.OthersPreviousYearRefreshEncap, this.prevYearRefEncap), '1.0-1');
                }
            }
        }
    }
}

// public getTotalCurrentYearSalesAggregate = (sdata: any) => {
//     let sum = 0;
//     sdata.result = this.getFilterData();
//     if (sdata && sdata.result && sdata.result.length > 0) {
//         sdata.result.forEach((e) => {
//             let fields = ['IFFCurrentYearSales', 'FirmenichCurrentYearSales', 'GivaudanCurrentYearSales', 'SymriseCurrentYearSales', 'TakasagoCurrentYearSales', 'OthersCurrentYearSales'];
//             let result = this.calculateTotal(e, fields);
//             sum = sum + result;
//         });
//     }
//     let intl: Internationalization = new Internationalization();
//     let nFormatter: Function = intl.getNumberFormat({ format: 'C2', currency: 'USD' });
//     return nFormatter(sum);
//     // return Number(sum.toFixed(2));
// }
// public getTotalPrevYearRefSaleAggregate = (sdata: any) => {
//     let sum = 0;
//     // sdata.result = this.getGridInstance().dataSource;
//     sdata.result = this.getFilterData();
//     if (sdata && sdata.result && sdata.result.length > 0) {
//         sdata.result.forEach((e) => {
//             let fields = ['IFFPreviousYearRefreshSales', 'FirmenichPreviousYearRefreshSales', 'GivaudanPreviousYearRefreshSales', 'SymrisePreviousYearRefreshSales', 'TakasagoPreviousYearRefreshSales', 'OthersPreviousYearRefreshSales'];
//             let result = this.calculateTotal(e, fields);
//             sum = sum + result;
//         });
//     }
//     let intl: Internationalization = new Internationalization();
//     let nFormatter: Function = intl.getNumberFormat({ format: 'C2', currency: 'USD' });
//     return nFormatter(sum);
//     // return Number(sum.toFixed(2));
// }
    // public isSalesPercentCalculated = false;
    // public isContryConsumptionCalculated = false;
    // public isTotalAvailablityCalculated = false;
        // public getIffGrowthRate = (data: any) => {
        //     return this.getCompanyBasedTotal(data,'IFFCurrentYearSales' ,'IFFPreviousYearRefreshSales');
        // }
        // public getFirmenichGrowthRate = (data: any) => {
        //     return this.getCompanyBasedTotal(data,'FirmenichCurrentYearSales' ,'FirmenichPreviousYearRefreshSales');
        // }
        // public getGivaudanGrowthRate = (data: any) => {
        //     return this.getCompanyBasedTotal(data,'GivaudanCurrentYearSales' ,'GivaudanPreviousYearRefreshSales');
        // }
        // public getSymriseGrowthRate = (data: any) => {
        //     return this.getCompanyBasedTotal(data,'SymriseCurrentYearSales' ,'SymrisePreviousYearRefreshSales');
        // }
        // public getTakasagoGrowthRate = (data: any) => {
        //     return this.getCompanyBasedTotal(data,'TakasagoCurrentYearSales' ,'TakasagoPreviousYearRefreshSales');
        // }
        // public getOthersGrowthRate = (data: any) => {
        //     return this.getCompanyBasedTotal(data,'OthersCurrentYearSales' ,'OthersPreviousYearRefreshSales');
        // }

        // public getCompanyBasedTotal =  (data, curYear, prevYear) => {
        //     let prevYearIffTotal = 0;
        //     let curYearIffTotal = 0;
        //     if (data && data.result && data.result.length > 0) {
        //         data.result.forEach((item: any) => {
        //             curYearIffTotal = curYearIffTotal + parseFloat(item[curYear] || 0);
        //             prevYearIffTotal = prevYearIffTotal + parseFloat(item[prevYear] || 0);
        //         });
        //     }
        //     let growthRateValue = this.getGrowthRate(curYearIffTotal, prevYearIffTotal);
        //     return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : Number(growthRateValue.toFixed(3));
        // }


// console.log(this.IFFCurrentYearSales,
//     this.IFFPreviousYearSales,
//     this.FirmenichCurrentYearSales,
//     this.FirmenichPreviousYearSales,
//     this.FirmenichPreviousYearRefreshSales,
//     this.GivaudanCurrentYearSales,
//     this.GivaudanPreviousYearSales,
//     this.GivaudanPreviousYearRefreshSales,
//     this.SymriseCurrentYearSales,
//     this.SymrisePreviousYearSales,
//     this.SymrisePreviousYearRefreshSales,
//     this.TakasagoCurrentYearSales,
//     this.TakasagoPreviousYearSales,
//     this.TakasagoPreviousYearRefreshSales,
//     this.OthersCurrentYearSales,
//     this.OthersPreviousYearSales,
//     this.OthersPreviousYearRefreshSales);        


// private calculatePercentage(source, totalField, currentField) {
//     let yearTotal = 0;
//     let YearSales = 0;
//     if (source && Array.isArray(source.result) && source.result.length > 0) {
//         source.result.forEach((item) => {
//             let value = parseFloat(this.validationService.getValueAccessorData(totalField, item, []) || 0);
//             yearTotal += value;
//             YearSales += (parseFloat(item[currentField] || 0));
//         })
//     }
//     let marketShareValue = this.getMarketShare(YearSales, yearTotal);
//     return isNaN(marketShareValue) ? 0 : marketShareValue;
//     // return 0;
// }

    // /** 
    //  * IFF SALES AGGREGATE PERCENTAGE (MARKET SHARE)
    //  * 
    //  * **/
    // public iffCurYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalCurrentYearSales', 'IFFCurrentYearSales');
    // }
    // public iffPrevYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearSales', 'IFFPreviousYearSales');
    // }

    // /** 
    //  * FERMENICH SALES AGGREGATE PERCENTAGE (MARKET SHARE)
    //  * 
    //  * **/
    // public firmenichCurYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalCurrentYearSales', 'FirmenichCurrentYearSales');
    // }
    // public firmenichPrevYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearSales', 'FirmenichPreviousYearSales');
    // }
    // public firmenichPrevYrRefreshSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearRefreshSales', 'FirmenichPreviousYearRefreshSales');
    // }

    // /** 
    //  * GIVAUDAN SALES AGGREGATE PERCENTAGE (MARKET SHARE)
    //  * 
    //  * **/
    // public givaudanCurYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalCurrentYearSales', 'GivaudanCurrentYearSales');
    // }
    // public givaudanPrevYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearSales', 'GivaudanPreviousYearSales');
    // }
    // public givaudanPrevYrRefreshSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearRefreshSales', 'GivaudanPreviousYearRefreshSales');
    // }

    // /** 
    //  * symrise SALES AGGREGATE PERCENTAGE (MARKET SHARE)
    //  * 
    //  * **/
    // public symriseCurYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalCurrentYearSales', 'SymriseCurrentYearSales');
    // }
    // public symrisePrevYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearSales', 'SymrisePreviousYearSales');
    // }
    // public symrisePrevYrRefreshSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearRefreshSales', 'SymrisePreviousYearRefreshSales');
    // }

    // /** 
    //  * takasago SALES AGGREGATE PERCENTAGE (MARKET SHARE)
    //  * 
    //  * **/
    // public takasagoCurYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalCurrentYearSales', 'TakasagoCurrentYearSales');
    // }
    // public takasagoPrevYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearSales', 'TakasagoPreviousYearSales');
    // }

    // public takasagoPrevYrRefreshSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearRefreshSales', 'TakasagoPreviousYearRefreshSales');
    // }

    // /** 
    //  * OTHERS SALES AGGREGATE PERCENTAGE (MARKET SHARE)
    //  * 
    //  * **/
    // public othersCurYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalCurrentYearSales', 'OthersCurrentYearSales');
    // }
    // public othersPrevYrSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearSales', 'OthersPreviousYearSales');
    // }
    // public othersPrevYrRefreshSalesAggregatePercent = (sdata: any) => {
    //     return this.calculatePercentage(sdata, 'TotalPreviousYearRefreshSales', 'OthersPreviousYearRefreshSales');
    // }

/**
*
* GROWTH RATE CALCULATION
*
* **/

    // public getTotalGrowthRate = (data: any) => {
    //     let prevYearRefTotal = 0;
    //     let curYearRefTotal = 0;
    //     if (data && data.result && data.result.length > 0) {
    //         data.result.forEach((element: any) => {
    //             curYearRefTotal = curYearRefTotal + parseFloat(this.validationService.getValueAccessorData('TotalCurrentYearSales', element, []) || 0);
    //             // prevYearRefTotal = prevYearRefTotal + parseFloat(this.validationService.getPrevYearRefSaleTotal('', element, [])|| 0);
    //             let fields = ['IFFPreviousYearRefreshSales', 'FirmenichPreviousYearRefreshSales', 'GivaudanPreviousYearRefreshSales', 'SymrisePreviousYearRefreshSales', 'TakasagoPreviousYearRefreshSales', 'OthersPreviousYearRefreshSales'];
    //             let result = this.calculateTotal(element, fields);
    //             prevYearRefTotal = prevYearRefTotal + result;
    //         })
    //     }
    //     let growthRateValue = this.getGrowthRate(curYearRefTotal, prevYearRefTotal);
    //     return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : Number((growthRateValue * 100).toFixed(3));
    // }
    // public getIffGrowthRate = (data: any, column) => {
    //     return this.getCompanyBasedTotal(data, 'IFFCurrentYearSales', 'IFFPreviousYearRefreshSales');
    // }
    // public getFirmenichGrowthRate = (data: any) => {
    //     return this.getCompanyBasedTotal(data, 'FirmenichCurrentYearSales', 'FirmenichPreviousYearRefreshSales');
    // }
    // public getGivaudanGrowthRate = (data: any) => {
    //     return this.getCompanyBasedTotal(data, 'GivaudanCurrentYearSales', 'GivaudanPreviousYearRefreshSales');
    // }
    // public getSymriseGrowthRate = (data: any) => {
    //     return this.getCompanyBasedTotal(data, 'SymriseCurrentYearSales', 'SymrisePreviousYearRefreshSales');
    // }
    // public getTakasagoGrowthRate = (data: any) => {
    //     return this.getCompanyBasedTotal(data, 'TakasagoCurrentYearSales', 'TakasagoPreviousYearRefreshSales');
    // }
    // public getOthersGrowthRate = (data: any) => {
    //     return this.getCompanyBasedTotal(data, 'OthersCurrentYearSales', 'OthersPreviousYearRefreshSales');
    // }

    // public getCompanyBasedTotal = (data, curYear, prevYear) => {
    //     let prevYearIffTotal = 0;
    //     let curYearIffTotal = 0;
    //     if (data && data.result && data.result.length > 0) {
    //         data.result.forEach((item: any) => {
    //             curYearIffTotal = curYearIffTotal + parseFloat(item[curYear] || 0);
    //             prevYearIffTotal = prevYearIffTotal + parseFloat(item[prevYear] || 0);
    //         });
    //     }
    //     let growthRateValue = this.getGrowthRate(curYearIffTotal, prevYearIffTotal);
    //     return isNullOrUndefined(growthRateValue) || isNaN(growthRateValue) ? 0 : Number(growthRateValue.toFixed(3));
    // }




    // public getCountry1ConsumptionTotal = (data: any) => {
    //     // this.getConsumptionTotal(data, 'Country1PercentageOfConsumption');
    //     let consumptionTotal = 0;
    //     if (data && data.result && Array.isArray(data.result)) {
    //         data.result.forEach(element => {
    //             consumptionTotal += element['IFFCurrentYearSales'] * (element['Country1PercentageOfConsumption'] / 100)
    //         });
    //     }
    //     return Number(consumptionTotal);
    // }
    // public getCountry2ConsumptionTotal = (data: any) => {
    //     // this.getConsumptionTotal(data, 'Country2PercentageOfConsumption');
    //     let consumptionTotal = 0;
    //     if (data && data.result && Array.isArray(data.result)) {
    //         data.result.forEach(element => {
    //             consumptionTotal += element['IFFCurrentYearSales'] * (element['Country2PercentageOfConsumption'] / 100)
    //         });
    //     }
    //     return Number(consumptionTotal);
    // }
    // public getCountry3ConsumptionTotal = (data: any) => {
    //     // this.getConsumptionTotal(data, 'Country2PercentageOfConsumption');
    //     let consumptionTotal = 0;
    //     if (data && data.result && Array.isArray(data.result)) {
    //         data.result.forEach(element => {
    //             consumptionTotal += element['IFFCurrentYearSales'] * (element['Country3PercentageOfConsumption'] / 100)
    //         });
    //     }
    //     return Number(consumptionTotal);
    // }
    // public getCountry4ConsumptionTotal = (data: any) => {
    //     // this.getConsumptionTotal(data, 'Country2PercentageOfConsumption');
    //     let consumptionTotal = 0;
    //     if (data && data.result && Array.isArray(data.result)) {
    //         data.result.forEach(element => {
    //             consumptionTotal += element['IFFCurrentYearSales'] * (element['Country4PercentageOfConsumption'] / 100)
    //         });
    //     }
    //     return Number(consumptionTotal);
    // }
    // public getConsumptionTotal(data: any, field) {
    //     let consumptionTotal = 0;
    //     if (data && data.result && Array.isArray(data.result)) {
    //         data.result.forEach(element => {
    //             consumptionTotal += element['IFFCurrentYearSales'] * (element[field] / 100);
    //         });
    //     }
    //     return consumptionTotal;
    // }


/**
 * County Consuption Tab Aggregate calculation
 */

    // public calculateCountryConsumption = (data: any, column: any) => {
    //     if (data && Array.isArray(data.result) && data.result.length > 0 && this.isContryConsumptionCalculated == false) {
    //         this.Country1PercentageOfConsumption = 0;
    //         this.Country2PercentageOfConsumption = 0;
    //         this.Country3PercentageOfConsumption = 0;
    //         this.Country4PercentageOfConsumption = 0;
    //         data.result.forEach(element => {
    //             this.Country1PercentageOfConsumption += element['IFFCurrentYearSales'] * (element['Country1PercentageOfConsumption'] / 100);
    //             this.Country2PercentageOfConsumption += element['IFFCurrentYearSales'] * (element['Country2PercentageOfConsumption'] / 100);
    //             this.Country3PercentageOfConsumption += element['IFFCurrentYearSales'] * (element['Country3PercentageOfConsumption'] / 100);
    //             this.Country4PercentageOfConsumption += element['IFFCurrentYearSales'] * (element['Country4PercentageOfConsumption'] / 100);
    //         });
    //         this.isContryConsumptionCalculated = true;
    //     }
    //     let fieldName = column.field;
    //     if (this.isContryConsumptionCalculated == true) {
    //         switch (fieldName) {
    //             case 'Country1ValueOfConsumption': {
    //                 return Number(this.Country1PercentageOfConsumption);
    //             }
    //             case 'Country2ValueOfConsumption': {
    //                 return Number(this.Country2PercentageOfConsumption);
    //             }
    //             case 'Country3ValueOfConsumption': {
    //                 return Number(this.Country3PercentageOfConsumption);
    //             }
    //             case 'Country4ValueOfConsumption': {
    //                 return Number(this.Country4PercentageOfConsumption);
    //             }
    //             default: {
    //                 return 0;
    //             }
    //         }
    //     }
    // }
    // /**
    //  * Aggregate Sales Percent
    //  */
    // public salesAggregatePercent = (sdata: any, columns: any) => {
    //     if (sdata && Array.isArray(sdata.result) && sdata.result.length > 0 && this.isSalesPercentCalculated === false) {
    //         this.curYearTotal = 0;
    //         this.prevYearTotal = 0;
    //         this.prevYearRefTotal = 0;
    //         this.IFFCurrentYearSales = 0;
    //         this.IFFPreviousYearSales = 0;
    //         this.FirmenichCurrentYearSales = 0;
    //         this.FirmenichPreviousYearSales = 0;
    //         this.FirmenichPreviousYearRefreshSales = 0;
    //         this.GivaudanCurrentYearSales = 0;
    //         this.GivaudanPreviousYearSales = 0;
    //         this.GivaudanPreviousYearRefreshSales = 0;
    //         this.SymriseCurrentYearSales = 0;
    //         this.SymrisePreviousYearSales = 0;
    //         this.SymrisePreviousYearRefreshSales = 0;
    //         this.TakasagoCurrentYearSales = 0;
    //         this.TakasagoPreviousYearSales = 0;
    //         this.TakasagoPreviousYearRefreshSales = 0;
    //         this.OthersCurrentYearSales = 0;
    //         this.OthersPreviousYearSales = 0;
    //         this.OthersPreviousYearRefreshSales = 0;
    //         sdata.result.forEach((item) => {
    //             let curYearValue = parseFloat(this.validationService.getValueAccessorData('TotalCurrentYearSales', item, []) || 0);
    //             let prevYearValue = parseFloat(this.validationService.getValueAccessorData('TotalPreviousYearSales', item, []) || 0);
    //             let prevYearRefValue = parseFloat(this.validationService.getValueAccessorData('TotalPreviousYearRefreshSales', item, []) || 0);
    //             this.curYearTotal += curYearValue;
    //             this.prevYearTotal += prevYearValue;
    //             this.prevYearRefTotal += prevYearRefValue;
    //             this.IFFCurrentYearSales += (parseFloat(item['IFFCurrentYearSales'] || 0));
    //             this.IFFPreviousYearSales += (parseFloat(item['IFFPreviousYearSales'] || 0));
    //             this.GivaudanCurrentYearSales += (parseFloat(item['GivaudanCurrentYearSales'] || 0));
    //             this.GivaudanPreviousYearSales += (parseFloat(item['GivaudanPreviousYearSales'] || 0));
    //             this.GivaudanPreviousYearRefreshSales += (parseFloat(item['GivaudanPreviousYearRefreshSales'] || 0));
    //             this.FirmenichCurrentYearSales += (parseFloat(item['FirmenichCurrentYearSales'] || 0));
    //             this.FirmenichPreviousYearSales += (parseFloat(item['FirmenichPreviousYearSales'] || 0));
    //             this.FirmenichPreviousYearRefreshSales += (parseFloat(item['FirmenichPreviousYearRefreshSales'] || 0));
    //             this.SymriseCurrentYearSales += (parseFloat(item['SymriseCurrentYearSales'] || 0));
    //             this.SymrisePreviousYearSales += (parseFloat(item['SymrisePreviousYearSales'] || 0));
    //             this.SymrisePreviousYearRefreshSales += (parseFloat(item['SymrisePreviousYearRefreshSales'] || 0));
    //             this.TakasagoCurrentYearSales += (parseFloat(item['TakasagoCurrentYearSales'] || 0));
    //             this.TakasagoPreviousYearSales += (parseFloat(item['TakasagoPreviousYearSales'] || 0));
    //             this.TakasagoPreviousYearRefreshSales += (parseFloat(item['TakasagoPreviousYearRefreshSales'] || 0));
    //             this.OthersCurrentYearSales += (parseFloat(item['OthersCurrentYearSales'] || 0));
    //             this.OthersPreviousYearSales += (parseFloat(item['OthersPreviousYearSales'] || 0));
    //             this.OthersPreviousYearRefreshSales += (parseFloat(item['OthersPreviousYearRefreshSales'] || 0));
    //         })
    //         this.isSalesPercentCalculated = true;
    //     }

    //     let fieldName = columns.field;
    //     if (this.isSalesPercentCalculated == true) {
    //         switch (fieldName) {
    //             case SharedConstant.IFF_CURRENTYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.IFFCurrentYearSales, this.curYearTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.IFF_PREVIOUSYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.IFFPreviousYearSales, this.prevYearTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.FIRMENICH_CURRENTYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.FirmenichCurrentYearSales, this.curYearTotal);

    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.FIRMENICH_PREVIOUSYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.FirmenichPreviousYearSales, this.prevYearTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.FIRMENICH_PREVIOUSYEARREF_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.FirmenichPreviousYearRefreshSales, this.prevYearRefTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             // GIVAUDAN
    //             case SharedConstant.GIVAUDAN_CURRENTYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.GivaudanCurrentYearSales, this.curYearTotal);

    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.GIVAUDAN_PREVIOUSYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.GivaudanPreviousYearSales, this.prevYearTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.GIVAUDAN_PREVIOUSYEARREF_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.GivaudanPreviousYearRefreshSales, this.prevYearRefTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             // SYMRISE
    //             case SharedConstant.SYMRISE_CURRENTYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.SymriseCurrentYearSales, this.curYearTotal);

    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.SYMRISE_PREVIOUSYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.SymrisePreviousYearSales, this.prevYearTotal);

    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.SYMRISE_PREVIOUSYEARREF_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.SymrisePreviousYearRefreshSales, this.prevYearRefTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             // TAKASAGO
    //             case SharedConstant.TAKASAGO_CURRENTYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.TakasagoCurrentYearSales, this.curYearTotal);

    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.TAKASAGO_PREVIOUSYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.TakasagoPreviousYearSales, this.prevYearTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.TAKASAGO_PREVIOUSYEARREF_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.TakasagoPreviousYearRefreshSales, this.prevYearRefTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             //others
    //             case SharedConstant.OTHERS_CURRENTYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.OthersCurrentYearSales, this.curYearTotal);

    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.OTHERS_PREVIOUSYEAR_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.OthersPreviousYearSales, this.prevYearTotal);

    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             case SharedConstant.OTHERS_PREVIOUSYEARREF_SALES: {
    //                 let marketShareValue = this.getMarketShare(this.OthersPreviousYearRefreshSales, this.prevYearRefTotal);
    //                 return isNaN(marketShareValue) ? 0 : marketShareValue;
    //             }
    //             default:
    //                 return 0;
    //         }
    //     } else {
    //         return 0;
    //     }
    // }
    // public getIffCurGrandTotalAvalilablity = (data: any, column) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'IFFCurrentYearAvailability');
    // }
    // public getIffPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'IFFPreviousYearAvailability');
    // }

    // public getFirmenichCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'FirmenichCurrentYearAvailability');
    // }
    // public getFirmenichPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'FirmenichPreviousYearAvailability');
    // }

    // public getGivaudanCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'GivaudanCurrentYearAvailability');
    // }
    // public getGivaudanPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'GivaudanPreviousYearAvailability');
    // }

    // public getSymriseCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'SymriseCurrentYearAvailability');
    // }
    // public getSymrisePrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'SymrisePreviousYearAvailability');
    // }


    // public getTakasagoCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'TakasagoCurrentYearAvailability');
    // }
    // public getTakasagoPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'TakasagoPreviousYearAvailability');
    // }


    // public getOthersCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'OthersCurrentYearAvailability');
    // }
    // public getOthersPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'OthersPreviousYearAvailability');
    // }

    // public getGrandTotalAvailablity = (data, currentSales, Availablity) => {
    //     let grandTotal = 0;
    //     if (data && data.result && data.result.length > 0) {
    //         data.result.forEach(element => {
    //             let curYearSales = this.validationService.getValueAccessorData(currentSales, element, []);
    //             grandTotal += this.getAvailabilityBasedSales(element[Availablity], curYearSales);
    //         });
    //     }
    //     return grandTotal;
    //     // return 0;
    // }

    // /**
    //  * @name calculateTotalAvailablity
    //  * 
    //  */

    // public calculateTotalAvailablity = (data: any, column: any) => {
    //     if (data && Array.isArray(data.result) && data.result.length > 0 && this.isTotalAvailablityCalculated == false) {
    //         //  this.currentYearSalesTotal = 0;
    //         //  this.previousYearSalesTotal = 0;
    //         //  this.previousYearRefSalesTotal = 0;
    //         this.IFFCurrentYearAvailability = 0;
    //         this.IFFPreviousYearAvailability = 0;
    //         this.FirmenichCurrentYearAvailability = 0;
    //         this.FirmenichPreviousYearAvailability = 0;
    //         this.GivaudanCurrentYearAvailability = 0;
    //         this.GivaudanPreviousYearAvailability = 0;
    //         this.SymriseCurrentYearAvailability = 0;
    //         this.SymrisePreviousYearAvailability = 0;
    //         this.TakasagoCurrentYearAvailability = 0;
    //         this.TakasagoPreviousYearAvailability = 0;
    //         this.OthersCurrentYearAvailability = 0;
    //         this.OthersPreviousYearAvailability = 0;
    //         data.result.forEach((element) => {
    //             let curYearSales =  parseFloat(element['FirmenichCurrentYearSales'] || 0) +
    //             parseFloat(element['IFFCurrentYearSales'] || 0) +
    //             parseFloat(element['GivaudanCurrentYearSales'] || 0) +
    //             parseFloat(element['SymriseCurrentYearSales'] || 0) +
    //             parseFloat(element['TakasagoCurrentYearSales'] || 0) +
    //             parseFloat(element['OthersCurrentYearSales'] || 0);
    //             let previousYearSalesTotal= parseFloat(element['IFFPreviousYearRefreshSales'] || 0) +
    //             parseFloat(element['FirmenichPreviousYearRefreshSales'] || 0) +
    //             parseFloat(element['GivaudanPreviousYearRefreshSales'] || 0) +
    //             parseFloat(element['SymrisePreviousYearRefreshSales'] || 0) +
    //             parseFloat(element['TakasagoPreviousYearRefreshSales'] || 0) +
    //             parseFloat(element['OthersPreviousYearRefreshSales'] || 0);
    //             this.IFFCurrentYearAvailability += this.getAvailabilityBasedSales(element['IFFCurrentYearAvailability'], curYearSales);
    //             this.IFFPreviousYearAvailability += this.getAvailabilityBasedSales(element['IFFPreviousYearAvailability'], previousYearSalesTotal);
    //             this.FirmenichCurrentYearAvailability += this.getAvailabilityBasedSales(element['FirmenichCurrentYearAvailability'], curYearSales);
    //             this.FirmenichPreviousYearAvailability += this.getAvailabilityBasedSales(element['FirmenichPreviousYearAvailability'], previousYearSalesTotal);
    //             this.GivaudanCurrentYearAvailability += this.getAvailabilityBasedSales(element['GivaudanCurrentYearAvailability'], curYearSales);
    //             this.GivaudanPreviousYearAvailability += this.getAvailabilityBasedSales(element['GivaudanPreviousYearAvailability'], previousYearSalesTotal);
    //             this.SymriseCurrentYearAvailability += this.getAvailabilityBasedSales(element['SymriseCurrentYearAvailability'], curYearSales);
    //             this.SymrisePreviousYearAvailability += this.getAvailabilityBasedSales(element['SymrisePreviousYearAvailability'], previousYearSalesTotal);
    //             this.TakasagoCurrentYearAvailability += this.getAvailabilityBasedSales(element['TakasagoCurrentYearAvailability'], curYearSales);
    //             this.TakasagoPreviousYearAvailability += this.getAvailabilityBasedSales(element['TakasagoPreviousYearAvailability'], previousYearSalesTotal);
    //             this.OthersCurrentYearAvailability += this.getAvailabilityBasedSales(element['OthersCurrentYearAvailability'], curYearSales);
    //             this.OthersPreviousYearAvailability += this.getAvailabilityBasedSales(element['OthersPreviousYearAvailability'], previousYearSalesTotal);
    //         });
    //         this.isTotalAvailablityCalculated = true;
    //     }
    //     let fieldName = column.field;
    //     if (this.isTotalAvailablityCalculated == true) {
    //         switch (fieldName) {
    //             case 'IFFCurrentYearAvailability':{
    //                 return this.IFFCurrentYearAvailability;
    //             }
    //             case 'IFFPreviousYearAvailability':{
    //                 return this.IFFPreviousYearAvailability;
    //             }
    //             case 'FirmenichCurrentYearAvailability':{
    //                 return this.FirmenichCurrentYearAvailability;
    //             }
    //             case 'FirmenichPreviousYearAvailability':{
    //                 return this.FirmenichPreviousYearAvailability;
    //             }
    //             case 'GivaudanCurrentYearAvailability':{
    //                 return this.GivaudanCurrentYearAvailability;
    //             }

    //             case 'GivaudanPreviousYearAvailability':{
    //                 return this.GivaudanPreviousYearAvailability;
    //             }
    //             case 'SymriseCurrentYearAvailability':{
    //                 return this.SymriseCurrentYearAvailability;
    //             }
    //             case 'SymrisePreviousYearAvailability':{
    //                 return this.SymrisePreviousYearAvailability;
    //             }
    //             case 'TakasagoCurrentYearAvailability':{
    //                 return this.TakasagoCurrentYearAvailability;
    //             }
    //             case 'TakasagoPreviousYearAvailability':{
    //                 return this.TakasagoPreviousYearAvailability;
    //             }
    //             case 'OthersCurrentYearAvailability':{
    //                 return this.OthersCurrentYearAvailability;
    //             }
    //             case 'OthersPreviousYearAvailability':{
    //                 return this.OthersPreviousYearAvailability;
    //             }

    //         }
    //     }
    // }

    // public getIffCurGrandTotalAvalilablity = (data: any, column) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'IFFCurrentYearAvailability');
    // }
    // public getIffPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'IFFPreviousYearAvailability');
    // }

    // public getFirmenichCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'FirmenichCurrentYearAvailability');
    // }
    // public getFirmenichPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'FirmenichPreviousYearAvailability');
    // }

    // public getGivaudanCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'GivaudanCurrentYearAvailability');
    // }
    // public getGivaudanPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'GivaudanPreviousYearAvailability');
    // }

    // public getSymriseCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'SymriseCurrentYearAvailability');
    // }
    // public getSymrisePrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'SymrisePreviousYearAvailability');
    // }


    // public getTakasagoCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'TakasagoCurrentYearAvailability');
    // }
    // public getTakasagoPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'TakasagoPreviousYearAvailability');
    // }


    // public getOthersCurGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalCurrentYearSales', 'OthersCurrentYearAvailability');
    // }
    // public getOthersPrevGrandTotalAvalilablity = (data: any) => {
    //     return this.getGrandTotalAvailablity(data, 'TotalPreviousYearRefreshSales', 'OthersPreviousYearAvailability');
    // }

    // public getGrandTotalAvailablity = (data, currentSales, Availablity) => {
    //     let grandTotal = 0;
    //     if (data && data.result && data.result.length > 0) {
    //         data.result.forEach(element => {
    //             let curYearSales = this.validationService.getValueAccessorData(currentSales, element, []);
    //             grandTotal += this.getAvailabilityBasedSales(element[Availablity], curYearSales);
    //         });
    //     }
    //     return grandTotal;
    //     // return 0;
    // }
    // public getIffCurGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalCurrentYearSalesAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }
    // public getIffPrevGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);

    //     let curYearSales = this.getTotalPrevYearRefSaleAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }


    // public getFirmenichCurGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalCurrentYearSalesAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }
    // public getFirmenichPrevGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     ;
    //     let curYearSales = this.getTotalPrevYearRefSaleAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }




    // public getGivaudanCurGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalCurrentYearSalesAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }
    // public getGivaudanPrevGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);

    //     let curYearSales = this.getTotalPrevYearRefSaleAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }



    // public getSymriseCurGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalCurrentYearSalesAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }
    // public getSymrisePrevGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalPrevYearRefSaleAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }
    // // getTotalAvailabilityPercent

    // public getTakasagoCurGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalCurrentYearSalesAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }
    // public getTakasagoPrevGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);

    //     let curYearSales = this.getTotalPrevYearRefSaleAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }

    // public getOthersCurGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalCurrentYearSalesAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }
    // public getOthersPrevGrandTotalAvailablityPercent = (data: any, columns: any) => {
    //     let getGTAvailablity = this.calculateAggregateRow2(data, columns);
    //     let curYearSales = this.getTotalPrevYearRefSaleAggregate(data); this.getTotalPrevYearRefSaleAggregate(data);
    //     return this.getTotalAvailabilityPercent(getGTAvailablity, curYearSales);
    // }

