export class SharedConstant {
    //Grid Constants
    public static IFF_CURRENTYEAR_AVAILABILITY_SALES = "IFFCurrentYearAvailabilitySales";
    public static IFF_PREVIOUSYEAR_AVAILABILITY_SALES = "IFFPreviousYearAvailabilitySales";
    public static FIRMENICH_CURRENTYEAR_AVAILABILITY_SALES = "FirmenichCurrentYearAvailabilitySales";
    public static FIRMENICH_PREVIOUSYEAR_AVAILABILITY_SALES = "FirmenichPreviousYearAvailabilitySales";
    public static GIVAUDAN_CURRENTYEAR_AVAILABILITY_SALES = "GivaudanCurrentYearAvailabilitySales";
    public static GIVAUDAN_PREVIOUSYEAR_AVAILABILITY_SALES = "GivaudanPreviousYearAvailabilitySales";
    public static SYMRISE_CURRENTYEAR_AVAILABILITY_SALES = "SymriseCurrentYearAvailabilitySales";
    public static SYMRISE_PREVIOUSYEAR_AVAILABILITY_SALES = "SymrisePreviousYearAvailabilitySales";
    public static TAKASAGO_CURRENTYEAR_AVAILABILITY_SALES = "TakasagoCurrentYearAvailabilitySales";
    public static TAKASAGO_PREVIOUSYEAR_AVAILABILITY_SALES = "TakasagoPreviousYearAvailabilitySales";
    public static OTHERS_CURRENTYEAR_AVAILABILITY_SALES = "OthersCurrentYearAvailabilitySales";
    public static OTHERS_PREVIOUSYEAR_AVAILABILITY_SALES = "OthersPreviousYearAvailabilitySales";

    public static TOTAL_CURRENTYEAR_SALES = "TotalCurrentYearSales";
    public static TOTAL_PREVIOUSYEAR_SALES = "TotalPreviousYearSales";
    public static TOTAL_PREVIOUSYEAR_REFRESH_SALES = "TotalPreviousYearRefreshSales"
    public static IFF_CURRENTYEAR_TOTALPOTENTIAL = "IFFCurrentYearTP";
    public static IFF_PREVIOUSYEAR_TOTALPOTENTIAL = "IFFPreviousYearTP";
    public static FIRMENICH_CURRENTYEAR_TOTALPOTENTIAL = "FirmenichCurrentYearTP";
    public static FIRMENICH_PREVIOUSYEAR_TOTALPOTENTIAL = "FirmenichPreviousYearTP";
    public static GIVAUDAN_CURRENTYEAR_TOTALPOTENTIAL = "GivaudanCurrentYearTP";
    public static GIVAUDAN_PREVIOUSYEAR_TOTALPOTENTIAL = "GivaudanPreviousYearTP";
    public static SYMRISE_CURRENTYEAR_TOTALPOTENTIAL = "SymriseCurrentYearTP";
    public static SYMRISE_PREVIOUSYEAR_TOTALPOTENTIAL = "SymrisePreviousYearTP";
    public static TAKASAGO_CURRENTYEAR_TOTALPOTENTIAL = "TakasagoCurrentYearTP";
    public static TAKASAGO_PREVIOUSYEAR_TOTALPOTENTIAL = "TakasagoPreviousYearTP";
    public static OTHERS_CURRENTYEAR_TOTALPOTENTIAL = "OthersCurrentYearTP";
    public static OTHERS_PREVIOUSYEAR_TOTALPOTENTIAL = "OthersPreviousYearTP";

    public static IFF_CURRENTYEAR_MARKETPOTENTIAL = "IFFCurrentYearSalesMP";
    public static FIRMENICH_CURRENTYEAR_MARKETPOTENTIAL = "FirmenichCurrentYearSalesMP";
    public static GIVAUDAN_CURRENTYEAR_MARKETPOTENTIAL = "GivaudanCurrentYearSalesMP";
    public static SYMRISE_CURRENTYEAR_MARKETPOTENTIAL = "SymriseCurrentYearSalesMP";
    public static TAKASAGO_CURRENTYEAR_MARKETPOTENTIAL = "TakasagoCurrentYearSalesMP";
    public static OTHERS_CURRENTYEAR_MARKETPOTENTIAL = "OthersCurrentYearSalesMP";

    public static IFF_PREVIOUSYEAR_MARKETPOTENTIAL = "IFFPreviousYearSalesMP";
    public static FIRMENICH_PREVIOUSYEAR_MARKETPOTENTIAL = "FirmenichPreviousYearSalesMP";
    public static GIVAUDAN_PREVIOUSYEAR_MARKETPOTENTIAL = "GivaudanPreviousYearSalesMP";
    public static SYMRISE_PREVIOUSYEAR_MARKETPOTENTIAL = "SymrisePreviousYearSalesMP";
    public static TAKASAGO_PREVIOUSYEAR_MARKETPOTENTIAL = "TakasagoPreviousYearSalesMP";
    public static OTHERS_PREVIOUSYEAR_MARKETPOTENTIAL = "OthersPreviousYearSalesMP";

    public static IFF_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL = "IFFPreviousYearRefreshSalesMP";
    public static FIRMENICH_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL = "FirmenichPreviousYearRefreshSalesMP";
    public static GIVAUDAN_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL = "GivaudanPreviousYearRefreshSalesMP";
    public static SYMRISE_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL = "SymrisePreviousYearRefreshSalesMP";
    public static TAKASAGO_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL = "TakasagoPreviousYearRefreshSalesMP";
    public static OTHERS_PREVIOUSYEAR_REFRESH_MARKETPOTENTIAL = "OthersPreviousYearRefreshSalesMP";

    public static IFF_TOTAL_CONSUMPTION = "IFFTotalConsumption";
    public static TOTAL_CURYEAR_ENCAP = "TotalCurEncap";
    public static TOTAL_PREVYEAR_ENCAP = "TotalPrevEncap";
    public static TOTAL_PREVYEARREF_ENCAP = "TotalPrevRefEncap";

    public static IFF_CURRENTYEAR_SALES = "IFFCurrentYearSales";
    public static IFF_PREVIOUSYEAR_SALES = "IFFPreviousYearSales";
    public static IFF_PREVIOUSYEARREF_SALES = "IFFPreviousYearRefreshSales";
    public static FIRMENICH_CURRENTYEAR_SALES = "FirmenichCurrentYearSales";
    public static FIRMENICH_PREVIOUSYEAR_SALES = "FirmenichPreviousYearSales";
    public static FIRMENICH_PREVIOUSYEARREF_SALES = "FirmenichPreviousYearRefreshSales";
    public static GIVAUDAN_CURRENTYEAR_SALES = "GivaudanCurrentYearSales";
    public static GIVAUDAN_PREVIOUSYEAR_SALES = "GivaudanPreviousYearSales";
    public static GIVAUDAN_PREVIOUSYEARREF_SALES = "GivaudanPreviousYearRefreshSales";
    public static SYMRISE_CURRENTYEAR_SALES = "SymriseCurrentYearSales";
    public static SYMRISE_PREVIOUSYEAR_SALES = "SymrisePreviousYearSales";
    public static SYMRISE_PREVIOUSYEARREF_SALES = "SymrisePreviousYearRefreshSales";
    public static TAKASAGO_CURRENTYEAR_SALES = "TakasagoCurrentYearSales";
    public static TAKASAGO_PREVIOUSYEAR_SALES = "TakasagoPreviousYearSales";
    public static TAKASAGO_PREVIOUSYEARREF_SALES = "TakasagoPreviousYearRefreshSales";
    public static OTHERS_CURRENTYEAR_SALES = "OthersCurrentYearSales";
    public static OTHERS_PREVIOUSYEAR_SALES = "OthersPreviousYearSales";
    public static OTHERS_PREVIOUSYEARREF_SALES = "OthersPreviousYearRefreshSales";
}