import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Tsej2gridComponent } from './tsej2grid.component';

describe('Tsej2gridComponent', () => {
  let component: Tsej2gridComponent;
  let fixture: ComponentFixture<Tsej2gridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Tsej2gridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Tsej2gridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
