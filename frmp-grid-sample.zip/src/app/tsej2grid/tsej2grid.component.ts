import { Component, OnInit } from '@angular/core';
import { Grid, Edit } from '@syncfusion/ej2-grids';

@Component({
  selector: 'app-tsej2grid',
  templateUrl: './tsej2grid.component.html',
  styleUrls: ['./tsej2grid.component.css']
})


export class Tsej2gridComponent implements OnInit {
  public grid: Grid;
  constructor() {

  
     this.grid = new Grid({
      dataSource: [{
        OrderID: 1,
        CustomerID: 100,
        Freight:1200,
        ShipCountry: 'India'
      },
      {
        OrderID: 2,
        CustomerID: 200,
        Freight:1500,
        ShipCountry: 'India'
      },
      {
        OrderID: 3,
        CustomerID: 100,
        Freight:400,
        ShipCountry: 'China'
      },
      {
        OrderID: 4,
        CustomerID: 300,
        Freight:1900,
        ShipCountry: 'India'
      }],
      editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
      columns: [
          { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 100, isPrimaryKey: true },
          { field: 'CustomerID', headerText: 'Customer ID', width: 120 },
          { field: 'Freight', headerText: 'Freight', textAlign: 'Right', width: 120, format: 'C2' },
          { field: 'ShipCountry', headerText: 'Ship Country', width: 150 }
      ],
      height: 315
  });
   }

  ngOnInit() {
    Grid.Inject(Edit);
    this.grid.appendTo('#Grid');

  }

}
