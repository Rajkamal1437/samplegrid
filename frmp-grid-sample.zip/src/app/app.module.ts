import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { NgModule, ErrorHandler, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { PercentPipe, CommonModule } from '@angular/common';
import {  BulkEntryDeactivateGuard } from './bulkentry-gaurd.service';

import {
  GridModule, Resize, ResizeService , PageService, SortService, FilterService, GroupService, EditService, ToolbarService, AggregateService
} from '@syncfusion/ej2-angular-grids';
import { NumericTextBoxModule } from '@syncfusion/ej2-angular-inputs';
import { TabModule } from '@syncfusion/ej2-angular-navigations';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule, Http } from '@angular/http';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { CurrencyMaskModule } from "ng2-currency-mask";
import { EditorModule } from 'primeng/editor';
import { NgMaterialModule } from './material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ROUTES } from './app.router';

import { AppComponent } from './app.component';
import { EjsgridComponent } from './ejsgrid/ejsgrid.component';
import { LandingComponent } from './landing/landing.component';
import { Tsej2gridComponent } from './tsej2grid/tsej2grid.component';


@NgModule({
  declarations: [
    AppComponent,
    EjsgridComponent,
    LandingComponent,
    Tsej2gridComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    HttpModule,
    CommonModule,
    RouterModule.forRoot(ROUTES, { useHash: false, preloadingStrategy: PreloadAllModules }),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    GridModule,
    NgMaterialModule
  ],
  providers: [
    ToastrService,
    BulkEntryDeactivateGuard,
    PercentPipe,
    // CustomPercentPipe,
    PageService,
    SortService,
    FilterService,
    GroupService,
    EditService,
    ToolbarService,
    AggregateService,
    ResizeService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
