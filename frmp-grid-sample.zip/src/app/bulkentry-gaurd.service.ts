import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { EjsgridComponent  } from './ejsgrid/ejsgrid.component';



@Injectable()
export class BulkEntryDeactivateGuard {
    canDeactivate(component: EjsgridComponent,
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot) {
        if (component.canDeactivate()) {
            return true;
        } else {
            if (confirm('Are you sure to exit without saving...')) {
                return true;
            } else {
                return false;
            }
        }
    }
}
