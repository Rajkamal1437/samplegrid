export enum TaskStatus {
    None = -1,
    Draft = 4,
    Completed = 5,
    Approved = 6,
    New = 7,
    Submitted = 8,
    ReOpened = 12,
    Validated = 13,
    CategoryManagerValidated = 17,
    SubRegionalManagerValidated = 18,
    RGMValidated = 15,
    VPValidated = 19,
    SVPValidated = 16,
    StrategyValidated = 14
}
